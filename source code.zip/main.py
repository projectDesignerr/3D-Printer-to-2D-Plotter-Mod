"""
main.py — Entry point for the G-Code Pen Plotter application.

Usage:
    python main.py           → Launch interactive GUI
    python main.py --cli     → Generate G-code from command-line arguments
"""

import sys
import argparse

import config_manager
from gcode_engine import PlotterConfig, save_gcode, generate_gcode_text


def main():
    json_cfg = config_manager.load_config()

    parser = argparse.ArgumentParser(
        description="G-Code Pen Plotter — Generate G-code for pen plotters (settings stored in JSON)"
    ) 
    parser.add_argument("--cli", action="store_true", help="Run in CLI mode (no GUI)")
    parser.add_argument("--config", type=str, default=config_manager.CONFIG_FILE, help="Path to settings JSON configuration file")
    parser.add_argument("--text", type=str, default=json_cfg.get("default_text", "hello world"), help="Text to write")
    parser.add_argument("-o", "--output", type=str, default=json_cfg.get("output_file", "text_output.gcode"), help="Output file")
    parser.add_argument("--scale", type=float, default=json_cfg.get("default_scale", 4.0), help="Text scale in mm")
    parser.add_argument("--pen-z", type=float, default=json_cfg.get("pen_touch_z", 0.0), help="Pen touch Z height (0.0 = Bed Level)")
    parser.add_argument("--z-hop", type=float, default=json_cfg.get("z_hop", 2.0), help="Z hop distance")
    parser.add_argument("--bed-x", type=float, default=json_cfg.get("bed_x", 220.0), help="Bed X dimension")
    parser.add_argument("--bed-y", type=float, default=json_cfg.get("bed_y", 220.0), help="Bed Y dimension")
    parser.add_argument("--no-center", action="store_true", help="Don't center text")
    parser.add_argument("--no-home", action="store_true", help="Don't home axes")
    parser.add_argument("--image", type=str, help="Image file to convert to G-code")
    parser.add_argument("--threshold", type=int, default=128, help="Image threshold (0-255)")
    parser.add_argument("--fill-mode", type=str, default="contour",
                        choices=["contour", "centerline", "hatch", "both"], help="Image fill mode")
    parser.add_argument("--no-optimize", action="store_true", help="Disable smart toolpath optimization")
    parser.add_argument("--offset-x", type=float, default=json_cfg.get("offset_x", 0.0), help="Pen toolhead X offset in mm")
    parser.add_argument("--offset-y", type=float, default=json_cfg.get("offset_y", 0.0), help="Pen toolhead Y offset in mm (e.g. front mount)")
    parser.add_argument("--offset-z", type=float, default=json_cfg.get("offset_z", 0.0), help="Pen toolhead Z offset in mm")

    args = parser.parse_args()

    if args.cli or args.image:
        _run_cli(args)
    else:
        _run_gui()


def _run_cli(args):
    """CLI mode: generate G-code from arguments."""
    if args.image:
        # Image mode
        import image_processor
        from gcode_engine import generate_gcode_paths

        cfg = PlotterConfig(
            output_file=args.output,
            pen_touch_z=args.pen_z,
            z_hop=args.z_hop,
            bed_x=args.bed_x,
            bed_y=args.bed_y,
            home_all=not args.no_home,
            optimize_paths=not args.no_optimize,
            offset_x=args.offset_x,
            offset_y=args.offset_y,
            offset_z=args.offset_z,
        )

        print(f"Processing image: {args.image}")
        paths, img_w, img_h = image_processor.image_to_paths(
            image_path=args.image,
            target_width_mm=min(args.bed_x * 0.9, 200),
            threshold=args.threshold,
            fill_mode=args.fill_mode,
        )

        # Center on bed
        offset_x, offset_y = 0.0, 0.0
        if not args.no_center and paths:
            all_x = [p[0] for poly in paths for p in poly]
            all_y = [p[1] for poly in paths for p in poly]
            if all_x and all_y:
                pw = max(all_x) - min(all_x)
                ph = max(all_y) - min(all_y)
                offset_x = (cfg.bed_x - pw) / 2.0 - min(all_x)
                offset_y = (cfg.bed_y - ph) / 2.0 - min(all_y)

        writer = generate_gcode_paths(cfg, paths, offset_x, offset_y)
        count = save_gcode(cfg, writer)
        _, est_time, draw_dist, travel_dist = writer.estimate_time()
        print(f"Generated {cfg.output_file} with {count} G-code lines from image.")
        print(f"Toolhead Pen Offset: X={cfg.offset_x:+.2f}mm, Y={cfg.offset_y:+.2f}mm, Z={cfg.offset_z:+.2f}mm")
        print(f"Image: {img_w}x{img_h} px → {len(paths)} paths")
        print(f"Estimated Plot Time: ~{est_time} (Draw: {draw_dist:.1f}mm, Travel: {travel_dist:.1f}mm)")
    else:
        # Text mode
        cfg = PlotterConfig(
            text=args.text,
            output_file=args.output,
            scale=args.scale,
            pen_touch_z=args.pen_z,
            z_hop=args.z_hop,
            bed_x=args.bed_x,
            bed_y=args.bed_y,
            center_text=not args.no_center,
            home_all=not args.no_home,
            optimize_paths=not args.no_optimize,
            offset_x=args.offset_x,
            offset_y=args.offset_y,
            offset_z=args.offset_z,
        )

        writer = generate_gcode_text(cfg)
        count = save_gcode(cfg, writer)
        _, est_time, draw_dist, travel_dist = writer.estimate_time()
        print(f"Generated {cfg.output_file} with {count} G-code lines.")
        print(f"Toolhead Pen Offset: X={cfg.offset_x:+.2f}mm, Y={cfg.offset_y:+.2f}mm, Z={cfg.offset_z:+.2f}mm")
        print(f"Estimated Plot Time: ~{est_time} (Draw: {draw_dist:.1f}mm, Travel: {travel_dist:.1f}mm)")
        print(f"Safety: no Z command will go below {cfg.pen_touch_z:.2f} mm.")


def _run_gui():
    """Launch the interactive GUI."""
    from gui import launch_gui
    launch_gui()


if __name__ == "__main__":
    main()
