"""
media_manager.py — Removable drive (SD Card / USB) discovery, direct saving, and safe ejection.

Provides automatic detection of ejectable media for 3D printer and CNC workflows.
"""

import os
import shutil
import ctypes
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional


def get_removable_drives() -> List[Dict[str, Any]]:
    """
    Detect all currently connected removable drives (SD cards, USB flash drives).
    
    Returns:
        List of dicts: [
            {
                "path": "E:\\",
                "letter": "E",
                "label": "SD_CARD",
                "free_gb": 7.29,
                "display": "💾 SD_CARD (E:) — 7.3 GB free",
                "short_display": "SD Card (E:)"
            },
            ...
        ]
    """
    drives = []
    DRIVE_REMOVABLE = 2

    if os.name == "nt":
        try:
            bitmask = ctypes.windll.kernel32.GetLogicalDrives()
            for i in range(26):
                if bitmask & (1 << i):
                    letter = chr(65 + i)
                    drive_path = f"{letter}:\\"
                    drive_type = ctypes.windll.kernel32.GetDriveTypeW(drive_path)

                    if drive_type == DRIVE_REMOVABLE:
                        vol_buf = ctypes.create_unicode_buffer(260)
                        ctypes.windll.kernel32.GetVolumeInformationW(
                            drive_path, vol_buf, 260, None, None, None, None, 0
                        )
                        vol_label = vol_buf.value.strip() or "SD / USB Drive"

                        free_gb = 0.0
                        try:
                            usage = shutil.disk_usage(drive_path)
                            free_gb = usage.free / (1024 ** 3)
                            display = f"💾 {vol_label} ({letter}:) — {free_gb:.1f} GB free"
                        except Exception:
                            display = f"💾 {vol_label} ({letter}:)"

                        drives.append({
                            "path": drive_path,
                            "letter": letter,
                            "label": vol_label,
                            "free_gb": free_gb,
                            "display": display,
                            "short_display": f"{vol_label} ({letter}:)"
                        })
        except Exception:
            pass

    return drives


def save_gcode_to_removable(
    lines: List[str],
    drive_path: str,
    filename: str = "text_output.gcode"
) -> Tuple[bool, str, str]:
    """
    Save G-code directly to a removable drive root or directory.
    
    Returns:
        (success: bool, target_filepath: str, message: str)
    """
    try:
        clean_filename = os.path.basename(filename)
        if not clean_filename.lower().endswith(".gcode"):
            clean_filename += ".gcode"

        target_file = os.path.join(drive_path, clean_filename)
        content = "\n".join(lines) + "\n"
        Path(target_file).write_text(content, encoding="ascii")
        return True, target_file, f"Successfully saved to {target_file}"
    except Exception as e:
        return False, "", f"Failed to write to {drive_path}: {e}"


def eject_drive(drive_path: str) -> Tuple[bool, str]:
    """
    Safely eject a removable drive on Windows.
    
    Returns:
        (success: bool, message: str)
    """
    drive_letter = drive_path.strip().rstrip(":\\").upper() + ":"
    if os.name == "nt":
        try:
            ps_cmd = (
                f"$drive = New-Object -comObject Shell.Application; "
                f"$drive.Namespace(17).ParseName('{drive_letter}').InvokeVerb('Eject')"
            )
            res = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
                capture_output=True,
                text=True,
                timeout=4,
            )
            if res.returncode == 0:
                return True, f"Drive {drive_letter} is safe to remove!"
            else:
                return False, f"Eject warning: {res.stderr.strip() or 'Busy'}"
        except Exception as e:
            return False, f"Could not eject {drive_letter}: {e}"
    return False, "Eject not supported on this OS"
