"""
preview.py — Live G-code path preview widget.

A custom tkinter canvas that renders draw segments (dark/cyan) and travel segments
(light/dashed) with zoom, pan, live dimensions in mm, hover inspection, and
interactive drag-to-move positioning on the print bed.
"""

import math
import tkinter as tk
from typing import List, Tuple, Optional, Callable

from gcode_engine import GCodeBuilder, Polyline


class PreviewCanvas(tk.Canvas):
    """
    Canvas widget that renders G-code toolpaths with zoom, pan, hover dimensions,
    and drag-to-move positioning.

    Colors:
      - Draw moves: solid vibrant cyan
      - Travel moves: dashed gray line
      - Bed boundary: dotted rectangle
      - Artwork Bounding Box & Dimensions: crisp amber/cyan overlays
    """

    def __init__(self, master, **kwargs):
        kwargs.setdefault("bg", "#141424")
        kwargs.setdefault("highlightthickness", 0)
        super().__init__(master, **kwargs)

        # View state
        self._zoom = 1.0
        self._pan_x = 0.0
        self._pan_y = 0.0
        self._drag_pan_start = None
        self._drag_item_start = None
        self._is_dragging_item = False

        # Callbacks
        self._on_move_callback: Optional[Callable[[float, float, bool], None]] = None
        self._on_hover_callback: Optional[Callable[[float, float, Optional[Tuple[float, float, float, float]]], None]] = None

        # Data
        self._draw_segments: List[Tuple[float, float, float, float]] = []
        self._travel_segments: List[Tuple[float, float, float, float]] = []
        self._bed_x = 220.0
        self._bed_y = 220.0
        self._offset_x = 0.0
        self._offset_y = 0.0
        self._paths: List[Polyline] = []
        self._bbox: Optional[Tuple[float, float, float, float]] = None  # (min_x, min_y, max_x, max_y)
        self._est_time_str: str = "--"
        self._draw_dist_mm: float = 0.0
        self._travel_dist_mm: float = 0.0

        # Hover state
        self._cursor_world: Optional[Tuple[float, float]] = None
        self._is_hovering_item: bool = False

        # Notebook page overlay state
        self._notebook_enabled: bool = False
        self._notebook_cfg: dict = {}
        self._has_auto_fit: bool = False

        # PCB Board overlay state
        self._pcb_enabled: bool = False
        self._pcb_cfg: dict = {}

        # Manual Eraser state
        self._eraser_radius_mm: float = 3.0
        self._is_erasing: bool = False
        self._eraser_screen_pos: Optional[Tuple[int, int]] = None
        self._current_erase_batch: List[Tuple[float, float, float, float]] = []
        self._erased_history: List[List[Tuple[float, float, float, float]]] = []
        self._original_draw_segments: List[Tuple[float, float, float, float]] = []
        self._on_erase_callback: Optional[Callable[[List[Tuple[float, float, float, float]], int], None]] = None

        # User zoom lock state (prevents timer/resize from resetting manual zoom)
        self._user_zoomed: bool = False

        # Bind events
        self.bind("<MouseWheel>", self._on_scroll)
        self.bind("<ButtonPress-1>", self._on_left_press)
        self.bind("<B1-Motion>", self._on_left_drag)
        self.bind("<ButtonRelease-1>", self._on_left_release)
        self.bind("<Double-Button-1>", self._on_double_click_reset)
        self.bind("<ButtonPress-2>", self._on_pan_start)
        self.bind("<B2-Motion>", self._on_pan_drag)
        self.bind("<Shift-ButtonPress-1>", self._on_pan_start)
        self.bind("<Shift-B1-Motion>", self._on_pan_drag)
        self.bind("<ButtonPress-3>", self._on_right_press)
        self.bind("<B3-Motion>", self._on_right_drag)
        self.bind("<ButtonRelease-3>", self._on_right_release)
        self.bind("<Motion>", self._on_mouse_move)
        self.bind("<Leave>", self._on_mouse_leave)
        self.bind("<Configure>", self._on_resize)

    def set_on_erase_callback(self, callback: Callable[[List[Tuple[float, float, float, float]], int], None]):
        """Callback when user erases strokes: callback(remaining_segments, history_len)."""
        self._on_erase_callback = callback

    def set_on_move_callback(self, callback: Callable[[float, float, bool], None]):
        """Callback when item is dragged on the plate: callback(dx_mm, dy_mm, is_done)."""
        self._on_move_callback = callback

    def set_on_hover_callback(self, callback: Callable[[float, float, Optional[Tuple[float, float, float, float]]], None]):
        """Callback when mouse moves: callback(wx, wy, bbox)."""
        self._on_hover_callback = callback

    def set_bed_size(self, bed_x: float, bed_y: float, offset_x: float = 0.0, offset_y: float = 0.0):
        """Set the print bed dimensions and toolhead offsets."""
        self._bed_x = max(10.0, bed_x)
        self._bed_y = max(10.0, bed_y)
        self._offset_x = offset_x
        self._offset_y = offset_y

    def set_notebook_overlay(self, enabled: bool, cfg: dict = None):
        """Enable/disable the notebook page ruled-line overlay."""
        self._notebook_enabled = enabled
        self._notebook_cfg = cfg or {}

    def set_pcb_overlay(self, enabled: bool, cfg: dict = None):
        """Enable/disable the PCB Copper Clad board blank overlay on the print bed."""
        self._pcb_enabled = enabled
        self._pcb_cfg = cfg or {}

    def load_from_builder(self, builder: GCodeBuilder, auto_fit: bool = False):
        """Load draw/travel segments and estimated time from a GCodeBuilder."""
        self._draw_segments = list(builder.draw_segments)
        self._original_draw_segments = list(builder.draw_segments)
        self._erased_history = []
        self._travel_segments = list(builder.travel_segments)
        self._paths = []
        try:
            _, self._est_time_str, self._draw_dist_mm, self._travel_dist_mm = builder.estimate_time()
        except Exception:
            self._est_time_str = "--"
        self._compute_bbox()
        if not self._has_auto_fit or (auto_fit and not self._user_zoomed):
            self._auto_fit()
            self._has_auto_fit = True
        self.render()

    def load_paths(self, paths: List[Polyline], offset_x: float = 0, offset_y: float = 0, auto_fit: bool = False):
        """Load raw polyline paths for preview."""
        self._paths = paths
        self._draw_segments = []
        self._travel_segments = []

        for poly in paths:
            if len(poly) < 2:
                continue
            for i in range(len(poly) - 1):
                x1 = poly[i][0] + offset_x
                y1 = poly[i][1] + offset_y
                x2 = poly[i + 1][0] + offset_x
                y2 = poly[i + 1][1] + offset_y
                self._draw_segments.append((x1, y1, x2, y2))

        self._original_draw_segments = list(self._draw_segments)
        self._erased_history = []
        self._compute_bbox()
        if not self._has_auto_fit or (auto_fit and not self._user_zoomed):
            self._auto_fit()
            self._has_auto_fit = True
        self.render()

    def _compute_bbox(self):
        """Compute the bounding box (min_x, min_y, max_x, max_y) of draw segments."""
        if not self._draw_segments:
            self._bbox = None
            return

        all_x = []
        all_y = []
        for x1, y1, x2, y2 in self._draw_segments:
            all_x.extend([x1, x2])
            all_y.extend([y1, y2])

        if all_x and all_y:
            self._bbox = (min(all_x), min(all_y), max(all_x), max(all_y))
        else:
            self._bbox = None

    def get_bbox_dimensions(self) -> Optional[Tuple[float, float, float, float, float, float]]:
        """Return (min_x, min_y, max_x, max_y, width_mm, height_mm) or None."""
        if self._bbox is None:
            return None
        min_x, min_y, max_x, max_y = self._bbox
        w = max(0.0, max_x - min_x)
        h = max(0.0, max_y - min_y)
        return min_x, min_y, max_x, max_y, w, h

    def clear(self):
        """Clear all paths."""
        self._draw_segments = []
        self._travel_segments = []
        self._paths = []
        self._bbox = None
        self.render()

    def _auto_fit(self):
        """Auto-zoom and pan to fit the bed with nice padding in view."""
        canvas_w = self.winfo_width() or 400
        canvas_h = self.winfo_height() or 400

        margin = 35
        available_w = max(50, canvas_w - 2 * margin)
        available_h = max(50, canvas_h - 2 * margin)

        if self._bed_x > 0 and self._bed_y > 0:
            zoom_x = available_w / self._bed_x
            zoom_y = available_h / self._bed_y
            self._zoom = min(zoom_x, zoom_y)
        else:
            self._zoom = 1.0

        self._pan_x = margin + (available_w - self._bed_x * self._zoom) / 2
        self._pan_y = margin + (available_h - self._bed_y * self._zoom) / 2

    def _world_to_screen(self, wx: float, wy: float) -> Tuple[float, float]:
        """Convert world (mm) coordinates to screen (pixel) coordinates."""
        sx = wx * self._zoom + self._pan_x
        sy = (self._bed_y - wy) * self._zoom + self._pan_y
        return sx, sy

    def _screen_to_world(self, sx: float, sy: float) -> Tuple[float, float]:
        """Convert screen (pixel) coordinates to world (mm) coordinates."""
        if self._zoom == 0:
            return 0.0, 0.0
        wx = (sx - self._pan_x) / self._zoom
        wy = self._bed_y - ((sy - self._pan_y) / self._zoom)
        return wx, wy

    def _is_inside_item(self, wx: float, wy: float, margin_mm: float = 6.0) -> bool:
        """Check if world coordinate is within the artwork bounding box (with margin)."""
        if self._bbox is None:
            return False
        min_x, min_y, max_x, max_y = self._bbox
        return (min_x - margin_mm <= wx <= max_x + margin_mm and
                min_y - margin_mm <= wy <= max_y + margin_mm)

    def render(self):
        """Redraw the entire scene."""
        self.delete("all")

        # 1. Draw Bed Boundary
        bx1, by1 = self._world_to_screen(0, 0)
        bx2, by2 = self._world_to_screen(self._bed_x, self._bed_y)

        # Bed plate fill & border
        self.create_rectangle(
            bx1, by2, bx2, by1,
            fill="#1a1a2e",
            outline="#3a3a60",
            width=2,
            tags="bed",
        )

        # 2. Draw Grid
        grid_spacing = 10  # mm
        major_spacing = 50 # mm
        for gx in range(0, int(self._bed_x) + 1, grid_spacing):
            sx1, sy1 = self._world_to_screen(gx, 0)
            sx2, sy2 = self._world_to_screen(gx, self._bed_y)
            color = "#2d2d4e" if gx % major_spacing == 0 else "#222238"
            width = 1.5 if gx % major_spacing == 0 else 1.0
            self.create_line(sx1, sy1, sx2, sy2, fill=color, width=width, tags="grid")

        for gy in range(0, int(self._bed_y) + 1, grid_spacing):
            sx1, sy1 = self._world_to_screen(0, gy)
            sx2, sy2 = self._world_to_screen(self._bed_x, gy)
            color = "#2d2d4e" if gy % major_spacing == 0 else "#222238"
            width = 1.5 if gy % major_spacing == 0 else 1.0
            self.create_line(sx1, sy1, sx2, sy2, fill=color, width=width, tags="grid")

        # 2a. Reachable Pen Envelope Overlay (when toolhead offsets are configured)
        reach_max_x = max(0.0, self._bed_x - max(0.0, self._offset_x))
        reach_max_y = max(0.0, self._bed_y - max(0.0, self._offset_y))
        reach_min_x = max(0.0, -self._offset_x)
        reach_min_y = max(0.0, -self._offset_y)

        if (abs(self._offset_x) > 0.1 or abs(self._offset_y) > 0.1) and not self._notebook_enabled:
            rx1, ry1 = self._world_to_screen(reach_min_x, reach_min_y)
            rx2, ry2 = self._world_to_screen(reach_max_x, reach_max_y)
            self.create_rectangle(
                rx1, ry2, rx2, ry1,
                outline="#00d4ff",
                dash=(4, 4),
                width=1,
                tags="reachable_envelope",
            )

        # 2b. Notebook Page Overlay (between grid and toolpaths)
        if self._notebook_enabled:
            self._render_notebook_overlay()

        # 2c. PCB Copper Clad Board Overlay
        if self._pcb_enabled:
            self._render_pcb_overlay()

        # 3. Draw Travel Moves (subtle dashed lines)
        travel_color = "#94a3b8" if (self._notebook_enabled or self._pcb_enabled) else "#444466"
        for x1, y1, x2, y2 in self._travel_segments:
            sx1, sy1 = self._world_to_screen(x1, y1)
            sx2, sy2 = self._world_to_screen(x2, y2)
            self.create_line(
                sx1, sy1, sx2, sy2,
                fill=travel_color,
                dash=(2, 4),
                width=1,
                tags="travel",
            )

        # 4. Draw Drawing Moves (vibrant ink)
        # In PCB mode, use jet-black permanent marker ink (#0a0a0f); in notebook mode, use rich dark ballpoint blue ink (#1e3a8a); otherwise vibrant cyan (#00d4ff)
        if self._pcb_enabled:
            draw_color = "#000000"
            draw_width = max(1, int(1.8 * self._zoom / 2))
        elif self._notebook_enabled:
            draw_color = "#1e3a8a"
            draw_width = max(1, int(1.8 * self._zoom / 2))
        else:
            draw_color = "#00d4ff"
            draw_width = max(1, int(1.6 * self._zoom / 2))

        for x1, y1, x2, y2 in self._draw_segments:
            sx1, sy1 = self._world_to_screen(x1, y1)
            sx2, sy2 = self._world_to_screen(x2, y2)
            self.create_line(
                sx1, sy1, sx2, sy2,
                fill=draw_color,
                width=draw_width,
                capstyle=tk.ROUND,
                joinstyle=tk.ROUND,
                tags="draw",
            )

        # 5. Origin Marker (0,0)
        ox, oy = self._world_to_screen(0, 0)
        self.create_oval(ox - 4, oy - 4, ox + 4, oy + 4, fill="#ff4757", outline="#ffffff", width=1, tags="origin")
        self.create_text(ox + 8, oy + 8, text="(0,0)", fill="#8888aa" if not self._notebook_enabled else "#475569", font=("Segoe UI", 9), anchor="nw", tags="origin")

        # 6. Artwork Bounding Box & Live Dimensions in mm
        if self._bbox is not None:
            min_x, min_y, max_x, max_y = self._bbox
            w_mm = max_x - min_x
            h_mm = max_y - min_y

            if w_mm > 0.01 or h_mm > 0.01:
                # Screen coords for bounding box (min_x, max_y is top-left in screen coords)
                box_x1, box_y_top = self._world_to_screen(min_x, max_y)
                box_x2, box_y_bot = self._world_to_screen(max_x, min_y)

                # Check if artwork exceeds reachable pen envelope
                is_out_of_reach = (
                    max_y > reach_max_y + 0.1 or min_y < reach_min_y - 0.1 or
                    max_x > reach_max_x + 0.1 or min_x < reach_min_x - 0.1
                )

                # Draw bounding box
                default_box_color = "#2563eb" if self._notebook_enabled else "#38bdf8"
                if is_out_of_reach:
                    box_color = "#ff4757"
                elif self._is_hovering_item or self._is_dragging_item:
                    box_color = "#ea580c"
                else:
                    box_color = default_box_color
                dash_pattern = (4, 3)
                self.create_rectangle(
                    box_x1, box_y_top, box_x2, box_y_bot,
                    outline=box_color,
                    dash=dash_pattern,
                    width=2.0 if is_out_of_reach else (1.5 if self._is_hovering_item else 1.0),
                    tags="dimension_box",
                )

                label_color = "#1e293b" if self._notebook_enabled else "#38bdf8"

                # Top Width Dimension Label
                mid_x = (box_x1 + box_x2) / 2
                self.create_text(
                    mid_x, box_y_top - 10,
                    text=f"↔ Width: {w_mm:.1f} mm",
                    fill=label_color,
                    font=("Segoe UI", 10, "bold"),
                    anchor="s",
                    tags="dimension_label",
                )

                # Right Height Dimension Label
                mid_y = (box_y_top + box_y_bot) / 2
                self.create_text(
                    box_x2 + 10, mid_y,
                    text=f"↕ Height: {h_mm:.1f} mm",
                    fill=label_color,
                    font=("Segoe UI", 10, "bold"),
                    anchor="w",
                    tags="dimension_label",
                )

                # Position Label (Bottom-Left of item)
                pos_label_color = "#475569" if self._notebook_enabled else "#a0aec0"
                self.create_text(
                    box_x1, box_y_bot + 12,
                    text=f"Pos: ({min_x:.1f}, {min_y:.1f}) mm",
                    fill=pos_label_color,
                    font=("Segoe UI", 9),
                    anchor="nw",
                    tags="dimension_label",
                )

                # Hover Tooltip Badge near cursor when hovering over item
                if self._is_hovering_item and self._cursor_world is not None:
                    c_wx, c_wy = self._cursor_world
                    c_sx, c_sy = self._world_to_screen(c_wx, c_wy)

                    tooltip_text = (
                        f"📏 Size: {w_mm:.1f} mm × {h_mm:.1f} mm\n"
                        f"⏱️ Est. Time: ~{self._est_time_str}\n"
                        f"📍 Pos: X={min_x:.1f} mm, Y={min_y:.1f} mm\n"
                        f"✋ Drag with Left-Click to move"
                    )
                    tt_x = c_sx + 15
                    tt_y = c_sy - 42

                    # Draw pill background
                    self.create_rectangle(
                        tt_x - 6, tt_y - 6, tt_x + 220, tt_y + 56,
                        fill="#0b0f19",
                        outline="#38bdf8",
                        width=1.5,
                        tags="hover_tooltip",
                    )
                    self.create_text(
                        tt_x, tt_y,
                        text=tooltip_text,
                        fill="#f1f5f9",
                        font=("Segoe UI", 9, "bold"),
                        anchor="nw",
                        tags="hover_tooltip",
                    )

        # 6b. Draw Eraser Cursor Overlay (when actively erasing with Right-Click)
        if self._is_erasing and self._eraser_screen_pos is not None:
            ex, ey = self._eraser_screen_pos
            r_scr = max(8.0, self._eraser_radius_mm * self._zoom)
            self.create_oval(
                ex - r_scr, ey - r_scr, ex + r_scr, ey + r_scr,
                outline="#ff4757",
                width=2.0,
                dash=(3, 2),
                tags="eraser_cursor",
            )
            self.create_text(
                ex + r_scr + 8, ey,
                text="🧹 Erasing...",
                fill="#ff6b81",
                font=("Segoe UI", 9, "bold"),
                anchor="w",
                tags="eraser_cursor",
            )

        # 7. Sleek Bottom-Left HUD Badge
        canvas_h = self.winfo_height() or 400
        hud_y = canvas_h - 15
        hud_x = 15

        if self._cursor_world is not None:
            c_x, c_y = self._cursor_world
            hud_text = f"📍 Cursor: X={c_x:.1f}, Y={c_y:.1f} mm  |  ⏱️ ~{self._est_time_str}  |  Bed: {self._bed_x:.0f}×{self._bed_y:.0f} mm"
        else:
            hud_text = f"⏱️ Est. Plot Time: ~{self._est_time_str}  |  Bed: {self._bed_x:.0f}×{self._bed_y:.0f} mm"

        self.create_rectangle(
            hud_x - 6, hud_y - 18, hud_x + 360, hud_y + 6,
            fill="#090d16",
            outline="#1e293b",
            width=1,
            tags="hud",
        )
        self.create_text(
            hud_x, hud_y - 6,
            text=hud_text,
            fill="#94a3b8",
            font=("Segoe UI", 9),
            anchor="w",
            tags="hud_text",
        )

    # ============================
    # ============================
    # Notebook Page Overlay
    # ============================
    def get_notebook_geometry(self) -> Optional[dict]:
        """Return computed notebook page geometry in world (mm) coordinates, or None."""
        if not self._notebook_enabled:
            return None

        c = self._notebook_cfg
        line_spacing = float(c.get("line_spacing", 8.0))
        left_margin = float(c.get("left_margin", 30.0))
        writable_w = float(c.get("writable_w", 175.0))
        writable_h = float(c.get("writable_h", 250.0))
        page_w = 210.0  # A4 width
        page_h = 297.0  # A4 height

        # Page margins (centering writable area on the A4 sheet)
        page_margin_lr = (page_w - writable_w) / 2.0  # ~17.5mm each side
        page_margin_tb = (page_h - writable_h) / 2.0  # ~23.5mm top/bottom

        align_mode = c.get("align_mode", "left_margin_at_zero")

        # Compute page and margin positions based on alignment mode
        if align_mode == "left_margin_at_zero":
            # Red margin touches the left edge of the build plate (X = 0)
            margin_x = float(c.get("margin_bed_x", 0.0))
            wr_x = margin_x - left_margin
            page_x = wr_x - page_margin_lr
        elif align_mode == "centered":
            page_x = (self._bed_x - page_w) / 2.0
            wr_x = page_x + page_margin_lr
            margin_x = wr_x + left_margin
        else:
            page_x = float(c.get("page_x", 0.0))
            wr_x = page_x + page_margin_lr
            margin_x = wr_x + left_margin

        # Compute page vertical position (top of page aligns with reachable top of bed by default)
        reach_max_y = max(10.0, self._bed_y - max(0.0, float(c.get("offset_y", self._offset_y))))
        page_y = float(c.get("page_y", -1.0))
        if page_y < -900 or page_y == -1.0:
            page_y = reach_max_y - page_h

        # Writable area in world coordinates
        wr_y_bottom = page_y + page_margin_tb
        wr_y_top = wr_y_bottom + writable_h

        # Ruled line Y positions (from top to bottom of writable area, in mm)
        num_lines = int(writable_h / line_spacing)
        line_ys = []
        for i in range(num_lines + 1):
            y = wr_y_top - i * line_spacing
            if y >= wr_y_bottom - 0.01:
                line_ys.append(y)

        return {
            "page_x": page_x, "page_y": page_y,
            "page_w": page_w, "page_h": page_h,
            "wr_x": wr_x, "wr_y_bottom": wr_y_bottom,
            "wr_y_top": wr_y_top, "writable_w": writable_w, "writable_h": writable_h,
            "margin_x": margin_x, "left_margin": left_margin,
            "line_spacing": line_spacing, "line_ys": line_ys,
            "num_lines": len(line_ys),
            "align_mode": align_mode,
        }

    def _render_notebook_overlay(self):
        """Draw the notebook page overlay: cream page, ruled lines, red margin, Date/Page box."""
        geo = self.get_notebook_geometry()
        if geo is None:
            return

        page_x = geo["page_x"]
        page_y = geo["page_y"]
        page_w = geo["page_w"]
        page_h = geo["page_h"]
        wr_x = geo["wr_x"]
        wr_y_bottom = geo["wr_y_bottom"]
        wr_y_top = geo["wr_y_top"]
        writable_w = geo["writable_w"]
        margin_x = geo["margin_x"]
        line_ys = geo["line_ys"]
        align_mode = geo.get("align_mode", "left_margin_at_zero")

        # A4 page rectangle (cream/off-white)
        p_x1, p_y1 = self._world_to_screen(page_x, page_y)
        p_x2, p_y2 = self._world_to_screen(page_x + page_w, page_y + page_h)
        self.create_rectangle(
            p_x1, p_y2, p_x2, p_y1,
            fill="#f5f0e8",
            outline="#a0a0a0",
            width=1.5,
            tags="notebook_page",
        )

        # Writable area boundary (subtle dashed)
        w_x1, w_y1 = self._world_to_screen(wr_x, wr_y_bottom)
        w_x2, w_y2 = self._world_to_screen(wr_x + writable_w, wr_y_top)
        self.create_rectangle(
            w_x1, w_y2, w_x2, w_y1,
            outline="#c0b8a8",
            dash=(3, 3),
            width=1.0,
            tags="notebook_writable",
        )

        # Top Header band: Double red lines at top of ruled area
        top_y1 = wr_y_top
        top_y2 = wr_y_top - 1.2
        tx1, ty1 = self._world_to_screen(wr_x, top_y1)
        tx2, _ = self._world_to_screen(wr_x + writable_w, top_y1)
        _, ty2 = self._world_to_screen(wr_x, top_y2)
        self.create_line(tx1, ty1, tx2, ty1, fill="#cc3333", width=1.5, tags="notebook_header_rule")
        self.create_line(tx1, ty2, tx2, ty2, fill="#cc3333", width=1.0, tags="notebook_header_rule")

        # Date / Page No. Box at top right
        date_box_w = 60.0
        date_box_h = 10.0
        db_x1 = wr_x + writable_w - date_box_w
        db_y_top = wr_y_top + 14.0
        db_y_bot = db_y_top - date_box_h
        ds_x1, ds_y1 = self._world_to_screen(db_x1, db_y_bot)
        ds_x2, ds_y2 = self._world_to_screen(db_x1 + date_box_w, db_y_top)
        self.create_rectangle(
            ds_x1, ds_y2, ds_x2, ds_y1,
            outline="#cc3333",
            width=1.0,
            fill="#faf7f0",
            tags="notebook_date_box",
        )
        self.create_text(
            ds_x1 + 4, ds_y2 + 3,
            text="Date: ___/___/___    Page: ___",
            fill="#882222",
            font=("Segoe UI", 7),
            anchor="nw",
            tags="notebook_date_text",
        )

        # Horizontal ruled lines (light blue #90b8d8)
        for y_mm in line_ys:
            lx1, ly1 = self._world_to_screen(wr_x, y_mm)
            lx2, ly2 = self._world_to_screen(wr_x + writable_w, y_mm)
            self.create_line(
                lx1, ly1, lx2, ly2,
                fill="#90b8d8",
                width=max(1, int(0.6 * self._zoom)),
                tags="notebook_rule",
            )

        # Bottom border line
        bx1, by1 = self._world_to_screen(wr_x, wr_y_bottom)
        bx2, _ = self._world_to_screen(wr_x + writable_w, wr_y_bottom)
        self.create_line(
            bx1, by1, bx2, by1,
            fill="#333333",
            width=1.2,
            tags="notebook_bottom_rule",
        )

        # Red vertical margin line
        mx, my_bot = self._world_to_screen(margin_x, wr_y_bottom)
        _, my_top = self._world_to_screen(margin_x, wr_y_top + 15.0)
        self.create_line(
            mx, my_top, mx, my_bot,
            fill="#cc3333",
            width=max(1, int(1.2 * self._zoom)),
            tags="notebook_margin",
        )

        # Page label (top-left)
        align_desc = "Red Margin at X=0 (Plate Border)" if align_mode == "left_margin_at_zero" else "Centered"
        label_sx, label_sy = self._world_to_screen(max(0.0, page_x + 3), page_y + page_h - 3)
        self.create_text(
            label_sx, label_sy,
            text=f"📄 A4 Ruled Register • {align_desc}",
            fill="#555577",
            font=("Segoe UI", 8, "bold"),
            anchor="nw",
            tags="notebook_label",
        )

    def _render_pcb_overlay(self):
        """Draw physical PCB blank copper board substrate on the print bed with rotation support."""
        if not self._pcb_enabled:
            return

        c = self._pcb_cfg
        bw = float(c.get("board_w", 70.0))
        bh = float(c.get("board_h", 50.0))
        bx = float(c.get("bed_x", 30.0))
        by = float(c.get("bed_y", 40.0))
        rot = float(c.get("rotation_deg", 0.0))

        if abs(rot) < 0.001:
            p_x1, p_y1 = self._world_to_screen(bx, by)
            p_x2, p_y2 = self._world_to_screen(bx + bw, by + bh)
            self.create_rectangle(
                p_x1, p_y2, p_x2, p_y1,
                fill="#78350f",
                outline="#f59e0b",
                width=2.0,
                tags="pcb_board",
            )
            lbl_x, lbl_y = self._world_to_screen(bx + 3, by + bh - 3)
        else:
            rad = math.radians(rot)
            cos_a = math.cos(rad)
            sin_a = math.sin(rad)
            cx = bx + bw / 2.0
            cy = by + bh / 2.0
            half_w = bw / 2.0
            half_h = bh / 2.0
            corners = [
                (-half_w, -half_h),
                (half_w, -half_h),
                (half_w, half_h),
                (-half_w, half_h),
            ]
            screen_pts = []
            for dx, dy in corners:
                rx = cx + dx * cos_a - dy * sin_a
                ry = cy + dx * sin_a + dy * cos_a
                sx, sy = self._world_to_screen(rx, ry)
                screen_pts.extend([sx, sy])

            self.create_polygon(
                screen_pts,
                fill="#78350f",
                outline="#f59e0b",
                width=2.0,
                tags="pcb_board",
            )
            lbl_x, lbl_y = self._world_to_screen(cx - half_w + 3, cy + half_h - 3)

        # Board dimension label
        rot_str = f" • {rot:.0f}°" if abs(rot) > 0.001 else ""
        self.create_text(
            lbl_x, lbl_y,
            text=f"⚡ Copper Clad ({bw:.1f} × {bh:.1f} mm{rot_str})",
            fill="#fef08a",
            font=("Segoe UI", 9, "bold"),
            anchor="nw",
            tags="pcb_label",
        )

    # ============================
    # Mouse & Event Handlers
    # ============================
    def _on_mouse_move(self, event):
        """Handle mouse hover — update coordinates and check if over item."""
        wx, wy = self._screen_to_world(event.x, event.y)
        self._cursor_world = (wx, wy)

        was_hovering = self._is_hovering_item
        self._is_hovering_item = self._is_inside_item(wx, wy)

        # Change cursor appearance
        if self._is_hovering_item or self._is_dragging_item:
            self.config(cursor="fleur")  # Move cursor
        else:
            self.config(cursor="arrow")

        # Notify callback
        if self._on_hover_callback:
            self._on_hover_callback(wx, wy, self._bbox)

        # Full re-render only if hover state flipped or actively erasing
        if was_hovering != self._is_hovering_item or self._is_erasing:
            self.render()
        else:
            self._update_hud_only()

    def _update_hud_only(self):
        """Update just the lightweight bottom-left HUD text without redrawing all toolpaths."""
        if self._cursor_world is not None:
            c_x, c_y = self._cursor_world
            hud_text = f"📍 Cursor: X={c_x:.1f}, Y={c_y:.1f} mm  |  ⏱️ ~{self._est_time_str}  |  Bed: {self._bed_x:.0f}×{self._bed_y:.0f} mm"
        else:
            hud_text = f"⏱️ Est. Plot Time: ~{self._est_time_str}  |  Bed: {self._bed_x:.0f}×{self._bed_y:.0f} mm"

        hud_items = self.find_withtag("hud_text")
        if hud_items:
            self.itemconfig(hud_items[0], text=hud_text)

    def _on_mouse_leave(self, event):
        """Handle mouse leaving canvas."""
        self._cursor_world = None
        self._is_hovering_item = False
        self.config(cursor="arrow")
        self.render()

    def _on_left_press(self, event):
        """Start dragging artwork on Left-Click."""
        wx, wy = self._screen_to_world(event.x, event.y)
        self._drag_item_start = (wx, wy)
        self._is_dragging_item = True
        self.config(cursor="fleur")

    def _on_left_drag(self, event):
        """Drag artwork across the print bed."""
        if not self._is_dragging_item or self._drag_item_start is None:
            return

        wx, wy = self._screen_to_world(event.x, event.y)
        dx = wx - self._drag_item_start[0]
        dy = wy - self._drag_item_start[1]
        self._drag_item_start = (wx, wy)

        if self._on_move_callback:
            self._on_move_callback(dx, dy, False)

    def _on_left_release(self, event):
        """Finish dragging artwork."""
        if self._is_dragging_item:
            self._is_dragging_item = False
            self._drag_item_start = None
            if self._on_move_callback:
                self._on_move_callback(0.0, 0.0, True)
            self._on_mouse_move(event)

    def _on_scroll(self, event):
        """Zoom with mouse wheel."""
        mx, my = event.x, event.y
        old_zoom = self._zoom

        if event.delta > 0:
            self._zoom *= 1.15
        else:
            self._zoom /= 1.15

        self._zoom = max(0.1, min(50.0, self._zoom))

        factor = self._zoom / old_zoom
        self._pan_x = mx - factor * (mx - self._pan_x)
        self._pan_y = my - factor * (my - self._pan_y)
        self._user_zoomed = True

        self.render()

    def _on_pan_start(self, event):
        """Start panning with middle/right click."""
        self._drag_pan_start = (event.x, event.y, self._pan_x, self._pan_y)
        self._user_zoomed = True

    def _on_pan_drag(self, event):
        """Pan while dragging with middle/right click."""
        if self._drag_pan_start is None:
            return
        dx = event.x - self._drag_pan_start[0]
        dy = event.y - self._drag_pan_start[1]
        self._pan_x = self._drag_pan_start[2] + dx
        self._pan_y = self._drag_pan_start[3] + dy
        self._user_zoomed = True
        self.render()

    def _on_double_click_reset(self, event):
        """Double-click to reset zoom & fit whole bed."""
        self._user_zoomed = False
        self._auto_fit()
        self.render()

    def _on_resize(self, event):
        """Handle window resize without wiping out user's zoom."""
        if not self._has_auto_fit and not self._user_zoomed:
            self._auto_fit()
            self._has_auto_fit = True
        self.render()

    # ============================
    # Manual Right-Click Eraser Tool
    # ============================
    def _on_right_press(self, event):
        """Start erasing strokes/dots on Right-Click."""
        self._is_erasing = True
        self._current_erase_batch = []
        self._erase_at(event.x, event.y)

    def _on_right_drag(self, event):
        """Erase strokes/dots while dragging Right Mouse Button."""
        if self._is_erasing:
            self._erase_at(event.x, event.y)

    def _on_right_release(self, event):
        """Finish erasing stroke batch."""
        self._is_erasing = False
        self._eraser_screen_pos = None
        if self._current_erase_batch:
            self._erased_history.append(self._current_erase_batch)
            self._current_erase_batch = []
            if self._on_erase_callback:
                self._on_erase_callback(self._draw_segments, len(self._erased_history))
        self.render()

    def _erase_at(self, screen_x: int, screen_y: int):
        """Erase segments within eraser radius of cursor."""
        wx, wy = self._screen_to_world(screen_x, screen_y)
        self._eraser_screen_pos = (screen_x, screen_y)
        r = self._eraser_radius_mm

        remaining = []
        erased_in_step = []

        for seg in self._draw_segments:
            x1, y1, x2, y2 = seg
            dx = x2 - x1
            dy = y2 - y1
            l2 = dx * dx + dy * dy
            if l2 < 1e-8:
                dist = math.hypot(wx - x1, wy - y1)
            else:
                t = max(0.0, min(1.0, ((wx - x1) * dx + (wy - y1) * dy) / l2))
                proj_x = x1 + t * dx
                proj_y = y1 + t * dy
                dist = math.hypot(wx - proj_x, wy - proj_y)

            if dist <= r:
                erased_in_step.append(seg)
            else:
                remaining.append(seg)

        if erased_in_step:
            self._draw_segments = remaining
            self._current_erase_batch.extend(erased_in_step)
            self._compute_bbox()
            self.render()

    def undo_erase(self) -> int:
        """Restore the most recently erased batch of strokes. Returns remaining undo steps."""
        if not self._erased_history:
            return 0
        last_batch = self._erased_history.pop()
        self._draw_segments.extend(last_batch)
        self._compute_bbox()
        self.render()
        if self._on_erase_callback:
            self._on_erase_callback(self._draw_segments, len(self._erased_history))
        return len(self._erased_history)

    def reset_erased(self):
        """Reset all erased strokes back to the original drawing."""
        if self._original_draw_segments:
            self._draw_segments = list(self._original_draw_segments)
            self._erased_history = []
            self._compute_bbox()
            self.render()
            if self._on_erase_callback:
                self._on_erase_callback(self._draw_segments, 0)

    def has_erased_segments(self) -> bool:
        """Return True if any strokes have been erased."""
        return len(self._erased_history) > 0

    def get_erased_count(self) -> int:
        """Return number of erased stroke batches."""
        return len(self._erased_history)

    def set_eraser_radius(self, radius_mm: float):
        """Set the radius of the eraser circle in millimeters."""
        self._eraser_radius_mm = max(0.5, float(radius_mm))

    def get_remaining_polylines(self) -> List[Polyline]:
        """Convert remaining unerased draw segments into joined polylines for G-code generation."""
        from gcode_engine import _join_connected_paths
        raw_lines = [[(s[0], s[1]), (s[2], s[3])] for s in self._draw_segments]
        return _join_connected_paths(raw_lines, tol=0.4)
