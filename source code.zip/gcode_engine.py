"""
gcode_engine.py — Core G-code generation engine for pen-plotter.

Handles configuration, G-code building, text rastering via Hershey vector fonts,
and generic polyline-to-gcode conversion for images and rendered fonts.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Tuple, Optional, Dict

from HersheyFonts import HersheyFonts

# Type alias: a single polyline is a list of (x, y) float pairs
Polyline = List[Tuple[float, float]]


# -----------------------------
# Configuration
# -----------------------------
@dataclass
class PlotterConfig:
    """All settings for G-code generation."""
    text: str = "hello world"
    start_x: float = 20.0
    start_y: float = 20.0
    scale: float = 4.0
    char_gap: float = 1.2
    word_gap: float = 2.4
    line_spacing: float = 1.8
    bed_x: float = 220.0
    bed_y: float = 220.0
    pen_touch_z: float = 0.0
    z_hop: float = 2.0
    travel_feed: int = 2500
    draw_feed: int = 1200
    output_file: str = "text_output.gcode"
    center_text: bool = True
    home_all: bool = True
    safe_lift_z: float = 30.0
    safe_wait_ms: int = 5000
    hershey_font: str = "futural"  # Hershey font name
    optimize_paths: bool = True    # Smart toolpath ordering & chaining
    offset_x: float = 0.0          # Pen Toolhead X offset (mm)
    offset_y: float = 0.0          # Pen Toolhead Y offset (mm) (e.g. front-mounted pen)
    offset_z: float = 0.0          # Pen Toolhead Z offset (mm)
    auto_wrap: bool = True         # Automatically wrap words to stay inside build/page area
    max_width: float = 0.0         # Max width in mm for auto-wrap (0.0 = auto-calculate from bed/page)

    @property
    def pen_up_z(self) -> float:
        return self.pen_touch_z + self.z_hop

    @property
    def effective_touch_z(self) -> float:
        return self.pen_touch_z + self.offset_z

    @property
    def effective_pen_up_z(self) -> float:
        return self.pen_touch_z + self.offset_z + self.z_hop

    @property
    def effective_safe_lift_z(self) -> float:
        return max(30.0, self.safe_lift_z) + self.offset_z

    @property
    def reachable_x_min(self) -> float:
        """Minimum reachable plate X coordinate for the pen without exceeding carriage limits."""
        return max(0.0, -self.offset_x)

    @property
    def reachable_x_max(self) -> float:
        """Maximum reachable plate X coordinate for the pen without exceeding carriage limits."""
        return max(0.0, self.bed_x - max(0.0, self.offset_x))

    @property
    def reachable_y_min(self) -> float:
        """Minimum reachable plate Y coordinate for the pen without exceeding carriage limits."""
        return max(0.0, -self.offset_y)

    @property
    def reachable_y_max(self) -> float:
        """Maximum reachable plate Y coordinate for the pen without exceeding carriage limits."""
        return max(0.0, self.bed_y - max(0.0, self.offset_y))

    @property
    def reachable_width(self) -> float:
        """Width of the reachable pen work envelope on the bed."""
        return max(0.0, self.reachable_x_max - self.reachable_x_min)

    @property
    def reachable_height(self) -> float:
        """Height of the reachable pen work envelope on the bed."""
        return max(0.0, self.reachable_y_max - self.reachable_y_min)

    def to_dict(self) -> dict:
        """Convert configuration to JSON-serializable dictionary."""
        return {
            "text": self.text,
            "start_x": self.start_x,
            "start_y": self.start_y,
            "scale": self.scale,
            "char_gap": self.char_gap,
            "word_gap": self.word_gap,
            "line_spacing": self.line_spacing,
            "bed_x": self.bed_x,
            "bed_y": self.bed_y,
            "pen_touch_z": self.pen_touch_z,
            "z_hop": self.z_hop,
            "travel_feed": self.travel_feed,
            "draw_feed": self.draw_feed,
            "output_file": self.output_file,
            "center_text": self.center_text,
            "home_all": self.home_all,
            "safe_lift_z": self.safe_lift_z,
            "safe_wait_ms": self.safe_wait_ms,
            "hershey_font": self.hershey_font,
            "optimize_paths": self.optimize_paths,
            "offset_x": self.offset_x,
            "offset_y": self.offset_y,
            "offset_z": self.offset_z,
            "auto_wrap": self.auto_wrap,
            "max_width": self.max_width,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "PlotterConfig":
        """Construct PlotterConfig from a dictionary (e.g. loaded from JSON)."""
        valid_keys = {
            "text", "start_x", "start_y", "scale", "char_gap", "word_gap", "line_spacing",
            "bed_x", "bed_y", "pen_touch_z", "z_hop", "travel_feed", "draw_feed",
            "output_file", "center_text", "home_all", "safe_lift_z", "safe_wait_ms",
            "hershey_font", "optimize_paths", "offset_x", "offset_y", "offset_z",
            "auto_wrap", "max_width",
        }
        filtered = {k: v for k, v in d.items() if k in valid_keys}
        return cls(**filtered)


# -----------------------------
# Hershey font rendering
# -----------------------------
# Available Hershey fonts with display names
HERSHEY_FONTS = {
    "futural":     "Sans Serif",
    "futuram":     "Sans Serif Bold",
    "rowmans":     "Serif",
    "rowmand":     "Serif Duplex",
    "rowmant":     "Serif Triplex",
    "timesr":      "Times Roman",
    "timesrb":     "Times Roman Bold",
    "timesi":      "Times Italic",
    "timesib":     "Times Italic Bold",
    "scripts":     "Script",
    "scriptc":     "Script Complex",
    "cursive":     "Cursive",
    "gothiceng":   "Gothic English",
    "gothicger":   "Gothic German",
    "gothicita":   "Gothic Italian",
    "greek":       "Greek",
    "cyrillic":    "Cyrillic",
}


_hershey_font_cache: Dict[str, HersheyFonts] = {}
_text_width_cache: Dict[Tuple[str, str, float], float] = {}


def _get_hershey_font(font_name: str = "futural") -> HersheyFonts:
    """Load and cache Hershey font objects to avoid disk re-reads."""
    global _hershey_font_cache
    if font_name not in _hershey_font_cache:
        hf = HersheyFonts()
        try:
            hf.load_default_font(font_name)
        except Exception:
            try:
                hf.load_default_font("futural")
            except Exception:
                pass
        hf.normalize_rendering(100)
        _hershey_font_cache[font_name] = hf
    return _hershey_font_cache[font_name]


def get_text_width_fast(text: str, font_name: str = "futural", height_mm: float = 8.0) -> float:
    """Fast cached measurement of text width."""
    if not text:
        return 0.0
    cache_key = (text, font_name, round(height_mm, 2))
    if cache_key in _text_width_cache:
        return _text_width_cache[cache_key]
    _, w, _ = hershey_text_to_polylines(text, font_name, height_mm)
    if len(_text_width_cache) < 2000:
        _text_width_cache[cache_key] = w
    return w


def hershey_text_to_polylines(
    text: str,
    font_name: str = "futural",
    height_mm: float = 10.0,
) -> Tuple[List[Polyline], float, float]:
    """
    Render a single line of text using Hershey vector font.
    Returns (polylines, total_width_mm, total_height_mm).

    Hershey fonts output Y=100 at top (cap height), Y=25 at baseline, Y=0 at descender.
    We normalize so total cap height = height_mm and Y increases upward (plotter coords).
    """
    hf = _get_hershey_font(font_name)
    hf.normalize_rendering(100)  # normalize to 100 units height

    raw_segments = list(hf.lines_for_text(text))
    if not raw_segments:
        return [], 0.0, 0.0

    # Find bounding box in Hershey coords
    all_x = []
    all_y = []
    for (x1, y1), (x2, y2) in raw_segments:
        all_x.extend([x1, x2])
        all_y.extend([y1, y2])

    if not all_x:
        return [], 0.0, 0.0

    min_x = min(all_x)
    max_x = max(all_x)
    min_y = min(all_y)
    max_y = max(all_y)

    hershey_height = max_y - min_y
    hershey_width = max_x - min_x

    if hershey_height <= 0:
        hershey_height = 100.0

    # Scale factor: map hershey units to mm
    scale = height_mm / hershey_height
    width_mm = hershey_width * scale

    # Group consecutive segments into polylines
    # Two segments are consecutive if seg[n].end == seg[n+1].start
    polylines = []
    current_poly = []

    for (x1, y1), (x2, y2) in raw_segments:
        # Convert to mm, shift to origin, Y already increases upward in Hershey
        mx1 = (x1 - min_x) * scale
        my1 = (y1 - min_y) * scale
        mx2 = (x2 - min_x) * scale
        my2 = (y2 - min_y) * scale

        if not current_poly:
            current_poly = [(mx1, my1), (mx2, my2)]
        elif abs(mx1 - current_poly[-1][0]) < 0.01 and abs(my1 - current_poly[-1][1]) < 0.01:
            # Continuous — append next point
            current_poly.append((mx2, my2))
        else:
            # Gap — start a new polyline
            if len(current_poly) >= 2:
                polylines.append(current_poly)
            current_poly = [(mx1, my1), (mx2, my2)]

    if len(current_poly) >= 2:
        polylines.append(current_poly)

    return polylines, width_mm, height_mm


def hershey_multiline_to_polylines(
    text: str,
    font_name: str = "futural",
    height_mm: float = 10.0,
    line_spacing_factor: float = 1.5,
) -> Tuple[List[Polyline], float, float]:
    """
    Render multi-line text (split by \\n) into polylines.
    Returns (polylines, total_width_mm, total_height_mm).
    """
    lines = text.split("\n")
    if not lines:
        return [], 0.0, 0.0

    all_polylines = []
    max_width = 0.0
    line_step = height_mm * line_spacing_factor

    for i, line in enumerate(lines):
        if not line.strip():
            continue
        polys, w, h = hershey_text_to_polylines(line, font_name, height_mm)
        y_offset = i * line_step
        # Shift each line down (in plotter coords, lower Y = closer to front)
        # We render top line at the highest Y, subsequent lines below
        for poly in polys:
            shifted = [(x, y - y_offset) for x, y in poly]
            all_polylines.append(shifted)
        max_width = max(max_width, w)

    total_height = height_mm + (len(lines) - 1) * line_step
    return all_polylines, max_width, total_height


def wrap_text_to_width(
    text: str,
    font_name: str = "futural",
    height_mm: float = 8.0,
    max_width_mm: float = 180.0,
) -> str:
    """
    Ultra-fast auto-wrap using cached text width calculations.
    Preserves user explicit newlines (\\n).
    If a single word exceeds max_width_mm, it breaks cleanly by character.
    """
    if not text or max_width_mm <= 5.0:
        return text

    paragraphs = text.split("\n")
    wrapped_paragraphs = []

    for para in paragraphs:
        if not para.strip():
            wrapped_paragraphs.append("")
            continue

        words = para.split(" ")
        lines = []
        cur_line = ""

        for word in words:
            if not word:
                continue

            test_line = word if not cur_line else (cur_line + " " + word)
            w = get_text_width_fast(test_line, font_name, height_mm)

            if w <= max_width_mm:
                cur_line = test_line
            else:
                if cur_line:
                    lines.append(cur_line)
                    w_single = get_text_width_fast(word, font_name, height_mm)
                    if w_single <= max_width_mm:
                        cur_line = word
                    else:
                        sub_word = ""
                        for char in word:
                            test_sub = sub_word + char
                            w_sub = get_text_width_fast(test_sub, font_name, height_mm)
                            if w_sub <= max_width_mm:
                                sub_word = test_sub
                            else:
                                if sub_word:
                                    lines.append(sub_word)
                                sub_word = char
                        cur_line = sub_word
                else:
                    sub_word = ""
                    for char in word:
                        test_sub = sub_word + char
                        w_sub = get_text_width_fast(test_sub, font_name, height_mm)
                        if w_sub <= max_width_mm:
                            sub_word = test_sub
                        else:
                            if sub_word:
                                lines.append(sub_word)
                            sub_word = char
                    cur_line = sub_word

        if cur_line:
            lines.append(cur_line)

        wrapped_paragraphs.append("\n".join(lines))

    return "\n".join(wrapped_paragraphs)


# Keep old name for backward compat (unused dict, but importable)
VECTOR_FONT = {}


# -----------------------------
# Utilities
# -----------------------------
def clamp(value: float, low: float, high: float) -> float:
    """Clamp value between low and high."""
    return min(max(value, low), high)


def safe_z_value(z: float, touch: float) -> float:
    """Ensure Z never goes below the pen touch plane (safety)."""
    return max(float(touch), float(z))


def estimate_text_size(
    text: str,
    scale: float,
    char_gap: float = 1.2,
    word_gap: float = 2.4,
    font_name: str = "futural",
) -> Tuple[float, float]:
    """
    Estimate the bounding box (width, height) of text rendered with Hershey font.
    scale = desired height in mm.
    """
    if not text.strip():
        return 0.0, 0.0

    _, width, height = hershey_text_to_polylines(text, font_name, scale)
    return width, height


def estimate_multiline_size(
    text: str,
    scale: float,
    char_gap: float = 1.2,
    word_gap: float = 2.4,
    line_spacing: float = 1.5,
    font_name: str = "futural",
) -> Tuple[float, float]:
    """Estimate bounding box for multi-line text."""
    if not text.strip():
        return 0.0, 0.0

    _, width, height = hershey_multiline_to_polylines(
        text, font_name, scale, line_spacing
    )
    return width, height


def anchor_center(cfg: PlotterConfig, text: Optional[str] = None) -> Tuple[float, float]:
    """Compute start position to center text within the reachable plate envelope."""
    active_text = text if text is not None else cfg.text
    if "\n" in active_text:
        tw, th = estimate_multiline_size(
            active_text, cfg.scale, cfg.char_gap, cfg.word_gap,
            cfg.line_spacing, cfg.hershey_font,
        )
    else:
        tw, th = estimate_text_size(
            active_text, cfg.scale, cfg.char_gap, cfg.word_gap, cfg.hershey_font,
        )

    # Center within reachable pen envelope rather than raw bed dimensions
    # to guarantee carriage coordinates (X+offset_x, Y+offset_y) never breach machine limits
    avail_w = cfg.reachable_width if cfg.reachable_width > 5.0 else cfg.bed_x
    avail_h = cfg.reachable_height if cfg.reachable_height > 5.0 else cfg.bed_y
    min_x = cfg.reachable_x_min
    min_y = cfg.reachable_y_min

    sx = min_x + max(0.0, (avail_w - tw) / 2.0)
    sy = min_y + max(0.0, (avail_h - th) / 2.0)
    return sx, sy


# -----------------------------
# Smart Toolpath Optimizer
# -----------------------------
def _simplify_collinear(poly: Polyline, tol: float = 0.01) -> Polyline:
    """Remove redundant collinear vertices along a polyline."""
    if len(poly) <= 2:
        return poly
    import math
    res = [poly[0]]
    for i in range(1, len(poly) - 1):
        x0, y0 = res[-1]
        x1, y1 = poly[i]
        x2, y2 = poly[i + 1]
        cross = abs((x1 - x0) * (y2 - y0) - (y1 - y0) * (x2 - x0))
        d = math.hypot(x2 - x0, y2 - y0)
        if d > 0 and (cross / d) < tol:
            continue
        res.append(poly[i])
    res.append(poly[-1])
    return res


def _cycle_closed_loop(poly: Polyline, cur_x: float, cur_y: float) -> Polyline:
    """Cycle closed polygon loop vertices so the starting vertex is closest to (cur_x, cur_y)."""
    if len(poly) < 3:
        return poly
    if abs(poly[0][0] - poly[-1][0]) > 0.01 or abs(poly[0][1] - poly[-1][1]) > 0.01:
        return poly

    pts = poly[:-1]
    best_idx = 0
    best_dist = float("inf")
    for i, (x, y) in enumerate(pts):
        d = (x - cur_x) ** 2 + (y - cur_y) ** 2
        if d < best_dist:
            best_dist = d
            best_idx = i

    if best_idx == 0:
        return poly

    cycled = pts[best_idx:] + pts[:best_idx]
    cycled.append(cycled[0])
    return cycled


def _join_connected_paths(paths: List[Polyline], tol: float = 0.4) -> List[Polyline]:
    """Join contiguous polylines that meet at endpoints to eliminate pen lifts."""
    import math
    if not paths:
        return []

    remaining = [list(p) for p in paths if len(p) >= 2]
    joined: List[Polyline] = []

    while remaining:
        curr = remaining.pop(0)
        extended = True
        while extended:
            extended = False
            for i, other in enumerate(remaining):
                # curr.end matches other.start
                if math.hypot(curr[-1][0] - other[0][0], curr[-1][1] - other[0][1]) < tol:
                    curr.extend(other[1:])
                    remaining.pop(i)
                    extended = True
                    break
                # curr.end matches other.end
                elif math.hypot(curr[-1][0] - other[-1][0], curr[-1][1] - other[-1][1]) < tol:
                    curr.extend(reversed(other[:-1]))
                    remaining.pop(i)
                    extended = True
                    break
                # curr.start matches other.end
                elif math.hypot(curr[0][0] - other[-1][0], curr[0][1] - other[-1][1]) < tol:
                    curr = other[:-1] + curr
                    remaining.pop(i)
                    extended = True
                    break
                # curr.start matches other.start
                elif math.hypot(curr[0][0] - other[0][0], curr[0][1] - other[0][1]) < tol:
                    curr = list(reversed(other[1:])) + curr
                    remaining.pop(i)
                    extended = True
                    break

        joined.append(_simplify_collinear(curr))

    return joined


def optimize_toolpath(
    paths: List[Polyline],
    start_pos: Tuple[float, float] = (0.0, 0.0),
    join_tolerance: float = 0.4,
    collinear_tolerance: float = 0.01,
) -> List[Polyline]:
    """
    Intelligent Toolpath Optimizer for Pen Plotters.

    Features:
      1. Collinear point simplification & duplicate removal.
      2. Connected stroke chaining (merges adjacent segments without pen lift).
      3. Bidirectional Nearest-Neighbor TSP reordering (minimizes rapid travel distance).
      4. Closed-loop entry point cycling (enters loops at the nearest vertex).
    """
    if not paths:
        return []

    # 1. Clean & simplify individual polylines
    cleaned = []
    for p in paths:
        if not p or len(p) < 2:
            continue
        dedup = [p[0]]
        for pt in p[1:]:
            if abs(pt[0] - dedup[-1][0]) > 0.001 or abs(pt[1] - dedup[-1][1]) > 0.001:
                dedup.append(pt)
        if len(dedup) >= 2:
            simplified = _simplify_collinear(dedup, collinear_tolerance)
            if len(simplified) >= 2:
                cleaned.append(simplified)

    if not cleaned:
        return []

    # 2. Join contiguous endpoints
    joined = _join_connected_paths(cleaned, join_tolerance)
    if not joined:
        return []

    # 3. Nearest-Neighbor TSP ordering with bidirectional entry
    cur_x, cur_y = start_pos
    remaining = [list(p) for p in joined]
    optimized: List[Polyline] = []

    while remaining:
        best_idx = 0
        best_dist = float("inf")
        best_flip = False
        best_is_closed = False

        for i, p in enumerate(remaining):
            is_closed = (abs(p[0][0] - p[-1][0]) < 0.01 and abs(p[0][1] - p[-1][1]) < 0.01)

            if is_closed:
                for vx, vy in p[:-1]:
                    d = (vx - cur_x) ** 2 + (vy - cur_y) ** 2
                    if d < best_dist:
                        best_dist = d
                        best_idx = i
                        best_flip = False
                        best_is_closed = True
            else:
                d_start = (p[0][0] - cur_x) ** 2 + (p[0][1] - cur_y) ** 2
                if d_start < best_dist:
                    best_dist = d_start
                    best_idx = i
                    best_flip = False
                    best_is_closed = False

                d_end = (p[-1][0] - cur_x) ** 2 + (p[-1][1] - cur_y) ** 2
                if d_end < best_dist:
                    best_dist = d_end
                    best_idx = i
                    best_flip = True
                    best_is_closed = False

        p = remaining.pop(best_idx)

        if best_is_closed:
            p = _cycle_closed_loop(p, cur_x, cur_y)
        elif best_flip:
            p = list(reversed(p))

        optimized.append(p)
        cur_x, cur_y = p[-1]

    # Verify that TSP optimization improved or matched sequential travel distance
    def _calc_travel_dist(pl):
        import math
        cx, cy = start_pos
        td = 0.0
        for p in pl:
            td += math.hypot(p[0][0] - cx, p[0][1] - cy)
            cx, cy = p[-1]
        return td

    tr_joined = _calc_travel_dist(joined)
    tr_opt = _calc_travel_dist(optimized)

    return optimized if tr_opt <= tr_joined else joined


# -----------------------------
# G-code builder
# -----------------------------
class GCodeBuilder:
    """Builds G-code commands for pen plotter moves."""

    def __init__(self, cfg: PlotterConfig):
        self.cfg = cfg
        self.lines: List[str] = []
        self.pen_down_state: bool = False
        # Track all draw/travel segments for preview
        self.draw_segments: List[Tuple[float, float, float, float]] = []
        self.travel_segments: List[Tuple[float, float, float, float]] = []
        self._last_x: float = 0.0
        self._last_y: float = 0.0

    def add(self, line: str):
        """Append a raw G-code line."""
        self.lines.append(line)

    def move_travel(self, x: float, y: float):
        """Rapid travel move (pen up) with machine limit safety clamping."""
        self.travel_segments.append((self._last_x, self._last_y, x, y))
        self._last_x, self._last_y = x, y
        raw_mx = x + self.cfg.offset_x
        raw_my = y + self.cfg.offset_y
        mx = clamp(raw_mx, 0.0, self.cfg.bed_x)
        my = clamp(raw_my, 0.0, self.cfg.bed_y)
        self.add(f"G0 X{mx:.3f} Y{my:.3f} F{self.cfg.travel_feed}")

    def move_draw(self, x: float, y: float):
        """Drawing move (pen down) with machine limit safety clamping."""
        self.draw_segments.append((self._last_x, self._last_y, x, y))
        self._last_x, self._last_y = x, y
        raw_mx = x + self.cfg.offset_x
        raw_my = y + self.cfg.offset_y
        mx = clamp(raw_mx, 0.0, self.cfg.bed_x)
        my = clamp(raw_my, 0.0, self.cfg.bed_y)
        self.add(f"G1 X{mx:.3f} Y{my:.3f} F{self.cfg.draw_feed}")

    def set_z(self, z: float, rapid: bool = True):
        """Move Z axis with safety clamping and toolhead Z offset."""
        safe = safe_z_value(z, self.cfg.pen_touch_z)
        mz = safe + self.cfg.offset_z
        cmd = "G0" if rapid else "G1"
        feed = self.cfg.travel_feed if rapid else self.cfg.draw_feed
        self.add(f"{cmd} Z{mz:.3f} F{feed}")

    def pen_up(self):
        """Lift pen."""
        self.set_z(self.cfg.pen_up_z, rapid=True)
        self.pen_down_state = False

    def pen_down(self):
        """Lower pen to drawing surface."""
        self.set_z(self.cfg.pen_touch_z, rapid=False)
        self.pen_down_state = True

    def lift_if_needed(self):
        """Lift pen only if currently down."""
        if self.pen_down_state:
            self.pen_up()

    def write_header(self):
        """Write G-code initialization header."""
        self.add("; Generated by G-Code Pen Plotter")
        self.add(f"; Pen Toolhead Offset: X={self.cfg.offset_x:+.2f} mm, Y={self.cfg.offset_y:+.2f} mm, Z={self.cfg.offset_z:+.2f} mm")
        self.add(f"; Pen touch Z: {self.cfg.pen_touch_z:.2f} mm (Machine Z: {self.cfg.effective_touch_z:.2f} mm)")
        self.add(f"; Pen up Z: {self.cfg.pen_up_z:.2f} mm (Machine Z: {self.cfg.effective_pen_up_z:.2f} mm)")
        self.add("G90 ; absolute positioning")
        self.add("M82 ; absolute extrusion mode")
        if self.cfg.home_all:
            self.add("G28 ; home all axes")
        safe_z = max(self.cfg.safe_lift_z, self.cfg.pen_touch_z + 10.0) + self.cfg.offset_z
        self.add(f"G0 Z{safe_z:.3f} F{self.cfg.travel_feed} ; safe clearance lift")
        if self.cfg.safe_wait_ms > 0:
            self.add(f"G4 P{self.cfg.safe_wait_ms} ; wait for safe clearance")
        self.pen_up()

    def write_footer(self, x_final: float, y_final: float):
        """Write G-code ending footer — lifts pen and moves Z to safe clearance."""
        self.pen_up()
        safe_z = max(30.0, self.cfg.safe_lift_z)
        self.set_z(safe_z, rapid=True)
        self.move_travel(x_final, y_final)
        self.add("M400 ; wait for moves to finish")
        self.add("M84 ; disable motors")

    def get_machine_bounds(self) -> Optional[Tuple[float, float, float, float]]:
        """
        Calculate bounding box in machine carriage coordinates (including X/Y offsets).
        Returns (min_x, min_y, max_x, max_y) or None if no moves.
        """
        all_x = []
        all_y = []
        for x1, y1, x2, y2 in self.draw_segments + self.travel_segments:
            all_x.extend([x1 + self.cfg.offset_x, x2 + self.cfg.offset_x])
            all_y.extend([y1 + self.cfg.offset_y, y2 + self.cfg.offset_y])
        if not all_x or not all_y:
            return None
        return (min(all_x), min(all_y), max(all_x), max(all_y))

    def estimate_time(self) -> Tuple[float, str, float, float]:
        """
        Estimate total plotting time in seconds, formatted string,
        and distances (draw_distance_mm, travel_distance_mm).
        
        Returns:
            (total_seconds, formatted_time_str, draw_distance_mm, travel_distance_mm)
        """
        import math

        # 1. Total drawing distance
        draw_dist = 0.0
        for x1, y1, x2, y2 in self.draw_segments:
            draw_dist += math.hypot(x2 - x1, y2 - y1)

        # 2. Total travel distance
        travel_dist = 0.0
        for x1, y1, x2, y2 in self.travel_segments:
            travel_dist += math.hypot(x2 - x1, y2 - y1)

        # Feedrates in mm/s (feedrates are in mm/min)
        draw_speed = max(1.0, self.cfg.draw_feed / 60.0)      # e.g. 1200 mm/min = 20 mm/s
        travel_speed = max(1.0, self.cfg.travel_feed / 60.0)  # e.g. 2500 mm/min = 41.67 mm/s

        # Realistic XY motion with segment acceleration overhead (~15ms per move)
        segment_overhead = 0.015
        xy_draw_time = (draw_dist / draw_speed) + len(self.draw_segments) * segment_overhead
        xy_travel_time = (travel_dist / travel_speed) + len(self.travel_segments) * segment_overhead

        # Pen Up/Down Z transitions
        z_dist_per_stroke = self.cfg.z_hop * 2
        z_speed = travel_speed / 2.0
        z_stroke_time = len(self.travel_segments) * (z_dist_per_stroke / z_speed + 0.05)

        # Startup time: homing + safe clearance dwell
        startup_time = 0.0
        if self.cfg.home_all:
            startup_time += 5.0  # homing
        startup_time += (self.cfg.safe_wait_ms / 1000.0)  # dwell
        startup_time += 1.0  # footer park

        total_seconds = xy_draw_time + xy_travel_time + z_stroke_time + startup_time

        # Format string
        total_secs_int = max(1, int(round(total_seconds)))
        if total_secs_int < 60:
            formatted = f"{total_secs_int}s"
        elif total_secs_int < 3600:
            mins = total_secs_int // 60
            secs = total_secs_int % 60
            formatted = f"{mins}m {secs:02d}s"
        else:
            hours = total_secs_int // 3600
            mins = (total_secs_int % 3600) // 60
            secs = total_secs_int % 60
            formatted = f"{hours}h {mins:02d}m {secs:02d}s"

        return total_seconds, formatted, draw_dist, travel_dist

    def raster_text(
        self, text: str, origin_x: float, origin_y: float
    ) -> Tuple[float, float]:
        """
        Raster text using Hershey vector fonts with instant linear rendering.
        Supports multi-line text (split by \\n).
        Returns (final_x, final_y).
        """
        font_name = self.cfg.hershey_font
        height_mm = self.cfg.scale

        if "\n" in text:
            polylines, total_w, total_h = hershey_multiline_to_polylines(
                text, font_name, height_mm, self.cfg.line_spacing,
            )
        else:
            polylines, total_w, total_h = hershey_text_to_polylines(
                text, font_name, height_mm,
            )

        if not polylines:
            return origin_x, origin_y

        # Raster text polylines directly in sequential reading order (instant, O(N))
        final_x, final_y = self.raster_paths(polylines, origin_x, origin_y, is_text=True)
        return final_x, final_y

    def raster_paths(
        self,
        paths: List[Polyline],
        offset_x: float = 0.0,
        offset_y: float = 0.0,
        is_text: bool = False,
    ) -> Tuple[float, float]:
        """
        Raster arbitrary polyline paths (from image contours, line art, or font rendering).
        Applies smart toolpath optimization for image paths.
        """
        if not paths:
            return offset_x, offset_y

        # 1. Apply offset to world coordinates
        shifted_paths = []
        for poly in paths:
            if not poly or len(poly) < 2:
                continue
            shifted_paths.append([(px + offset_x, py + offset_y) for px, py in poly])

        if not shifted_paths:
            return offset_x, offset_y

        # 2. Smart Path Optimization (skip for linear text to maintain reading order and instant speed)
        if self.cfg.optimize_paths and not is_text:
            effective_paths = optimize_toolpath(
                shifted_paths,
                start_pos=(self._last_x, self._last_y),
            )
        else:
            effective_paths = shifted_paths

        final_x, final_y = self._last_x, self._last_y

        # 3. Emit G-code moves
        for poly in effective_paths:
            if not poly or len(poly) < 2:
                continue

            sx, sy = poly[0]
            self.lift_if_needed()
            self.move_travel(sx, sy)
            self.pen_down()

            for tx, ty in poly[1:]:
                self.move_draw(tx, ty)
                final_x = max(final_x, tx)
                final_y = max(final_y, ty)

            self.lift_if_needed()

        return final_x, final_y


# -----------------------------
# Main generator
# -----------------------------
def generate_gcode_text(cfg: PlotterConfig) -> GCodeBuilder:
    """Generate G-code for text using Hershey vector fonts with auto-wrap and auto-scale support."""
    text_to_render = cfg.text
    active_scale = cfg.scale

    # Auto-wrap words so text stays inside build plate / page boundaries
    if cfg.auto_wrap and text_to_render:
        avail_reach_w = cfg.reachable_width if cfg.reachable_width > 5.0 else cfg.bed_x
        avail_reach_h = cfg.reachable_height if cfg.reachable_height > 5.0 else cfg.bed_y

        if cfg.max_width > 5.0:
            wrap_w = cfg.max_width
        elif cfg.center_text:
            wrap_w = max(30.0, avail_reach_w * 0.9)
        else:
            wrap_w = max(30.0, cfg.reachable_x_max - cfg.start_x - 10.0)

        # First pass wrap with current scale
        wrapped = wrap_text_to_width(
            text_to_render,
            font_name=cfg.hershey_font,
            height_mm=active_scale,
            max_width_mm=wrap_w,
        )

        # If auto-centering in normal bed mode, verify vertical fit and auto-scale if too tall
        if cfg.center_text and cfg.max_width <= 5.0:
            total_w, total_h = estimate_multiline_size(
                wrapped, active_scale, cfg.char_gap, cfg.word_gap,
                cfg.line_spacing, cfg.hershey_font,
            ) if "\n" in wrapped else estimate_text_size(
                wrapped, active_scale, cfg.char_gap, cfg.word_gap, cfg.hershey_font,
            )

            max_allowed_h = avail_reach_h * 0.88
            if total_h > max_allowed_h and total_h > 0.01:
                fit_scale = max(2.0, active_scale * (max_allowed_h / total_h))
                active_scale = fit_scale
                wrapped = wrap_text_to_width(
                    text_to_render,
                    font_name=cfg.hershey_font,
                    height_mm=active_scale,
                    max_width_mm=wrap_w,
                )

        text_to_render = wrapped

    orig_scale = cfg.scale
    cfg.scale = active_scale

    if cfg.center_text:
        cfg.start_x, cfg.start_y = anchor_center(cfg, text=text_to_render)

    writer = GCodeBuilder(cfg)
    writer.write_header()
    final_x, final_y = writer.raster_text(text_to_render, cfg.start_x, cfg.start_y)
    writer.write_footer(final_x, final_y)

    cfg.scale = orig_scale
    return writer


def generate_gcode_paths(
    cfg: PlotterConfig,
    paths: List[Polyline],
    offset_x: float = 0.0,
    offset_y: float = 0.0,
) -> GCodeBuilder:
    """Generate G-code from a list of polylines (image or font paths)."""
    writer = GCodeBuilder(cfg)
    writer.write_header()
    final_x, final_y = writer.raster_paths(paths, offset_x, offset_y)
    writer.write_footer(final_x, final_y)
    return writer


def save_gcode(cfg: PlotterConfig, writer: GCodeBuilder = None) -> int:
    """Save G-code to file. If no writer given, generates from text config."""
    if writer is None:
        writer = generate_gcode_text(cfg)
    Path(cfg.output_file).write_text("\n".join(writer.lines) + "\n", encoding="ascii")
    return len(writer.lines)


# Backward compatibility
def generate_gcode(cfg: PlotterConfig) -> List[str]:
    """Legacy API — returns list of G-code lines."""
    return generate_gcode_text(cfg).lines
