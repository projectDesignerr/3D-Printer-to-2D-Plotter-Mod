@echo off
echo =======================================================
echo Building Standalone Executable for G-Code Pen Plotter
echo =======================================================

call .\.venv\Scripts\activate.bat

python -m PyInstaller ^
    --noconfirm ^
    --onedir ^
    --windowed ^
    --name "GCodePlotter" ^
    --version-file "version_info.txt" ^
    --add-data "plotter_config.json;." ^
    --collect-all customtkinter ^
    --collect-all tkinterdnd2 ^
    --collect-all HersheyFonts ^
    main.py

echo.
echo Compressing to ZIP distribution...
powershell -Command "Compress-Archive -Path '.\dist\GCodePlotter' -DestinationPath '.\dist\GCodePlotter_v1.0_Windows_x64.zip' -Force"

echo.
echo =======================================================
echo Build complete!
echo Output folder: dist\GCodePlotter\
echo Executable:    dist\GCodePlotter\GCodePlotter.exe
echo ZIP Package:   dist\GCodePlotter_v1.0_Windows_x64.zip
echo =======================================================
pause
