"""
gui.py — Modern interactive GUI for the G-Code Pen Plotter.

Features:
  - Tabbed controls: Text Mode, Image Mode, and Dedicated Settings Page
  - Toolhead Offset Calibration (X, Y, Z offsets for front-mounted pens)
  - Bed bounds verification and out-of-bounds safety warnings
  - Live preview canvas with mm dimensions, hover inspection, and drag-and-drop plate positioning
  - Persistent settings storage via config_manager (plotter_config.json)
"""

import os
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox
from typing import Optional, Tuple, Dict, Any

import customtkinter as ctk

from gcode_engine import (
    PlotterConfig,
    GCodeBuilder,
    generate_gcode_text,
    generate_gcode_paths,
    save_gcode,
    HERSHEY_FONTS,
    estimate_text_size,
    estimate_multiline_size,
    anchor_center,
)
from preview import PreviewCanvas
import font_manager
import image_processor
import config_manager
import media_manager
import svg_processor


# -----------------------------
# Theme & appearance
# -----------------------------
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# Accent colors
ACCENT = "#00d4ff"
ACCENT_HOVER = "#00b8e6"
SURFACE = "#1e1e2e"
SURFACE_2 = "#252540"
TEXT_DIM = "#8888aa"
TEXT_MAIN = "#e2e8f0"


class PlotterGUI(ctk.CTk):
    """Main application window."""

    def __init__(self):
        super().__init__()

        self.title("G-Code Pen Plotter — Interactive Studio")
        self.geometry("1320x840")
        self.minsize(1020, 680)

        # Persistent config state
        self._config_data = config_manager.load_config()
        self._settings_entries: Dict[str, ctk.CTkEntry] = {}

        # App state
        self._last_active_tab = "✏️  Text"
        self._current_image_path: Optional[str] = None
        self._current_pcb_path: Optional[str] = None
        self._fonts_dict = {}
        self._generating = False
        self._preview_job = None
        self._last_builder: Optional[GCodeBuilder] = None

        # Build UI
        self._build_layout()
        self._load_fonts_async()

        # Connect preview callbacks
        self.preview.set_on_move_callback(self._on_preview_drag_move)
        self.preview.set_on_hover_callback(self._on_preview_hover)
        self.preview.set_on_erase_callback(self._on_preview_erase)

        # Bind Ctrl+Z for undo erase
        self.bind("<Control-z>", lambda e: self._on_undo_erase())
        self.bind("<Control-Z>", lambda e: self._on_undo_erase())

        # Setup drag-and-drop
        self._setup_dnd()

        # Handle window close with auto-save to JSON
        self.protocol("WM_DELETE_WINDOW", self._on_window_close)

        # Initial offset badges update & live preview
        self._update_offset_badges()
        self.after(200, self._queue_live_preview)

        # Removable media (SD card / USB) detection
        self._detected_removable_drives = []
        self._drive_scan_job = None
        self.after(500, self._check_removable_drives)

    # ============================
    # Layout
    # ============================
    def _build_layout(self):
        # Main horizontal split
        self.grid_columnconfigure(0, weight=0, minsize=440)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # --- Left Panel: Controls ---
        left_frame = ctk.CTkFrame(self, corner_radius=0, fg_color=SURFACE)
        left_frame.grid(row=0, column=0, sticky="nsew")
        left_frame.grid_rowconfigure(1, weight=1)
        left_frame.grid_columnconfigure(0, weight=1)

        # Title bar
        title_frame = ctk.CTkFrame(left_frame, fg_color="transparent", height=60)
        title_frame.grid(row=0, column=0, sticky="ew", padx=16, pady=(16, 4))
        title_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            title_frame,
            text="⚙  G-Code Plotter Studio",
            font=ctk.CTkFont(size=21, weight="bold"),
            text_color=ACCENT,
        ).grid(row=0, column=0, sticky="w")

        ctk.CTkLabel(
            title_frame,
            text="Drag on canvas to position  •  Hover for mm dimensions",
            font=ctk.CTkFont(size=11),
            text_color=TEXT_DIM,
        ).grid(row=1, column=0, sticky="w")

        # Scrollable controls area
        controls_scroll = ctk.CTkScrollableFrame(
            left_frame, fg_color="transparent", corner_radius=0,
        )
        controls_scroll.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        controls_scroll.grid_columnconfigure(0, weight=1)

        # Tabview (Text, Image, Settings)
        self.tabview = ctk.CTkTabview(
            controls_scroll,
            fg_color=SURFACE_2,
            segmented_button_fg_color=SURFACE,
            segmented_button_selected_color=ACCENT,
            segmented_button_selected_hover_color=ACCENT_HOVER,
            corner_radius=12,
            command=self._on_tab_change,
        )
        self.tabview.grid(row=0, column=0, sticky="ew", padx=8, pady=4)

        self.tab_text = self.tabview.add("✏️  Text")
        self.tab_image = self.tabview.add("🖼️  Image")
        self.tab_pcb = self.tabview.add("⚡ PCB")
        self.tab_settings = self.tabview.add("⚙️  Settings")

        self.tab_text.grid_columnconfigure(0, weight=1)
        self.tab_image.grid_columnconfigure(0, weight=1)
        self.tab_pcb.grid_columnconfigure(0, weight=1)
        self.tab_settings.grid_columnconfigure(0, weight=1)

        # Build individual tabs
        self._build_text_tab(self.tab_text)
        self._build_image_tab(self.tab_image)
        self._build_pcb_tab(self.tab_pcb)
        self._build_settings_tab(self.tab_settings)

        # Out-of-bounds warning banner (initially hidden)
        self.bounds_warning_frame = ctk.CTkFrame(
            controls_scroll, fg_color="#3d1414", corner_radius=8,
            border_color="#ff4757", border_width=1,
        )
        self.bounds_warning_frame.grid(row=1, column=0, sticky="ew", padx=10, pady=(4, 6))
        self.bounds_warning_frame.grid_columnconfigure(0, weight=1)
        self.bounds_warning_frame.grid_remove()

        self.bounds_warning_label = ctk.CTkLabel(
            self.bounds_warning_frame,
            text="",
            font=ctk.CTkFont(size=10, weight="bold"),
            text_color="#ff6b81",
            wraplength=380,
            justify="left",
        )
        self.bounds_warning_label.grid(row=0, column=0, padx=10, pady=6, sticky="w")

        # Generate and Removable Media action area
        btn_frame = ctk.CTkFrame(left_frame, fg_color="transparent")
        btn_frame.grid(row=2, column=0, sticky="ew", padx=16, pady=(4, 16))
        btn_frame.grid_columnconfigure(0, weight=1)
        btn_frame.grid_columnconfigure(1, weight=1)

        self.generate_btn = ctk.CTkButton(
            btn_frame,
            text="⚡  Generate File",
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=ACCENT,
            hover_color=ACCENT_HOVER,
            text_color="#0a0a1a",
            height=44,
            corner_radius=10,
            command=self._on_generate,
        )
        self.generate_btn.grid(row=0, column=0, sticky="ew", padx=(0, 4), pady=(4, 4))

        # Removable media sub-frame for button + optional eject icon
        rem_sub = ctk.CTkFrame(btn_frame, fg_color="transparent")
        rem_sub.grid(row=0, column=1, sticky="ew", padx=(4, 0), pady=(4, 4))
        rem_sub.grid_columnconfigure(0, weight=1)

        self.removable_btn = ctk.CTkButton(
            rem_sub,
            text="💾  Save to SD / USB",
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color="#2ed573",
            hover_color="#26af5f",
            text_color="#0a0a1a",
            height=44,
            corner_radius=10,
            command=self._on_save_to_removable,
        )
        self.removable_btn.grid(row=0, column=0, sticky="ew")

        self.eject_btn = ctk.CTkButton(
            rem_sub,
            text="⏏️",
            width=36,
            height=44,
            font=ctk.CTkFont(size=14),
            fg_color=SURFACE_2,
            hover_color="#ff4757",
            corner_radius=10,
            command=self._on_eject_removable,
        )
        # Eject button initially hidden, shown when removable media is detected
        self.eject_btn.grid_remove()

        self.status_label = ctk.CTkLabel(
            btn_frame,
            text="Ready • Live preview active",
            font=ctk.CTkFont(size=11),
            text_color=TEXT_DIM,
        )
        self.status_label.grid(row=1, column=0, columnspan=2, sticky="w", pady=(2, 0))

        # --- Right Panel: Preview ---
        right_frame = ctk.CTkFrame(self, corner_radius=0, fg_color="#0d0d1a")
        right_frame.grid(row=0, column=1, sticky="nsew")
        right_frame.grid_rowconfigure(0, weight=0)
        right_frame.grid_rowconfigure(1, weight=1)
        right_frame.grid_columnconfigure(0, weight=1)

        # Preview header
        prev_header = ctk.CTkFrame(right_frame, fg_color="transparent", height=40)
        prev_header.grid(row=0, column=0, sticky="ew", padx=16, pady=(12, 0))
        prev_header.grid_columnconfigure(0, weight=0)
        prev_header.grid_columnconfigure(1, weight=1)
        prev_header.grid_columnconfigure(2, weight=0)

        left_title_frame = ctk.CTkFrame(prev_header, fg_color="transparent")
        left_title_frame.grid(row=0, column=0, sticky="w")

        ctk.CTkLabel(
            left_title_frame,
            text="Build Plate Preview",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color="#ccccee",
        ).pack(side="left")

        ctk.CTkLabel(
            left_title_frame,
            text="  •  🧹 Right-Click to Erase dots/lines",
            font=ctk.CTkFont(size=11),
            text_color="#ff6b81",
        ).pack(side="left", padx=(4, 0))

        # Undo / Reset Erase Actions Frame
        erase_btn_frame = ctk.CTkFrame(prev_header, fg_color="transparent")
        erase_btn_frame.grid(row=0, column=2, sticky="e")

        self.undo_erase_btn = ctk.CTkButton(
            erase_btn_frame,
            text="↩️ Undo Erase",
            width=90,
            height=26,
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color=SURFACE,
            hover_color="#3a3a5c",
            text_color="#ccccee",
            corner_radius=6,
            command=self._on_undo_erase,
            state="disabled",
        )
        self.undo_erase_btn.pack(side="left", padx=(0, 6))

        self.reset_erase_btn = ctk.CTkButton(
            erase_btn_frame,
            text="🔄 Reset",
            width=65,
            height=26,
            font=ctk.CTkFont(size=11),
            fg_color=SURFACE,
            hover_color="#ff4757",
            text_color=TEXT_DIM,
            corner_radius=6,
            command=self._on_reset_erase,
            state="disabled",
        )
        self.reset_erase_btn.pack(side="left")

        self.stats_label = ctk.CTkLabel(
            right_frame,
            text="",
            font=ctk.CTkFont(size=11),
            text_color=TEXT_DIM,
        )
        self.stats_label.grid(row=0, column=0, sticky="e", padx=16, pady=(12, 0))

        # Preview canvas
        preview_frame = ctk.CTkFrame(right_frame, fg_color="transparent")
        preview_frame.grid(row=1, column=0, sticky="nsew", padx=12, pady=12)
        preview_frame.grid_rowconfigure(0, weight=1)
        preview_frame.grid_columnconfigure(0, weight=1)

        self.preview = PreviewCanvas(preview_frame)
        self.preview.grid(row=0, column=0, sticky="nsew")

    # ============================
    # Text Tab
    # ============================
    def _build_text_tab(self, parent):
        row = 0

        # Active offset badge
        self.text_offset_badge = ctk.CTkLabel(
            parent,
            text="🎯 Pen Offset: X=+0.0, Y=+0.0, Z=+0.0 mm  •  ⚙️ Settings",
            font=ctk.CTkFont(size=10),
            text_color="#ffb86c",
        )
        self.text_offset_badge.grid(row=row, column=0, sticky="w", padx=8, pady=(4, 2))
        row += 1

        # ── 📄 Notebook Page Mode Card ──
        nb_cfg = self._config_data
        notebook_card = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10, border_color="#3a3a5c", border_width=1)
        notebook_card.grid(row=row, column=0, sticky="ew", padx=8, pady=(4, 6))
        notebook_card.grid_columnconfigure(0, weight=1)
        row += 1

        # Enable switch
        nb_header = ctk.CTkFrame(notebook_card, fg_color="transparent")
        nb_header.grid(row=0, column=0, sticky="ew", padx=10, pady=(8, 4))
        nb_header.grid_columnconfigure(0, weight=1)

        self.notebook_enabled_var = ctk.BooleanVar(value=bool(nb_cfg.get("notebook_enabled", False)))
        self.notebook_switch = ctk.CTkSwitch(
            nb_header, text="📄  Notebook Page Mode (A4 Ruled Register)",
            variable=self.notebook_enabled_var,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=SURFACE_2, progress_color=ACCENT,
            command=self._on_notebook_toggle,
        )
        self.notebook_switch.grid(row=0, column=0, sticky="w")

        # Expandable details panel (shown when enabled)
        self._notebook_details = ctk.CTkFrame(notebook_card, fg_color="transparent")
        self._notebook_details.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 8))
        self._notebook_details.grid_columnconfigure((0, 1), weight=1)

        ctk.CTkLabel(
            self._notebook_details,
            text="Indian A4 school register • 8mm ruled lines • Date/Page header band",
            font=ctk.CTkFont(size=10), text_color=TEXT_DIM,
        ).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 4))

        nb_entries = {}

        # Alignment Mode: Red Margin at X=0 vs Centered
        align_frame = ctk.CTkFrame(self._notebook_details, fg_color="transparent")
        align_frame.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 4))
        align_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(align_frame, text="Paper Bed Alignment", text_color=TEXT_DIM, font=ctk.CTkFont(size=10, weight="bold")).grid(row=0, column=0, sticky="w")
        
        self.notebook_align_var = ctk.StringVar(
            value="📌 Red Margin at X=0 (Left Border)" if nb_cfg.get("notebook_align_mode", "left_margin_at_zero") == "left_margin_at_zero" else "📐 Centered A4 Page"
        )
        self.notebook_align_combo = ctk.CTkSegmentedButton(
            align_frame,
            values=["📌 Red Margin at X=0 (Left Border)", "📐 Centered A4 Page"],
            variable=self.notebook_align_var,
            selected_color=ACCENT,
            selected_hover_color=ACCENT_HOVER,
            command=lambda _: self._on_notebook_param_changed(),
        )
        self.notebook_align_combo.grid(row=1, column=0, sticky="ew", pady=(2, 4))

        # Margin X on Bed & Line Spacing
        mbx_frame = ctk.CTkFrame(self._notebook_details, fg_color="transparent")
        mbx_frame.grid(row=2, column=0, sticky="ew", padx=(0, 4))
        mbx_frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(mbx_frame, text="Margin X on Bed (mm)", text_color=TEXT_DIM, font=ctk.CTkFont(size=10)).grid(row=0, column=0, sticky="w")
        e_mbx = ctk.CTkEntry(mbx_frame, fg_color=SURFACE_2, corner_radius=6, font=ctk.CTkFont(size=11), width=70)
        e_mbx.insert(0, str(nb_cfg.get("notebook_margin_bed_x", 0.0)))
        e_mbx.grid(row=1, column=0, sticky="ew", pady=(2, 4))
        e_mbx.bind("<KeyRelease>", lambda _: self._on_notebook_param_changed())
        nb_entries["margin_bed_x"] = e_mbx

        ls_frame = ctk.CTkFrame(self._notebook_details, fg_color="transparent")
        ls_frame.grid(row=2, column=1, sticky="ew", padx=(4, 0))
        ls_frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(ls_frame, text="Line Spacing (mm)", text_color=TEXT_DIM, font=ctk.CTkFont(size=10)).grid(row=0, column=0, sticky="w")
        e_ls = ctk.CTkEntry(ls_frame, fg_color=SURFACE_2, corner_radius=6, font=ctk.CTkFont(size=11), width=70)
        e_ls.insert(0, str(nb_cfg.get("notebook_line_spacing", 8.0)))
        e_ls.grid(row=1, column=0, sticky="ew", pady=(2, 4))
        e_ls.bind("<KeyRelease>", lambda _: self._on_notebook_param_changed())
        nb_entries["line_spacing"] = e_ls

        # Left Margin Width & Writable Width
        lm_frame = ctk.CTkFrame(self._notebook_details, fg_color="transparent")
        lm_frame.grid(row=3, column=0, sticky="ew", padx=(0, 4))
        lm_frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(lm_frame, text="Left Margin Width (mm)", text_color=TEXT_DIM, font=ctk.CTkFont(size=10)).grid(row=0, column=0, sticky="w")
        e_lm = ctk.CTkEntry(lm_frame, fg_color=SURFACE_2, corner_radius=6, font=ctk.CTkFont(size=11), width=70)
        e_lm.insert(0, str(nb_cfg.get("notebook_left_margin", 30.0)))
        e_lm.grid(row=1, column=0, sticky="ew", pady=(2, 4))
        e_lm.bind("<KeyRelease>", lambda _: self._on_notebook_param_changed())
        nb_entries["left_margin"] = e_lm

        ww_frame = ctk.CTkFrame(self._notebook_details, fg_color="transparent")
        ww_frame.grid(row=3, column=1, sticky="ew", padx=(4, 0))
        ww_frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(ww_frame, text="Writable Width (mm)", text_color=TEXT_DIM, font=ctk.CTkFont(size=10)).grid(row=0, column=0, sticky="w")
        e_ww = ctk.CTkEntry(ww_frame, fg_color=SURFACE_2, corner_radius=6, font=ctk.CTkFont(size=11), width=70)
        e_ww.insert(0, str(nb_cfg.get("notebook_writable_w", 175.0)))
        e_ww.grid(row=1, column=0, sticky="ew", pady=(2, 4))
        e_ww.bind("<KeyRelease>", lambda _: self._on_notebook_param_changed())
        nb_entries["writable_w"] = e_ww

        # Writable Height & Start Line #
        wh_frame = ctk.CTkFrame(self._notebook_details, fg_color="transparent")
        wh_frame.grid(row=4, column=0, sticky="ew", padx=(0, 4))
        wh_frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(wh_frame, text="Writable Height (mm)", text_color=TEXT_DIM, font=ctk.CTkFont(size=10)).grid(row=0, column=0, sticky="w")
        e_wh = ctk.CTkEntry(wh_frame, fg_color=SURFACE_2, corner_radius=6, font=ctk.CTkFont(size=11), width=70)
        e_wh.insert(0, str(nb_cfg.get("notebook_writable_h", 250.0)))
        e_wh.grid(row=1, column=0, sticky="ew", pady=(2, 4))
        e_wh.bind("<KeyRelease>", lambda _: self._on_notebook_param_changed())
        nb_entries["writable_h"] = e_wh

        sl_frame = ctk.CTkFrame(self._notebook_details, fg_color="transparent")
        sl_frame.grid(row=4, column=1, sticky="ew", padx=(4, 0))
        sl_frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(sl_frame, text="Start at Line #", text_color=TEXT_DIM, font=ctk.CTkFont(size=10)).grid(row=0, column=0, sticky="w")
        e_sl = ctk.CTkEntry(sl_frame, fg_color=SURFACE_2, corner_radius=6, font=ctk.CTkFont(size=11), width=70)
        e_sl.insert(0, str(nb_cfg.get("notebook_start_line", 1)))
        e_sl.grid(row=1, column=0, sticky="ew", pady=(2, 4))
        e_sl.bind("<KeyRelease>", lambda _: self._on_notebook_param_changed())
        nb_entries["start_line"] = e_sl

        self._notebook_entries = nb_entries

        # Initially show/hide based on enabled state
        if not self.notebook_enabled_var.get():
            self._notebook_details.grid_remove()


        # Font mode selector — restore from saved config
        saved_font_mode = str(self._config_data.get("font_mode", "vector"))
        self._font_mode_var = ctk.StringVar(value=saved_font_mode)
        ctk.CTkLabel(parent, text="Font Mode", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=row, column=0, sticky="w", padx=8, pady=(6, 2)
        )
        row += 1

        mode_frame = ctk.CTkFrame(parent, fg_color="transparent")
        mode_frame.grid(row=row, column=0, sticky="ew", padx=8, pady=(0, 6))
        mode_frame.grid_columnconfigure((0, 1), weight=1)

        self.radio_vector = ctk.CTkRadioButton(
            mode_frame, text="Hershey Single-Stroke", variable=self._font_mode_var,
            value="vector", command=self._on_font_mode_change,
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
        )
        self.radio_vector.grid(row=0, column=0, sticky="w")

        self.radio_system = ctk.CTkRadioButton(
            mode_frame, text="System Font (TTF)", variable=self._font_mode_var,
            value="system", command=self._on_font_mode_change,
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
        )
        self.radio_system.grid(row=0, column=1, sticky="w")
        row += 1

        # Hershey font selector
        self._hershey_frame = ctk.CTkFrame(parent, fg_color="transparent")
        self._hershey_frame.grid(row=row, column=0, sticky="ew", padx=8, pady=(0, 6))
        self._hershey_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            self._hershey_frame, text="Hershey Style",
            text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        ).grid(row=0, column=0, sticky="w", pady=(0, 2))

        hershey_display = [f"{v}  ({k})" for k, v in HERSHEY_FONTS.items()]
        self._hershey_keys = list(HERSHEY_FONTS.keys())
        self.hershey_combo = ctk.CTkComboBox(
            self._hershey_frame,
            values=hershey_display,
            corner_radius=8,
            fg_color=SURFACE,
            border_color=SURFACE_2,
            button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
            state="readonly",
            command=lambda _: self._queue_live_preview(),
        )
        # Restore saved hershey font selection
        saved_hershey = str(self._config_data.get("hershey_font", "futural"))
        saved_idx = 0
        if saved_hershey in self._hershey_keys:
            saved_idx = self._hershey_keys.index(saved_hershey)
        self.hershey_combo.set(hershey_display[saved_idx])
        self.hershey_combo.grid(row=1, column=0, sticky="ew", pady=(0, 4))
        row += 1

        # Text input
        ctk.CTkLabel(parent, text="Text to Write", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=row, column=0, sticky="w", padx=8, pady=(4, 2)
        )
        row += 1

        self.text_input = ctk.CTkTextbox(
            parent, height=80, corner_radius=8, fg_color=SURFACE,
            font=ctk.CTkFont(size=13),
        )
        self.text_input.grid(row=row, column=0, sticky="ew", padx=8, pady=(0, 6))
        self.text_input.insert("1.0", str(self._config_data.get("default_text", "Hello World")))
        self.text_input.bind("<KeyRelease>", lambda _: self._queue_live_preview(delay_ms=120))
        row += 1

        # System font controls (initially hidden)
        self._font_controls_frame = ctk.CTkFrame(parent, fg_color="transparent")
        self._font_controls_frame.grid(row=row, column=0, sticky="ew", padx=8, pady=(0, 6))
        self._font_controls_frame.grid_columnconfigure(0, weight=1)
        row += 1

        ctk.CTkLabel(
            self._font_controls_frame, text="System Font", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        ).grid(row=0, column=0, sticky="w", pady=(0, 2))

        self.font_combo = ctk.CTkComboBox(
            self._font_controls_frame,
            values=["Loading fonts..."],
            corner_radius=8,
            fg_color=SURFACE,
            border_color=SURFACE_2,
            button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
            state="readonly",
            command=lambda _: self._queue_live_preview(),
        )
        self.font_combo.grid(row=1, column=0, sticky="ew", pady=(0, 4))

        ctk.CTkLabel(
            self._font_controls_frame, text="Font Size (render quality)",
            text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        ).grid(row=2, column=0, sticky="w", pady=(4, 2))

        self.font_size_slider = ctk.CTkSlider(
            self._font_controls_frame, from_=20, to=200, number_of_steps=18,
            fg_color=SURFACE, progress_color=ACCENT, button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
        )
        self.font_size_slider.set(80)
        self.font_size_slider.grid(row=3, column=0, sticky="ew", pady=(0, 2))

        self.font_size_label = ctk.CTkLabel(
            self._font_controls_frame, text="80 px", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        )
        self.font_size_label.grid(row=3, column=0, sticky="e", padx=(0, 4))
        self.font_size_slider.configure(command=self._on_font_size_change)

        ctk.CTkLabel(
            self._font_controls_frame, text="Fill Mode",
            text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        ).grid(row=4, column=0, sticky="w", pady=(4, 2))

        self.font_fill_var = ctk.StringVar(value="contour")
        self.font_fill_combo = ctk.CTkComboBox(
            self._font_controls_frame,
            values=["contour", "hatch", "both"],
            variable=self.font_fill_var,
            corner_radius=8,
            fg_color=SURFACE,
            border_color=SURFACE_2,
            button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
            state="readonly",
            command=lambda _: self._queue_live_preview(),
        )
        self.font_fill_combo.grid(row=5, column=0, sticky="ew", pady=(0, 4))

        # Show/hide font frames based on saved font mode
        if saved_font_mode == "system":
            self._hershey_frame.grid_remove()
        else:
            self._font_controls_frame.grid_remove()

        # Text Scale (Height in mm)
        ctk.CTkLabel(parent, text="Text Height / Scale (mm)", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=row, column=0, sticky="w", padx=8, pady=(4, 2)
        )
        row += 1

        self.text_scale_slider = ctk.CTkSlider(
            parent, from_=2, to=60, number_of_steps=58,
            fg_color=SURFACE, progress_color=ACCENT, button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
        )
        default_scale = float(self._config_data.get("default_scale", 8.0))
        self.text_scale_slider.set(default_scale)
        self.text_scale_slider.grid(row=row, column=0, sticky="ew", padx=8, pady=(0, 2))

        self.text_scale_label = ctk.CTkLabel(
            parent, text=f"{default_scale:.1f} mm", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        )
        self.text_scale_label.grid(row=row, column=0, sticky="e", padx=(0, 16))
        self.text_scale_slider.configure(command=self._on_text_scale_change)
        row += 1

        # Position Controls
        pos_frame = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10)
        pos_frame.grid(row=row, column=0, sticky="ew", padx=8, pady=(8, 8))
        pos_frame.grid_columnconfigure(0, weight=1)
        row += 1

        # Checkboxes row: Center on bed + Auto-wrap
        chk_box = ctk.CTkFrame(pos_frame, fg_color="transparent")
        chk_box.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 6))
        chk_box.grid_columnconfigure((0, 1), weight=1)

        self.center_var = ctk.BooleanVar(value=bool(self._config_data.get("center_on_bed", True)))
        self.center_check = ctk.CTkCheckBox(
            chk_box, text="Center on bed", variable=self.center_var,
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
            command=self._on_center_toggle,
        )
        self.center_check.grid(row=0, column=0, sticky="w")

        self.auto_wrap_var = ctk.BooleanVar(value=bool(self._config_data.get("auto_wrap", True)))
        self.auto_wrap_check = ctk.CTkCheckBox(
            chk_box, text="🔄 Auto-wrap to area", variable=self.auto_wrap_var,
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
            command=lambda: self._queue_live_preview(),
        )
        self.auto_wrap_check.grid(row=0, column=1, sticky="w")

        # Position X slider
        ctk.CTkLabel(pos_frame, text="Position X on Plate (mm)", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=1, column=0, sticky="w", padx=10, pady=(2, 0)
        )
        self.text_x_slider = ctk.CTkSlider(
            pos_frame, from_=0, to=float(self._config_data.get("bed_x", 220.0)), number_of_steps=220,
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
        )
        self.text_x_slider.set(float(self._config_data.get("text_start_x", 30.0)))
        self.text_x_slider.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 2))

        _init_x = float(self._config_data.get("text_start_x", 30.0))
        self.text_x_label = ctk.CTkLabel(
            pos_frame, text=f"{_init_x:.1f} mm", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        )
        self.text_x_label.grid(row=1, column=0, sticky="e", padx=(0, 14))
        self.text_x_slider.configure(command=self._on_text_x_change)

        # Position Y slider
        ctk.CTkLabel(pos_frame, text="Position Y on Plate (mm)", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=3, column=0, sticky="w", padx=10, pady=(2, 0)
        )
        self.text_y_slider = ctk.CTkSlider(
            pos_frame, from_=0, to=float(self._config_data.get("bed_y", 220.0)), number_of_steps=220,
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
        )
        self.text_y_slider.set(float(self._config_data.get("text_start_y", 100.0)))
        self.text_y_slider.grid(row=4, column=0, sticky="ew", padx=10, pady=(0, 8))

        _init_y = float(self._config_data.get("text_start_y", 100.0))
        self.text_y_label = ctk.CTkLabel(
            pos_frame, text=f"{_init_y:.1f} mm", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        )
        self.text_y_label.grid(row=3, column=0, sticky="e", padx=(0, 14))
        self.text_y_slider.configure(command=self._on_text_y_change)

    # ============================
    # Image Tab
    # ============================
    def _build_image_tab(self, parent):
        row = 0

        # Active offset badge
        self.img_offset_badge = ctk.CTkLabel(
            parent,
            text="🎯 Pen Offset: X=+0.0, Y=+0.0, Z=+0.0 mm  •  ⚙️ Settings",
            font=ctk.CTkFont(size=10),
            text_color="#ffb86c",
        )
        self.img_offset_badge.grid(row=row, column=0, sticky="w", padx=8, pady=(4, 2))
        row += 1

        # Drop zone
        self.drop_zone = ctk.CTkFrame(
            parent, height=100, corner_radius=12,
            fg_color=SURFACE, border_color=SURFACE_2, border_width=2,
        )
        self.drop_zone.grid(row=row, column=0, sticky="ew", padx=8, pady=6)
        self.drop_zone.grid_rowconfigure(0, weight=1)
        self.drop_zone.grid_columnconfigure(0, weight=1)

        self.drop_label = ctk.CTkLabel(
            self.drop_zone,
            text="🖼️  Drag & drop an image here\nor click Browse",
            font=ctk.CTkFont(size=13),
            text_color=TEXT_DIM,
            justify="center",
        )
        self.drop_label.grid(row=0, column=0, padx=16, pady=10)

        self.browse_btn = ctk.CTkButton(
            self.drop_zone, text="Browse Image...", width=120,
            fg_color=SURFACE_2, hover_color="#3a3a5c",
            corner_radius=8, height=30,
            command=self._on_browse_image,
        )
        self.browse_btn.grid(row=1, column=0, pady=(0, 10))
        row += 1

        # Image info label
        self.image_info_label = ctk.CTkLabel(
            parent, text="", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        )
        self.image_info_label.grid(row=row, column=0, sticky="w", padx=8, pady=(0, 4))
        row += 1

        # Threshold
        ctk.CTkLabel(parent, text="Threshold (Black/White Cutoff)", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=row, column=0, sticky="w", padx=8, pady=(4, 2)
        )
        row += 1

        self.threshold_slider = ctk.CTkSlider(
            parent, from_=0, to=255, number_of_steps=255,
            fg_color=SURFACE, progress_color=ACCENT, button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
        )
        self.threshold_slider.set(128)
        self.threshold_slider.grid(row=row, column=0, sticky="ew", padx=8, pady=(0, 2))

        self.threshold_label = ctk.CTkLabel(
            parent, text="128", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        )
        self.threshold_label.grid(row=row, column=0, sticky="e", padx=(0, 16))
        self.threshold_slider.configure(command=self._on_threshold_change)
        row += 1

        # ── ✍️ Signature Mode (Single Stroke) Switch ──
        sig_frame = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10, border_color="#3a3a5c", border_width=1)
        sig_frame.grid(row=row, column=0, sticky="ew", padx=8, pady=(4, 6))
        sig_frame.grid_columnconfigure(0, weight=1)
        row += 1

        self.signature_mode_var = ctk.BooleanVar(value=False)
        self.signature_switch = ctk.CTkSwitch(
            sig_frame,
            text="✍️  Signature Mode (Single-Stroke Centerline)",
            variable=self.signature_mode_var,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=SURFACE_2, progress_color="#2ed573",
            command=self._on_signature_mode_toggle,
        )
        self.signature_switch.grid(row=0, column=0, sticky="w", padx=10, pady=(8, 2))

        self.sig_desc_label = ctk.CTkLabel(
            sig_frame,
            text="Extracts clean 1-line center strokes from ink/pen without double outlines.",
            font=ctk.CTkFont(size=10), text_color=TEXT_DIM,
        )
        self.sig_desc_label.grid(row=1, column=0, sticky="w", padx=10, pady=(0, 8))

        # Checkboxes: Invert & Adaptive
        chk_frame = ctk.CTkFrame(parent, fg_color="transparent")
        chk_frame.grid(row=row, column=0, sticky="ew", padx=8, pady=(2, 4))
        chk_frame.grid_columnconfigure((0, 1), weight=1)

        self.invert_var = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(
            chk_frame, text="Invert (draw white)", variable=self.invert_var,
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
            command=lambda: self._queue_live_preview(),
        ).grid(row=0, column=0, sticky="w")

        self.adaptive_var = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(
            chk_frame, text="Adaptive (scans)", variable=self.adaptive_var,
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
            command=lambda: self._queue_live_preview(),
        ).grid(row=0, column=1, sticky="w")
        row += 1

        # Fill mode selector
        ctk.CTkLabel(parent, text="Stroke / Fill Mode", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=row, column=0, sticky="w", padx=8, pady=(4, 2)
        )
        row += 1

        self.fill_mode_var = ctk.StringVar(value="contour")
        self.fill_combo = ctk.CTkComboBox(
            parent,
            values=["contour", "signature (single-stroke)", "centerline", "hatch", "both"],
            variable=self.fill_mode_var,
            corner_radius=8,
            fg_color=SURFACE,
            border_color=SURFACE_2,
            button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
            state="readonly",
            command=self._on_fill_mode_change,
        )
        self.fill_combo.grid(row=row, column=0, sticky="ew", padx=8, pady=(0, 2))

        self.fill_tip_label = ctk.CTkLabel(
            parent, text="💡 Tip: Use 'signature' or toggle Signature Mode for single-line pen strokes",
            text_color="#64748b", font=ctk.CTkFont(size=10, slant="italic"),
        )
        self.fill_tip_label.grid(row=row + 1, column=0, sticky="w", padx=8, pady=(0, 4))
        row += 2

        # ── 📐 Manual Dimensions: Width & Height Controls ──
        dim_frame = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10)
        dim_frame.grid(row=row, column=0, sticky="ew", padx=8, pady=(4, 6))
        dim_frame.grid_columnconfigure(0, weight=1)
        row += 1

        # Lock Aspect Ratio
        dim_header = ctk.CTkFrame(dim_frame, fg_color="transparent")
        dim_header.grid(row=0, column=0, sticky="ew", padx=10, pady=(8, 2))
        dim_header.grid_columnconfigure(0, weight=1)

        self.lock_aspect_var = ctk.BooleanVar(value=True)
        self.lock_aspect_check = ctk.CTkCheckBox(
            dim_header, text="🔒 Lock Aspect Ratio (Proportional)",
            variable=self.lock_aspect_var,
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
            command=self._on_lock_aspect_toggle,
        )
        self.lock_aspect_check.grid(row=0, column=0, sticky="w")

        # Width row
        w_box = ctk.CTkFrame(dim_frame, fg_color="transparent")
        w_box.grid(row=1, column=0, sticky="ew", padx=10, pady=(4, 0))
        w_box.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(w_box, text="Drawing Output Width (mm)", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=0, column=0, sticky="w"
        )
        self.img_width_label = ctk.CTkLabel(
            w_box, text="120.0 mm", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        )
        self.img_width_label.grid(row=0, column=1, sticky="e")

        self.img_width_slider = ctk.CTkSlider(
            dim_frame, from_=5, to=float(self._config_data.get("bed_x", 220.0)), number_of_steps=215,
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
        )
        self.img_width_slider.set(120.0)
        self.img_width_slider.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 4))
        self.img_width_slider.configure(command=self._on_img_width_change)

        # Height row
        h_box = ctk.CTkFrame(dim_frame, fg_color="transparent")
        h_box.grid(row=3, column=0, sticky="ew", padx=10, pady=(4, 0))
        h_box.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(h_box, text="Drawing Output Height (mm)", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=0, column=0, sticky="w"
        )
        self.img_height_label = ctk.CTkLabel(
            h_box, text="80.0 mm", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        )
        self.img_height_label.grid(row=0, column=1, sticky="e")

        self.img_height_slider = ctk.CTkSlider(
            dim_frame, from_=5, to=float(self._config_data.get("bed_y", 220.0)), number_of_steps=215,
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
        )
        self.img_height_slider.set(80.0)
        self.img_height_slider.grid(row=4, column=0, sticky="ew", padx=10, pady=(0, 8))
        self.img_height_slider.configure(command=self._on_img_height_change)

        # ── 🔄 Rotation Controls ──
        rot_header = ctk.CTkFrame(parent, fg_color="transparent")
        rot_header.grid(row=row, column=0, sticky="ew", padx=8, pady=(4, 2))
        rot_header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(rot_header, text="🔄 Rotation Angle (°)", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=0, column=0, sticky="w"
        )
        self.img_rot_label = ctk.CTkLabel(
            rot_header, text="0°", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        )
        self.img_rot_label.grid(row=0, column=1, sticky="e", padx=(0, 8))
        row += 1

        self.img_rot_slider = ctk.CTkSlider(
            parent, from_=-180, to=180, number_of_steps=360,
            fg_color=SURFACE, progress_color=ACCENT, button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
        )
        self.img_rot_slider.set(0)
        self.img_rot_slider.grid(row=row, column=0, sticky="ew", padx=8, pady=(0, 2))
        self.img_rot_slider.configure(command=self._on_img_rotation_change)
        row += 1

        # Rotation quick preset buttons
        rot_presets = ctk.CTkFrame(parent, fg_color="transparent")
        rot_presets.grid(row=row, column=0, sticky="ew", padx=8, pady=(0, 6))
        rot_presets.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

        ctk.CTkButton(rot_presets, text="0°", height=22, font=ctk.CTkFont(size=10), fg_color=SURFACE_2, hover_color="#3a3a5c", command=lambda: self._set_img_rotation(0)).grid(row=0, column=0, padx=1, sticky="ew")
        ctk.CTkButton(rot_presets, text="-90°", height=22, font=ctk.CTkFont(size=10), fg_color=SURFACE_2, hover_color="#3a3a5c", command=lambda: self._set_img_rotation(-90)).grid(row=0, column=1, padx=1, sticky="ew")
        ctk.CTkButton(rot_presets, text="+90°", height=22, font=ctk.CTkFont(size=10), fg_color=SURFACE_2, hover_color="#3a3a5c", command=lambda: self._set_img_rotation(90)).grid(row=0, column=2, padx=1, sticky="ew")
        ctk.CTkButton(rot_presets, text="180°", height=22, font=ctk.CTkFont(size=10), fg_color=SURFACE_2, hover_color="#3a3a5c", command=lambda: self._set_img_rotation(180)).grid(row=0, column=3, padx=1, sticky="ew")
        ctk.CTkButton(rot_presets, text="-5°", height=22, font=ctk.CTkFont(size=10), fg_color=SURFACE_2, hover_color="#3a3a5c", command=lambda: self._set_img_rotation(self.img_rot_slider.get() - 5)).grid(row=0, column=4, padx=1, sticky="ew")
        ctk.CTkButton(rot_presets, text="+5°", height=22, font=ctk.CTkFont(size=10), fg_color=SURFACE_2, hover_color="#3a3a5c", command=lambda: self._set_img_rotation(self.img_rot_slider.get() + 5)).grid(row=0, column=5, padx=1, sticky="ew")
        row += 1

        # ── 🌊 Stroke Flow & Smoothness Controls ──
        smooth_header = ctk.CTkFrame(parent, fg_color="transparent")
        smooth_header.grid(row=row, column=0, sticky="ew", padx=8, pady=(2, 2))
        smooth_header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(smooth_header, text="🌊 Handwriting Flow / Smoothness", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=0, column=0, sticky="w"
        )
        self.img_smooth_label = ctk.CTkLabel(
            smooth_header, text="2 (Flowing)", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        )
        self.img_smooth_label.grid(row=0, column=1, sticky="e", padx=(0, 8))
        row += 1

        self.img_smooth_slider = ctk.CTkSlider(
            parent, from_=0, to=4, number_of_steps=4,
            fg_color=SURFACE, progress_color=ACCENT, button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
        )
        self.img_smooth_slider.set(2)
        self.img_smooth_slider.grid(row=row, column=0, sticky="ew", padx=8, pady=(0, 6))
        self.img_smooth_slider.configure(command=self._on_img_smooth_change)
        row += 1

        # Image Position Controls
        img_pos_frame = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10)
        img_pos_frame.grid(row=row, column=0, sticky="ew", padx=8, pady=(6, 8))
        img_pos_frame.grid_columnconfigure(0, weight=1)
        row += 1

        self.center_img_var = ctk.BooleanVar(value=True)
        self.center_img_check = ctk.CTkCheckBox(
            img_pos_frame, text="Center automatically on bed", variable=self.center_img_var,
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
            command=self._on_center_img_toggle,
        )
        self.center_img_check.grid(row=0, column=0, sticky="w", padx=10, pady=(10, 6))

        # Img X slider
        ctk.CTkLabel(img_pos_frame, text="Position X on Plate (mm)", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=1, column=0, sticky="w", padx=10, pady=(2, 0)
        )
        self.img_x_slider = ctk.CTkSlider(
            img_pos_frame, from_=0, to=float(self._config_data.get("bed_x", 220.0)), number_of_steps=220,
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
        )
        self.img_x_slider.set(50.0)
        self.img_x_slider.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 2))

        self.img_x_label = ctk.CTkLabel(
            img_pos_frame, text="50.0 mm", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        )
        self.img_x_label.grid(row=1, column=0, sticky="e", padx=(0, 14))
        self.img_x_slider.configure(command=self._on_img_x_change)

        # Img Y slider
        ctk.CTkLabel(img_pos_frame, text="Position Y on Plate (mm)", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(
            row=3, column=0, sticky="w", padx=10, pady=(2, 0)
        )
        self.img_y_slider = ctk.CTkSlider(
            img_pos_frame, from_=0, to=float(self._config_data.get("bed_y", 220.0)), number_of_steps=220,
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
        )
        self.img_y_slider.set(50.0)
        self.img_y_slider.grid(row=4, column=0, sticky="ew", padx=10, pady=(0, 8))

        self.img_y_label = ctk.CTkLabel(
            img_pos_frame, text="50.0 mm", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)
        )
        self.img_y_label.grid(row=3, column=0, sticky="e", padx=(0, 14))
        self.img_y_slider.configure(command=self._on_img_y_change)

    # ============================
    # PCB Tab (EasyEDA SVG & Etch-Resist Plotting)
    # ============================
    def _build_pcb_tab(self, parent):
        row = 0

        # Active offset badge
        self.pcb_offset_badge = ctk.CTkLabel(
            parent,
            text="🎯 Pen Offset: X=+0.0, Y=+49.5, Z=+0.0 mm  •  ⚙️ Settings",
            font=ctk.CTkFont(size=10),
            text_color="#ffb86c",
        )
        self.pcb_offset_badge.grid(row=row, column=0, sticky="w", padx=8, pady=(4, 2))
        row += 1

        # ── 📂 File Selector Card ──
        file_card = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10, border_color="#3a3a5c", border_width=1)
        file_card.grid(row=row, column=0, sticky="ew", padx=8, pady=(4, 6))
        file_card.grid_columnconfigure(0, weight=1)
        row += 1

        ctk.CTkLabel(
            file_card,
            text="⚡ EasyEDA Vector SVG / PCB File",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#38bdf8",
        ).grid(row=0, column=0, sticky="w", padx=12, pady=(10, 4))

        self.pcb_file_btn = ctk.CTkButton(
            file_card,
            text="📂  Choose EasyEDA SVG / PCB File...",
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=ACCENT,
            hover_color=ACCENT_HOVER,
            text_color="#0a0a1a",
            height=34,
            command=self._on_choose_pcb_file,
        )
        self.pcb_file_btn.grid(row=1, column=0, sticky="ew", padx=12, pady=(0, 4))

        self.pcb_file_label = ctk.CTkLabel(
            file_card,
            text="No SVG loaded (Export in EasyEDA: File > Export > SVG)",
            font=ctk.CTkFont(size=10),
            text_color=TEXT_DIM,
            wraplength=280,
        )
        self.pcb_file_label.grid(row=2, column=0, sticky="w", padx=12, pady=(0, 10))

        # ── 📏 Physical Blank Copper Clad Board Card ──
        board_card = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10, border_color="#b87333", border_width=1)
        board_card.grid(row=row, column=0, sticky="ew", padx=8, pady=(4, 6))
        board_card.grid_columnconfigure((0, 1), weight=1)
        row += 1

        ctk.CTkLabel(
            board_card,
            text="📐 Physical Blank Copper Clad Dimensions",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#fcd34d",
        ).grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(10, 6))

        # Board Width
        ctk.CTkLabel(board_card, text="Board Width (mm):", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=1, column=0, sticky="w", padx=12, pady=2)
        self.pcb_w_entry = ctk.CTkEntry(board_card, width=80, height=28)
        self.pcb_w_entry.insert(0, "70.0")
        self.pcb_w_entry.grid(row=1, column=1, sticky="e", padx=12, pady=2)
        self.pcb_w_entry.bind("<KeyRelease>", lambda e: self._on_pcb_param_change())

        # Board Height
        ctk.CTkLabel(board_card, text="Board Height (mm):", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=2, column=0, sticky="w", padx=12, pady=2)
        self.pcb_h_entry = ctk.CTkEntry(board_card, width=80, height=28)
        self.pcb_h_entry.insert(0, "50.0")
        self.pcb_h_entry.grid(row=2, column=1, sticky="e", padx=12, pady=2)
        self.pcb_h_entry.bind("<KeyRelease>", lambda e: self._on_pcb_param_change())

        # Board Thickness (Z Height Offset)
        ctk.CTkLabel(board_card, text="Board Thickness / Z (mm):", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=3, column=0, sticky="w", padx=12, pady=2)
        self.pcb_thickness_entry = ctk.CTkEntry(board_card, width=80, height=28)
        self.pcb_thickness_entry.insert(0, "1.6")
        self.pcb_thickness_entry.grid(row=3, column=1, sticky="e", padx=12, pady=2)
        self.pcb_thickness_entry.bind("<KeyRelease>", lambda e: self._on_pcb_param_change())

        # Dynamic Pen Z Touch Height Indicator
        self.pcb_z_touch_label = ctk.CTkLabel(
            board_card,
            text=f"⚡ Pen Touch Z on Board: {self._config_data.get('pen_touch_z', 28.8) + 1.6:.1f} mm",
            font=ctk.CTkFont(size=10, weight="bold"),
            text_color="#fcd34d",
        )
        self.pcb_z_touch_label.grid(row=4, column=0, columnspan=2, sticky="w", padx=12, pady=(2, 8))

        # ── 🎯 Trace Position on Copper Board (X, Y Offset) Card ──
        trace_pos_card = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10)
        trace_pos_card.grid(row=row, column=0, sticky="ew", padx=8, pady=(4, 6))
        trace_pos_card.grid_columnconfigure(0, weight=1)
        row += 1

        tpos_header = ctk.CTkFrame(trace_pos_card, fg_color="transparent")
        tpos_header.grid(row=0, column=0, sticky="ew", padx=10, pady=(8, 2))
        tpos_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(tpos_header, text="🎯 Trace Position on Board", font=ctk.CTkFont(size=12, weight="bold"), text_color=TEXT_MAIN).grid(row=0, column=0, sticky="w")

        # Center traces button
        ctk.CTkButton(
            tpos_header,
            text="🎯 Center Traces",
            font=ctk.CTkFont(size=10, weight="bold"),
            height=22,
            width=100,
            fg_color=SURFACE_2,
            hover_color=ACCENT,
            text_color="#ccccee",
            command=self._center_pcb_traces,
        ).grid(row=0, column=1, sticky="e")

        # Trace X Shift Slider
        tx_header = ctk.CTkFrame(trace_pos_card, fg_color="transparent")
        tx_header.grid(row=1, column=0, sticky="ew", padx=10, pady=(4, 0))
        tx_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(tx_header, text="Trace Shift X (mm):", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=0, column=0, sticky="w")
        self.pcb_trace_x_label = ctk.CTkLabel(tx_header, text="0.0 mm", text_color=TEXT_DIM, font=ctk.CTkFont(size=11))
        self.pcb_trace_x_label.grid(row=0, column=1, sticky="e")

        self.pcb_trace_x_slider = ctk.CTkSlider(
            trace_pos_card, from_=-40.0, to=40.0, number_of_steps=160,
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT, button_hover_color=ACCENT_HOVER,
        )
        self.pcb_trace_x_slider.set(0.0)
        self.pcb_trace_x_slider.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 4))
        self.pcb_trace_x_slider.configure(command=self._on_pcb_trace_x_change)

        # Trace Y Shift Slider
        ty_header = ctk.CTkFrame(trace_pos_card, fg_color="transparent")
        ty_header.grid(row=3, column=0, sticky="ew", padx=10, pady=(4, 0))
        ty_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(ty_header, text="Trace Shift Y (mm):", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=0, column=0, sticky="w")
        self.pcb_trace_y_label = ctk.CTkLabel(ty_header, text="0.0 mm", text_color=TEXT_DIM, font=ctk.CTkFont(size=11))
        self.pcb_trace_y_label.grid(row=0, column=1, sticky="e")

        self.pcb_trace_y_slider = ctk.CTkSlider(
            trace_pos_card, from_=-40.0, to=40.0, number_of_steps=160,
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT, button_hover_color=ACCENT_HOVER,
        )
        self.pcb_trace_y_slider.set(0.0)
        self.pcb_trace_y_slider.grid(row=4, column=0, sticky="ew", padx=10, pady=(0, 8))
        self.pcb_trace_y_slider.configure(command=self._on_pcb_trace_y_change)

        # ── 📍 Board Position on Print Bed Card ──
        pos_card = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10)
        pos_card.grid(row=row, column=0, sticky="ew", padx=8, pady=(4, 6))
        pos_card.grid_columnconfigure(0, weight=1)
        row += 1

        pos_header = ctk.CTkFrame(pos_card, fg_color="transparent")
        pos_header.grid(row=0, column=0, sticky="ew", padx=10, pady=(8, 2))
        pos_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(pos_header, text="📍 Board Position on Print Bed", font=ctk.CTkFont(size=12, weight="bold"), text_color=TEXT_MAIN).grid(row=0, column=0, sticky="w")

        # Center on bed button
        ctk.CTkButton(
            pos_header,
            text="🎯 Center on Bed",
            font=ctk.CTkFont(size=10, weight="bold"),
            height=22,
            width=110,
            fg_color=SURFACE_2,
            hover_color=ACCENT,
            text_color="#ccccee",
            command=self._center_pcb_board,
        ).grid(row=0, column=1, sticky="e")

        # Bed X Slider
        px_header = ctk.CTkFrame(pos_card, fg_color="transparent")
        px_header.grid(row=1, column=0, sticky="ew", padx=10, pady=(4, 0))
        px_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(px_header, text="Board Left X (mm):", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=0, column=0, sticky="w")
        self.pcb_x_label = ctk.CTkLabel(px_header, text="30.0 mm", text_color=TEXT_DIM, font=ctk.CTkFont(size=11))
        self.pcb_x_label.grid(row=0, column=1, sticky="e")

        self.pcb_x_slider = ctk.CTkSlider(
            pos_card, from_=0, to=float(self._config_data.get("bed_x", 220.0)),
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT, button_hover_color=ACCENT_HOVER,
        )
        self.pcb_x_slider.set(30.0)
        self.pcb_x_slider.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 4))
        self.pcb_x_slider.configure(command=self._on_pcb_x_change)

        # Bed Y Slider
        py_header = ctk.CTkFrame(pos_card, fg_color="transparent")
        py_header.grid(row=3, column=0, sticky="ew", padx=10, pady=(4, 0))
        py_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(py_header, text="Board Bottom Y (mm):", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=0, column=0, sticky="w")
        self.pcb_y_label = ctk.CTkLabel(py_header, text="40.0 mm", text_color=TEXT_DIM, font=ctk.CTkFont(size=11))
        self.pcb_y_label.grid(row=0, column=1, sticky="e")

        self.pcb_y_slider = ctk.CTkSlider(
            pos_card, from_=0, to=float(self._config_data.get("bed_y", 220.0)),
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT, button_hover_color=ACCENT_HOVER,
        )
        self.pcb_y_slider.set(40.0)
        self.pcb_y_slider.grid(row=4, column=0, sticky="ew", padx=10, pady=(0, 8))
        self.pcb_y_slider.configure(command=self._on_pcb_y_change)

        # ── 🔄 Board Rotation Card ──
        rot_card = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10)
        rot_card.grid(row=row, column=0, sticky="ew", padx=8, pady=(4, 6))
        rot_card.grid_columnconfigure(0, weight=1)
        row += 1

        rot_header = ctk.CTkFrame(rot_card, fg_color="transparent")
        rot_header.grid(row=0, column=0, sticky="ew", padx=10, pady=(6, 2))
        rot_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(rot_header, text="🔄 Board Rotation Angle", font=ctk.CTkFont(size=12, weight="bold"), text_color=TEXT_MAIN).grid(row=0, column=0, sticky="w")
        self.pcb_rot_label = ctk.CTkLabel(rot_header, text="0°", font=ctk.CTkFont(size=11), text_color=TEXT_DIM)
        self.pcb_rot_label.grid(row=0, column=1, sticky="e")

        self.pcb_rot_slider = ctk.CTkSlider(
            rot_card, from_=-180, to=180, number_of_steps=360,
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT, button_hover_color=ACCENT_HOVER,
        )
        self.pcb_rot_slider.set(0)
        self.pcb_rot_slider.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 4))
        self.pcb_rot_slider.configure(command=self._on_pcb_rot_change)

        # Quick preset buttons
        rot_presets = ctk.CTkFrame(rot_card, fg_color="transparent")
        rot_presets.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 6))
        rot_presets.grid_columnconfigure((0, 1, 2, 3, 4), weight=1)

        ctk.CTkButton(rot_presets, text="0°", height=22, font=ctk.CTkFont(size=10), fg_color=SURFACE_2, hover_color="#3a3a5c", command=lambda: self._set_pcb_rotation(0)).grid(row=0, column=0, padx=1, sticky="ew")
        ctk.CTkButton(rot_presets, text="+90°", height=22, font=ctk.CTkFont(size=10), fg_color=SURFACE_2, hover_color="#3a3a5c", command=lambda: self._set_pcb_rotation(90)).grid(row=0, column=1, padx=1, sticky="ew")
        ctk.CTkButton(rot_presets, text="180°", height=22, font=ctk.CTkFont(size=10), fg_color=SURFACE_2, hover_color="#3a3a5c", command=lambda: self._set_pcb_rotation(180)).grid(row=0, column=2, padx=1, sticky="ew")
        ctk.CTkButton(rot_presets, text="-90°", height=22, font=ctk.CTkFont(size=10), fg_color=SURFACE_2, hover_color="#3a3a5c", command=lambda: self._set_pcb_rotation(-90)).grid(row=0, column=3, padx=1, sticky="ew")
        ctk.CTkButton(rot_presets, text="Swap W/H", height=22, font=ctk.CTkFont(size=10), fg_color=SURFACE_2, hover_color="#3a3a5c", command=self._swap_pcb_dimensions).grid(row=0, column=4, padx=1, sticky="ew")

        # ── 🔄 Copper Layer & Mirroring Card ──
        layer_card = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10)
        layer_card.grid(row=row, column=0, sticky="ew", padx=8, pady=(4, 6))
        layer_card.grid_columnconfigure(0, weight=1)
        row += 1

        self.pcb_mirror_var = ctk.BooleanVar(value=True)
        self.pcb_mirror_switch = ctk.CTkSwitch(
            layer_card,
            text="🪞 Bottom Layer (Mirror X for Copper Side)",
            variable=self.pcb_mirror_var,
            font=ctk.CTkFont(size=11, weight="bold"),
            progress_color="#2ed573",
            command=self._on_pcb_param_change,
        )
        self.pcb_mirror_switch.grid(row=0, column=0, sticky="w", padx=12, pady=(10, 4))

        ctk.CTkLabel(
            layer_card,
            text="Required for single-sided PCBs so pinouts and ICs match when viewed from top.",
            font=ctk.CTkFont(size=10),
            text_color=TEXT_DIM,
            wraplength=280,
        ).grid(row=1, column=0, sticky="w", padx=12, pady=(0, 10))

        # ── 🖊️ Etch-Resist Infill & Marker Card ──
        infill_card = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10)
        infill_card.grid(row=row, column=0, sticky="ew", padx=8, pady=(4, 8))
        infill_card.grid_columnconfigure(0, weight=1)
        row += 1

        ctk.CTkLabel(
            infill_card,
            text="🧪 FeCl3 Etch-Resist Infill & Marker Settings",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#2ed573",
        ).grid(row=0, column=0, sticky="w", padx=12, pady=(10, 4))

        # Marker tip width
        mt_header = ctk.CTkFrame(infill_card, fg_color="transparent")
        mt_header.grid(row=1, column=0, sticky="ew", padx=12, pady=(4, 0))
        mt_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(mt_header, text="Marker Pen Line Width:", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=0, column=0, sticky="w")
        self.pcb_marker_label = ctk.CTkLabel(mt_header, text="0.60 mm", text_color=TEXT_DIM, font=ctk.CTkFont(size=11))
        self.pcb_marker_label.grid(row=0, column=1, sticky="e")

        self.pcb_marker_slider = ctk.CTkSlider(
            infill_card, from_=0.2, to=1.2, number_of_steps=50,
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT, button_hover_color=ACCENT_HOVER,
        )
        self.pcb_marker_slider.set(0.6)
        self.pcb_marker_slider.grid(row=2, column=0, sticky="ew", padx=12, pady=(0, 4))
        self.pcb_marker_slider.configure(command=self._on_pcb_marker_change)

        # Infill overlap %
        ov_header = ctk.CTkFrame(infill_card, fg_color="transparent")
        ov_header.grid(row=3, column=0, sticky="ew", padx=12, pady=(4, 0))
        ov_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(ov_header, text="Infill Overlap (Pinhole Prevention):", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=0, column=0, sticky="w")
        self.pcb_overlap_label = ctk.CTkLabel(ov_header, text="40%", text_color=TEXT_DIM, font=ctk.CTkFont(size=11))
        self.pcb_overlap_label.grid(row=0, column=1, sticky="e")

        self.pcb_overlap_slider = ctk.CTkSlider(
            infill_card, from_=0, to=70, number_of_steps=70,
            fg_color=SURFACE_2, progress_color=ACCENT, button_color=ACCENT, button_hover_color=ACCENT_HOVER,
        )
        self.pcb_overlap_slider.set(40)
        self.pcb_overlap_slider.grid(row=4, column=0, sticky="ew", padx=12, pady=(0, 10))
        self.pcb_overlap_slider.configure(command=self._on_pcb_overlap_change)

    def _on_choose_pcb_file(self):
        """Open file dialog for EasyEDA SVG or PCB files."""
        path = filedialog.askopenfilename(
            title="Select EasyEDA Vector SVG or PCB File",
            filetypes=[
                ("EasyEDA Vector SVG", "*.svg"),
                ("All Supported Files", "*.svg;*.png;*.jpg;*.jpeg;*.bmp"),
                ("All Files", "*.*"),
            ],
        )
        if path:
            self._current_pcb_path = path
            fname = os.path.basename(path)
            self.pcb_file_label.configure(text=f"✅ {fname}", text_color="#2ed573")
            self._sync_pcb_overlay()
            self._queue_live_preview()

    def _on_pcb_trace_x_change(self, val):
        self.pcb_trace_x_label.configure(text=f"{float(val):.1f} mm")
        self._queue_live_preview()

    def _on_pcb_trace_y_change(self, val):
        self.pcb_trace_y_label.configure(text=f"{float(val):.1f} mm")
        self._queue_live_preview()

    def _center_pcb_traces(self):
        self.pcb_trace_x_slider.set(0.0)
        self.pcb_trace_y_slider.set(0.0)
        self._on_pcb_trace_x_change(0.0)
        self._on_pcb_trace_y_change(0.0)

    def _on_pcb_x_change(self, val):
        self.pcb_x_label.configure(text=f"{float(val):.1f} mm")
        self._sync_pcb_overlay()
        self._queue_live_preview()

    def _on_pcb_y_change(self, val):
        self.pcb_y_label.configure(text=f"{float(val):.1f} mm")
        self._sync_pcb_overlay()
        self._queue_live_preview()

    def _on_pcb_rot_change(self, val):
        self.pcb_rot_label.configure(text=f"{int(float(val))}°")
        self._sync_pcb_overlay()
        self._queue_live_preview()

    def _set_pcb_rotation(self, deg: float):
        self.pcb_rot_slider.set(deg)
        self._on_pcb_rot_change(deg)

    def _swap_pcb_dimensions(self):
        try:
            bw = float(self.pcb_w_entry.get() or 70.0)
            bh = float(self.pcb_h_entry.get() or 50.0)
            self.pcb_w_entry.delete(0, "end")
            self.pcb_w_entry.insert(0, f"{bh:.1f}")
            self.pcb_h_entry.delete(0, "end")
            self.pcb_h_entry.insert(0, f"{bw:.1f}")
            self._on_pcb_param_change()
        except ValueError:
            pass

    def _on_pcb_marker_change(self, val):
        self.pcb_marker_label.configure(text=f"{float(val):.2f} mm")
        self._queue_live_preview()

    def _on_pcb_overlap_change(self, val):
        self.pcb_overlap_label.configure(text=f"{int(float(val))}%")
        self._queue_live_preview()

    def _on_pcb_param_change(self):
        try:
            th = float(self.pcb_thickness_entry.get() or 1.6)
        except (ValueError, AttributeError):
            th = 1.6
        base_z = float(self._config_data.get("pen_touch_z", 28.8))
        if hasattr(self, "pcb_z_touch_label"):
            self.pcb_z_touch_label.configure(text=f"⚡ Pen Touch Z on Board: {base_z + th:.1f} mm ({base_z:.1f} + {th:.1f} mm)")
        self._sync_pcb_overlay()
        self._queue_live_preview()

    def _center_pcb_board(self):
        cfg = self._get_config()
        try:
            bw = float(self.pcb_w_entry.get() or 70.0)
            bh = float(self.pcb_h_entry.get() or 50.0)
        except ValueError:
            bw, bh = 70.0, 50.0

        cx = max(0.0, (cfg.bed_x - bw) / 2.0)
        cy = max(0.0, (cfg.bed_y - bh) / 2.0)
        self.pcb_x_slider.set(cx)
        self.pcb_y_slider.set(cy)
        self._on_pcb_x_change(cx)
        self._on_pcb_y_change(cy)

    def _sync_pcb_overlay(self):
        """Update the physical PCB copper board blank overlay on the canvas."""
        tab = self.tabview.get()
        active_tab = tab if tab in ("✏️  Text", "🖼️  Image", "⚡ PCB") else getattr(self, "_last_active_tab", "✏️  Text")
        if active_tab == "⚡ PCB":
            try:
                bw = float(self.pcb_w_entry.get() or 70.0)
                bh = float(self.pcb_h_entry.get() or 50.0)
            except (ValueError, AttributeError):
                bw, bh = 70.0, 50.0
            bx = self.pcb_x_slider.get() if hasattr(self, "pcb_x_slider") else 30.0
            by = self.pcb_y_slider.get() if hasattr(self, "pcb_y_slider") else 40.0
            rot = float(self.pcb_rot_slider.get()) if hasattr(self, "pcb_rot_slider") else 0.0
            self.preview.set_pcb_overlay(True, {"board_w": bw, "board_h": bh, "bed_x": bx, "bed_y": by, "rotation_deg": rot})
        else:
            self.preview.set_pcb_overlay(False)

    def _generate_pcb(self, cfg: PlotterConfig) -> Optional[GCodeBuilder]:
        """Generate G-code for PCB vector traces with solid etch-resist infill and elevated Z."""
        if not self._current_pcb_path:
            return None

        try:
            bw = float(self.pcb_w_entry.get() or 70.0)
            bh = float(self.pcb_h_entry.get() or 50.0)
            th = float(self.pcb_thickness_entry.get() or 1.6)
        except (ValueError, AttributeError):
            bw, bh, th = 70.0, 50.0, 1.6

        bx = float(self.pcb_x_slider.get())
        by = float(self.pcb_y_slider.get())
        mirror = self.pcb_mirror_var.get()
        rot = float(self.pcb_rot_slider.get()) if hasattr(self, "pcb_rot_slider") else 0.0
        trace_sx = float(self.pcb_trace_x_slider.get()) if hasattr(self, "pcb_trace_x_slider") else 0.0
        trace_sy = float(self.pcb_trace_y_slider.get()) if hasattr(self, "pcb_trace_y_slider") else 0.0
        marker_tip = float(self.pcb_marker_slider.get())
        overlap = float(self.pcb_overlap_slider.get())

        # Create elevated PCB config
        import copy
        pcb_cfg = copy.copy(cfg)
        pcb_cfg.pen_touch_z = cfg.pen_touch_z + th
        pcb_cfg.safe_lift_z = max(cfg.safe_lift_z, pcb_cfg.pen_touch_z + cfg.z_hop + 3.0)

        if self._current_pcb_path.lower().endswith(".svg"):
            paths, meta = svg_processor.process_pcb_svg(
                svg_path=self._current_pcb_path,
                pcb_board_w_mm=bw,
                pcb_board_h_mm=bh,
                pcb_board_bed_x=bx,
                pcb_board_bed_y=by,
                mirror_x=mirror,
                rotation_deg=rot,
                trace_shift_x=trace_sx,
                trace_shift_y=trace_sy,
                marker_tip_mm=marker_tip,
                overlap_pct=overlap,
                infill_mode="solid",
            )
        else:
            paths, _, _ = image_processor.image_to_paths(
                image_path=self._current_pcb_path,
                target_width_mm=bw,
                target_height_mm=bh,
                threshold=128,
                rotation_deg=rot,
                fill_mode="both",
                offset_x=bx + trace_sx,
                offset_y=by + trace_sy,
            )

        if not paths:
            return None

        return generate_gcode_paths(pcb_cfg, paths)

    # ============================
    # Settings Page
    # ============================
    def _build_settings_tab(self, parent):
        cfg = self._config_data
        entries = {}

        # Header title
        title_box = ctk.CTkFrame(parent, fg_color="transparent")
        title_box.grid(row=0, column=0, sticky="ew", padx=8, pady=(4, 6))
        title_box.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            title_box,
            text="⚙️  Plotter & Machine Configurations",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=ACCENT,
        ).grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(
            title_box,
            text="Calibrate toolhead offsets, bed boundaries, Z-heights, and feedrates.",
            font=ctk.CTkFont(size=11),
            text_color=TEXT_DIM,
        ).grid(row=1, column=0, sticky="w")

        row = 1

        # ==========================================
        # Card 1: 🎯 Pen Physical Position & Reach Calibration
        # ==========================================
        card_offset = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=12, border_color="#3a3a5c", border_width=1)
        card_offset.grid(row=row, column=0, sticky="ew", padx=6, pady=(0, 8))
        card_offset.grid_columnconfigure((0, 1, 2), weight=1)
        row += 1

        ctk.CTkLabel(
            card_offset,
            text="🎯  Pen Toolhead Offset Calibration (Front Mount Pen)",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#ffb86c",
        ).grid(row=0, column=0, columnspan=3, sticky="w", padx=12, pady=(10, 2))

        ctk.CTkLabel(
            card_offset,
            text="💡 Physical shift between pen tip and nozzle (NOT bed size):\n"
                 "• X Shift: 0.0 mm if pen is aligned with nozzle along X\n"
                 "• Y Offset: +49.5 mm for Kobra 2 Neo front-mount (compensates for pen mounted in front of nozzle)",
            font=ctk.CTkFont(size=10),
            text_color=TEXT_DIM,
            justify="left",
        ).grid(row=1, column=0, columnspan=3, sticky="w", padx=12, pady=(0, 8))

        offset_fields = [
            ("Pen X Shift (0.0 = Aligned)", "offset_x", str(cfg.get("offset_x", 0.0))),
            ("Pen Y Offset (e.g. +49.5mm)", "offset_y", str(cfg.get("offset_y", 49.5))),
            ("Pen Z Micro-Trim (mm)", "offset_z", str(cfg.get("offset_z", 0.0))),
        ]

        for col, (label_text, key, default) in enumerate(offset_fields):
            col_frame = ctk.CTkFrame(card_offset, fg_color="transparent")
            col_frame.grid(row=2, column=col, sticky="ew", padx=6, pady=(0, 6))
            col_frame.grid_columnconfigure(0, weight=1)

            ctk.CTkLabel(
                col_frame, text=label_text,
                text_color=TEXT_DIM, font=ctk.CTkFont(size=10, weight="bold"),
            ).grid(row=0, column=0, sticky="w")

            entry = ctk.CTkEntry(
                col_frame, fg_color=SURFACE_2, corner_radius=6,
                font=ctk.CTkFont(size=12, weight="bold"),
                justify="center",
            )
            entry.insert(0, default)
            entry.grid(row=1, column=0, sticky="ew", pady=(2, 4))
            entry.bind("<KeyRelease>", lambda _: self._on_settings_input_changed())
            entries[key] = entry

        # Quick presets row
        preset_frame = ctk.CTkFrame(card_offset, fg_color="transparent")
        preset_frame.grid(row=3, column=0, columnspan=3, sticky="ew", padx=6, pady=(0, 10))
        preset_frame.grid_columnconfigure((0, 1, 2), weight=1)

        ctk.CTkButton(
            preset_frame, text="Nozzle Aligned (0,0)",
            font=ctk.CTkFont(size=10), height=24, fg_color=SURFACE_2, hover_color="#3a3a60",
            command=lambda: self._apply_offset_preset(0.0, 0.0, 0.0),
        ).grid(row=0, column=0, padx=2, sticky="ew")

        ctk.CTkButton(
            preset_frame, text="Front Mount (Y+35mm)",
            font=ctk.CTkFont(size=10), height=24, fg_color=SURFACE_2, hover_color="#3a3a60",
            command=lambda: self._apply_offset_preset(0.0, 35.0, 0.0),
        ).grid(row=0, column=1, padx=2, sticky="ew")

        ctk.CTkButton(
            preset_frame, text="Kobra 2 Neo (Y+49.5mm)",
            font=ctk.CTkFont(size=10), height=24, fg_color=SURFACE_2, hover_color="#3a3a60",
            command=lambda: self._apply_offset_preset(0.0, 49.5, 0.0),
        ).grid(row=0, column=2, padx=2, sticky="ew")

        # ==========================================
        # Card 2: 📐 Machine Bed & Dimensions
        # ==========================================
        card_bed = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=12)
        card_bed.grid(row=row, column=0, sticky="ew", padx=6, pady=(0, 8))
        card_bed.grid_columnconfigure((0, 1), weight=1)
        row += 1

        ctk.CTkLabel(
            card_bed,
            text="📐  Machine Bed Dimensions",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#ccccee",
        ).grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(8, 4))

        bed_fields = [
            ("Bed Width X (mm)", "bed_x", str(cfg.get("bed_x", 220.0))),
            ("Bed Depth Y (mm)", "bed_y", str(cfg.get("bed_y", 220.0))),
        ]
        for col, (label_text, key, default) in enumerate(bed_fields):
            col_frame = ctk.CTkFrame(card_bed, fg_color="transparent")
            col_frame.grid(row=1, column=col, sticky="ew", padx=8, pady=(0, 8))
            col_frame.grid_columnconfigure(0, weight=1)

            ctk.CTkLabel(col_frame, text=label_text, text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=0, column=0, sticky="w")
            entry = ctk.CTkEntry(col_frame, fg_color=SURFACE_2, corner_radius=6, font=ctk.CTkFont(size=12))
            entry.insert(0, default)
            entry.grid(row=1, column=0, sticky="ew", pady=(2, 0))
            entry.bind("<KeyRelease>", lambda _: self._on_settings_input_changed())
            entries[key] = entry

        # ==========================================
        # Card 3: 🖋️ Pen Z Heights & Touch Bed Calibration
        # ==========================================
        card_z = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=12)
        card_z.grid(row=row, column=0, sticky="ew", padx=6, pady=(0, 8))
        card_z.grid_columnconfigure((0, 1), weight=1)
        row += 1

        ctk.CTkLabel(
            card_z,
            text="🖋️  Pen Z Heights & Touch Bed Calibration",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#ccccee",
        ).grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(8, 4))

        z_fields = [
            ("Pen Touching Bed Z Height (mm)", "pen_touch_z", str(cfg.get("pen_touch_z", 0.0))),
            ("Z Hop Distance (mm)", "z_hop", str(cfg.get("z_hop", 2.0))),
            ("Safe Lift Z (mm)", "safe_lift_z", str(cfg.get("safe_lift_z", 30.0))),
            ("Safe Dwell Wait (ms)", "safe_wait_ms", str(cfg.get("safe_wait_ms", 5000))),
        ]
        for i, (label_text, key, default) in enumerate(z_fields):
            r, c = divmod(i, 2)
            col_frame = ctk.CTkFrame(card_z, fg_color="transparent")
            col_frame.grid(row=r + 1, column=c, sticky="ew", padx=8, pady=(0, 8))
            col_frame.grid_columnconfigure(0, weight=1)

            ctk.CTkLabel(col_frame, text=label_text, text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=0, column=0, sticky="w")
            entry = ctk.CTkEntry(col_frame, fg_color=SURFACE_2, corner_radius=6, font=ctk.CTkFont(size=12))
            entry.insert(0, default)
            entry.grid(row=1, column=0, sticky="ew", pady=(2, 0))
            entry.bind("<KeyRelease>", lambda _: self._on_settings_input_changed())
            entries[key] = entry

        # ==========================================
        # Card 4: 🚀 Speeds & Feedrates
        # ==========================================
        card_feed = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=12)
        card_feed.grid(row=row, column=0, sticky="ew", padx=6, pady=(0, 8))
        card_feed.grid_columnconfigure((0, 1), weight=1)
        row += 1

        ctk.CTkLabel(
            card_feed,
            text="🚀  Speeds & Feedrates (mm/min)",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#ccccee",
        ).grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(8, 4))

        feed_fields = [
            ("Drawing Feedrate (mm/min)", "draw_feed", str(cfg.get("draw_feed", 1200))),
            ("Travel Feedrate (mm/min)", "travel_feed", str(cfg.get("travel_feed", 2500))),
        ]
        for col, (label_text, key, default) in enumerate(feed_fields):
            col_frame = ctk.CTkFrame(card_feed, fg_color="transparent")
            col_frame.grid(row=1, column=col, sticky="ew", padx=8, pady=(0, 8))
            col_frame.grid_columnconfigure(0, weight=1)

            ctk.CTkLabel(col_frame, text=label_text, text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=0, column=0, sticky="w")
            entry = ctk.CTkEntry(col_frame, fg_color=SURFACE_2, corner_radius=6, font=ctk.CTkFont(size=12))
            entry.insert(0, default)
            entry.grid(row=1, column=0, sticky="ew", pady=(2, 0))
            entry.bind("<KeyRelease>", lambda _: self._on_settings_input_changed())
            entries[key] = entry

        # ==========================================
        # Card 5: ⚡ G-Code Options & Optimization
        # ==========================================
        card_opt = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=12)
        card_opt.grid(row=row, column=0, sticky="ew", padx=6, pady=(0, 8))
        card_opt.grid_columnconfigure(0, weight=1)
        row += 1

        ctk.CTkLabel(
            card_opt,
            text="⚡  G-Code Generator Options",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#ccccee",
        ).grid(row=0, column=0, sticky="w", padx=12, pady=(8, 4))

        self.home_var = ctk.BooleanVar(value=bool(cfg.get("home_all", True)))
        ctk.CTkCheckBox(
            card_opt, text="Home all axes before plotting (G28)", variable=self.home_var,
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
            command=lambda: self._queue_live_preview(),
        ).grid(row=1, column=0, sticky="w", padx=12, pady=(2, 2))

        self.optimize_paths_var = ctk.BooleanVar(value=bool(cfg.get("optimize_paths", True)))
        ctk.CTkCheckBox(
            card_opt, text="⚡ Smart Toolpath Optimization (TSP + Chaining)",
            variable=self.optimize_paths_var,
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
            command=lambda: self._queue_live_preview(),
        ).grid(row=2, column=0, sticky="w", padx=12, pady=(2, 6))

        # Output file
        out_box = ctk.CTkFrame(card_opt, fg_color="transparent")
        out_box.grid(row=3, column=0, sticky="ew", padx=12, pady=(2, 8))
        out_box.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(out_box, text="Default Output File", text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).grid(row=0, column=0, sticky="w")
        self.output_entry = ctk.CTkEntry(out_box, fg_color=SURFACE_2, corner_radius=6, font=ctk.CTkFont(size=12))
        self.output_entry.insert(0, cfg.get("output_file", "text_output.gcode"))
        self.output_entry.grid(row=1, column=0, sticky="ew", pady=(2, 0))

        ctk.CTkButton(
            out_box, text="Browse...", width=70, height=28,
            fg_color=SURFACE_2, hover_color="#3a3a5c", corner_radius=6,
            command=self._on_browse_output,
        ).grid(row=1, column=1, padx=(6, 0), pady=(2, 0))

        # ==========================================
        # Card 6: 💾 JSON Configuration Storage & Actions
        # ==========================================
        card_actions = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=12, border_color="#3a3a5c", border_width=1)
        card_actions.grid(row=row, column=0, sticky="ew", padx=6, pady=(4, 12))
        card_actions.grid_columnconfigure((0, 1), weight=1)
        row += 1

        ctk.CTkLabel(
            card_actions,
            text="💾  JSON Configuration Storage",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#ccccee",
        ).grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(8, 2))

        ctk.CTkLabel(
            card_actions,
            text="📁 Active File: plotter_config.json (Auto-saved on exit & generation)",
            font=ctk.CTkFont(size=10),
            text_color=TEXT_DIM,
        ).grid(row=1, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 8))

        # Main save / reset row
        save_btn = ctk.CTkButton(
            card_actions, text="💾  Save to plotter_config.json",
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=ACCENT, hover_color=ACCENT_HOVER, text_color="#0a0a1a",
            height=34, corner_radius=8,
            command=self._on_save_settings,
        )
        save_btn.grid(row=2, column=0, sticky="ew", padx=(10, 4), pady=(0, 6))

        reset_btn = ctk.CTkButton(
            card_actions, text="🔄  Reset to Defaults",
            font=ctk.CTkFont(size=12),
            fg_color=SURFACE_2, hover_color="#3a3a5c",
            height=34, corner_radius=8,
            command=self._on_reset_settings,
        )
        reset_btn.grid(row=2, column=1, sticky="ew", padx=(4, 10), pady=(0, 6))

        # Import / Export profile row
        import_btn = ctk.CTkButton(
            card_actions, text="📥  Import JSON...",
            font=ctk.CTkFont(size=11),
            fg_color=SURFACE_2, hover_color="#3a3a5c",
            height=30, corner_radius=8,
            command=self._on_import_settings,
        )
        import_btn.grid(row=3, column=0, sticky="ew", padx=(10, 4), pady=(0, 6))

        export_btn = ctk.CTkButton(
            card_actions, text="📤  Export JSON As...",
            font=ctk.CTkFont(size=11),
            fg_color=SURFACE_2, hover_color="#3a3a5c",
            height=30, corner_radius=8,
            command=self._on_export_settings,
        )
        export_btn.grid(row=3, column=1, sticky="ew", padx=(4, 10), pady=(0, 6))

        self.settings_status_label = ctk.CTkLabel(
            card_actions,
            text="",
            font=ctk.CTkFont(size=11),
            text_color="#2ed573",
        )
        self.settings_status_label.grid(row=4, column=0, columnspan=2, padx=12, pady=(0, 8))

        self._settings_entries = entries

    # ============================
    # Settings Handlers & Presets
    # ============================
    def _update_bed_sliders(self, bed_x: float, bed_y: float):
        """Update slider bounds and preview canvas when machine bed dimensions or offsets change."""
        try:
            cfg = self._get_config()
            rx_max = cfg.reachable_x_max
            ry_max = cfg.reachable_y_max
            rw = cfg.reachable_width
            rh = cfg.reachable_height

            if hasattr(self, "text_x_slider"):
                self.text_x_slider.configure(to=max(10.0, rx_max), number_of_steps=max(1, int(rx_max)))
            if hasattr(self, "text_y_slider"):
                self.text_y_slider.configure(to=max(10.0, ry_max), number_of_steps=max(1, int(ry_max)))
            if hasattr(self, "img_x_slider"):
                self.img_x_slider.configure(to=max(10.0, rx_max), number_of_steps=max(1, int(rx_max)))
            if hasattr(self, "img_y_slider"):
                self.img_y_slider.configure(to=max(10.0, ry_max), number_of_steps=max(1, int(ry_max)))
            if hasattr(self, "img_width_slider"):
                self.img_width_slider.configure(to=max(5.0, rw))
            if hasattr(self, "img_height_slider"):
                self.img_height_slider.configure(to=max(5.0, rh))
            if hasattr(self, "preview"):
                self.preview.set_bed_size(bed_x, bed_y, cfg.offset_x, cfg.offset_y)
        except Exception:
            pass

    def _apply_offset_preset(self, ox: float, oy: float, oz: float):
        """Apply quick preset values to X, Y, Z toolhead offset entries."""
        if "offset_x" in self._settings_entries:
            self._settings_entries["offset_x"].delete(0, "end")
            self._settings_entries["offset_x"].insert(0, f"{ox:.1f}")
        if "offset_y" in self._settings_entries:
            self._settings_entries["offset_y"].delete(0, "end")
            self._settings_entries["offset_y"].insert(0, f"{oy:.1f}")
        if "offset_z" in self._settings_entries:
            self._settings_entries["offset_z"].delete(0, "end")
            self._settings_entries["offset_z"].insert(0, f"{oz:.1f}")
        self._on_settings_input_changed()

    def _on_settings_input_changed(self):
        """Called when settings entries are modified in UI."""
        try:
            bx = float(self._settings_entries.get("bed_x", None).get() if "bed_x" in self._settings_entries else 220.0)
            by = float(self._settings_entries.get("bed_y", None).get() if "bed_y" in self._settings_entries else 220.0)
            self._update_bed_sliders(bx, by)
        except (ValueError, TypeError):
            pass
        self._update_offset_badges()
        self._queue_live_preview()

    def _update_offset_badges(self):
        """Update active offset badges on Text and Image tabs."""
        try:
            ox = float(self._settings_entries.get("offset_x", None).get() if "offset_x" in self._settings_entries else self._config_data.get("offset_x", 0.0))
            oy = float(self._settings_entries.get("offset_y", None).get() if "offset_y" in self._settings_entries else self._config_data.get("offset_y", 0.0))
            oz = float(self._settings_entries.get("offset_z", None).get() if "offset_z" in self._settings_entries else self._config_data.get("offset_z", 0.0))

            nb_note = "  •  📄 Notebook Ruled Mode" if (hasattr(self, "notebook_enabled_var") and self.notebook_enabled_var.get()) else ""

            if abs(ox) > 0.001 or abs(oy) > 0.001 or abs(oz) > 0.001:
                badge_text = f"🎯 Pen Touching Bed Position: X={ox:+.1f}, Y={oy:+.1f} mm{nb_note}  •  ⚙️ Settings"
                color = "#ffb86c"
            else:
                badge_text = f"🎯 Pen Touching Bed Position: (0, 0) mm{nb_note}  •  ⚙️ Configure in Settings"
                color = "#a78bfa" if nb_note else TEXT_DIM

            if hasattr(self, "text_offset_badge"):
                self.text_offset_badge.configure(text=badge_text, text_color=color)
            if hasattr(self, "img_offset_badge"):
                self.img_offset_badge.configure(text=badge_text, text_color=color)
        except Exception:
            pass

    def _get_current_settings_dict(self) -> Dict[str, Any]:
        """Collect current UI settings into a dictionary."""
        cfg_to_save = {}
        for k, entry in self._settings_entries.items():
            val_str = entry.get().strip()
            try:
                val = float(val_str)
                if val.is_integer() and k in ("safe_wait_ms", "travel_feed", "draw_feed"):
                    cfg_to_save[k] = int(val)
                else:
                    cfg_to_save[k] = val
            except ValueError:
                cfg_to_save[k] = val_str

        cfg_to_save["home_all"] = self.home_var.get()
        cfg_to_save["optimize_paths"] = self.optimize_paths_var.get()
        cfg_to_save["output_file"] = self.output_entry.get()
        cfg_to_save["default_text"] = self.text_input.get("1.0", "end-1c").strip()
        cfg_to_save["default_scale"] = self.text_scale_slider.get()
        cfg_to_save["center_on_bed"] = self.center_var.get()
        cfg_to_save["text_start_x"] = self.text_x_slider.get()
        cfg_to_save["text_start_y"] = self.text_y_slider.get()
        cfg_to_save["font_mode"] = self._font_mode_var.get()
        # Save hershey font key
        try:
            hershey_idx = self.hershey_combo.cget("values").index(self.hershey_combo.get())
            cfg_to_save["hershey_font"] = self._hershey_keys[hershey_idx]
        except (ValueError, IndexError):
            cfg_to_save["hershey_font"] = "futural"
        if hasattr(self, "auto_wrap_var"):
            cfg_to_save["auto_wrap"] = self.auto_wrap_var.get()

        # Notebook page settings
        if hasattr(self, "notebook_enabled_var"):
            cfg_to_save["notebook_enabled"] = self.notebook_enabled_var.get()
        if hasattr(self, "notebook_align_var"):
            val = self.notebook_align_var.get()
            cfg_to_save["notebook_align_mode"] = "centered" if "Centered" in val else "left_margin_at_zero"
        if hasattr(self, "_notebook_entries"):
            nb = self._notebook_entries
            for nb_key in ("margin_bed_x", "line_spacing", "left_margin", "writable_w", "writable_h", "start_line"):
                if nb_key in nb:
                    try:
                        v = float(nb[nb_key].get())
                        cfg_to_save[f"notebook_{nb_key}"] = int(v) if nb_key == "start_line" else v
                    except (ValueError, TypeError):
                        pass

        return cfg_to_save

    def _save_current_settings_silently(self, filepath: Optional[str] = None):
        """Save settings to JSON without popping UI toast."""
        cfg_to_save = self._get_current_settings_dict()
        if filepath:
            config_manager.save_config(cfg_to_save, filepath)
        else:
            config_manager.save_config(cfg_to_save)
            self._config_data = cfg_to_save

    def _on_save_settings(self):
        """Persist current settings to plotter_config.json."""
        cfg_to_save = self._get_current_settings_dict()
        ok = config_manager.save_config(cfg_to_save)
        if ok:
            self._config_data = cfg_to_save
            self.settings_status_label.configure(
                text="✅ Saved to plotter_config.json!",
                text_color="#2ed573",
            )
        else:
            self.settings_status_label.configure(
                text="❌ Failed to save configuration to disk.",
                text_color="#ff4757",
            )
        self._update_offset_badges()
        self._queue_live_preview()

    def _on_import_settings(self):
        """Import settings from a selected JSON file."""
        path = filedialog.askopenfilename(
            title="Import Settings JSON",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if path:
            imported = config_manager.load_config(path)
            for k, entry in self._settings_entries.items():
                if k in imported:
                    entry.delete(0, "end")
                    entry.insert(0, str(imported[k]))
            if "home_all" in imported:
                self.home_var.set(bool(imported["home_all"]))
            if "optimize_paths" in imported:
                self.optimize_paths_var.set(bool(imported["optimize_paths"]))
            if "output_file" in imported:
                self.output_entry.delete(0, "end")
                self.output_entry.insert(0, str(imported["output_file"]))
            if "auto_wrap" in imported and hasattr(self, "auto_wrap_var"):
                self.auto_wrap_var.set(bool(imported["auto_wrap"]))

            # Import notebook settings
            if "notebook_enabled" in imported and hasattr(self, "notebook_enabled_var"):
                self.notebook_enabled_var.set(bool(imported["notebook_enabled"]))
                if self.notebook_enabled_var.get():
                    self._notebook_details.grid()
                else:
                    self._notebook_details.grid_remove()

            if "notebook_align_mode" in imported and hasattr(self, "notebook_align_var"):
                mode = imported["notebook_align_mode"]
                self.notebook_align_var.set("📐 Centered A4 Page" if mode == "centered" else "📌 Red Margin at X=0 (Left Border)")

            if hasattr(self, "_notebook_entries"):
                for nb_k in ("margin_bed_x", "line_spacing", "left_margin", "writable_w", "writable_h", "start_line"):
                    full_k = f"notebook_{nb_k}"
                    if full_k in imported and nb_k in self._notebook_entries:
                        self._notebook_entries[nb_k].delete(0, "end")
                        self._notebook_entries[nb_k].insert(0, str(imported[full_k]))

            # Update bed sliders
            bx = float(imported.get("bed_x", 220.0))
            by = float(imported.get("bed_y", 220.0))
            self._update_bed_sliders(bx, by)

            self._save_current_settings_silently()
            self.settings_status_label.configure(
                text=f"✅ Imported settings from {os.path.basename(path)}",
                text_color="#2ed573",
            )
            self._sync_notebook_overlay()
            self._update_offset_badges()
            self._queue_live_preview()

    def _on_export_settings(self):
        """Export current settings to a chosen JSON file path."""
        path = filedialog.asksaveasfilename(
            title="Export Settings JSON As",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if path:
            cfg_to_save = self._get_current_settings_dict()
            ok = config_manager.save_config(cfg_to_save, path)
            if ok:
                self.settings_status_label.configure(
                    text=f"✅ Exported settings to {os.path.basename(path)}",
                    text_color="#2ed573",
                )
            else:
                self.settings_status_label.configure(
                    text="❌ Failed to export settings.",
                    text_color="#ff4757",
                )

    def _on_reset_settings(self):
        """Reset settings fields to factory defaults."""
        defaults = config_manager.get_default_config()
        for k, entry in self._settings_entries.items():
            entry.delete(0, "end")
            entry.insert(0, str(defaults.get(k, 0)))

        self.home_var.set(bool(defaults.get("home_all", True)))
        self.optimize_paths_var.set(bool(defaults.get("optimize_paths", True)))
        self.output_entry.delete(0, "end")
        self.output_entry.insert(0, defaults.get("output_file", "text_output.gcode"))
        if hasattr(self, "auto_wrap_var"):
            self.auto_wrap_var.set(bool(defaults.get("auto_wrap", True)))

        # Reset notebook settings
        if hasattr(self, "notebook_enabled_var"):
            self.notebook_enabled_var.set(bool(defaults.get("notebook_enabled", False)))
            self._notebook_details.grid_remove()

        if hasattr(self, "notebook_align_var"):
            self.notebook_align_var.set("📌 Red Margin at X=0 (Left Border)")

        if hasattr(self, "_notebook_entries"):
            default_map = {
                "margin_bed_x": 0.0,
                "line_spacing": 8.0,
                "left_margin": 30.0,
                "writable_w": 175.0,
                "writable_h": 250.0,
                "start_line": 1,
            }
            for nb_k in ("margin_bed_x", "line_spacing", "left_margin", "writable_w", "writable_h", "start_line"):
                full_k = f"notebook_{nb_k}"
                if nb_k in self._notebook_entries:
                    self._notebook_entries[nb_k].delete(0, "end")
                    val = defaults.get(full_k, default_map.get(nb_k, 0))
                    self._notebook_entries[nb_k].insert(0, str(val))

        # Reset bed sliders
        bx = float(defaults.get("bed_x", 220.0))
        by = float(defaults.get("bed_y", 220.0))
        self._update_bed_sliders(bx, by)

        self._save_current_settings_silently()
        self.settings_status_label.configure(
            text="🔄 Reset to factory defaults & saved to JSON.",
            text_color=ACCENT,
        )
        self._sync_notebook_overlay()
        self._update_offset_badges()
        self._queue_live_preview()

    def _on_window_close(self):
        """Handle window close event: auto-save current settings to JSON and quit."""
        try:
            self._save_current_settings_silently()
        except Exception:
            pass
        self.destroy()
    # ============================
    # Notebook Page Handlers
    # ============================
    def _on_notebook_toggle(self):
        """Show/hide notebook details panel and update preview overlay."""
        if self.notebook_enabled_var.get():
            self._notebook_details.grid()
            self._sync_notebook_overlay()
            geo = self.preview.get_notebook_geometry()
            if geo is not None:
                try:
                    line_num = max(1, int(float(self._notebook_entries["start_line"].get())))
                except (ValueError, KeyError):
                    line_num = 1
                init_x = geo["margin_x"] + 3.0
                init_y = (geo["wr_y_top"] - line_num * geo["line_spacing"]) + 1.0
                self.text_x_slider.set(init_x)
                self.text_y_slider.set(init_y)
                self.text_x_label.configure(text=f"{init_x:.1f} mm")
                self.text_y_label.configure(text=f"{init_y:.1f} mm")
                self.center_var.set(False)
        else:
            self._notebook_details.grid_remove()
            self._sync_notebook_overlay()
        self._update_offset_badges()
        self._queue_live_preview()

    def _on_notebook_param_changed(self):
        """Called when any notebook parameter entry changes."""
        self._sync_notebook_overlay()
        if self.notebook_enabled_var.get():
            geo = self.preview.get_notebook_geometry()
            if geo is not None:
                try:
                    line_num = max(1, int(float(self._notebook_entries["start_line"].get())))
                    new_y = (geo["wr_y_top"] - line_num * geo["line_spacing"]) + 1.0
                    self.text_y_slider.set(new_y)
                    self.text_y_label.configure(text=f"{new_y:.1f} mm")
                    new_x = geo["margin_x"] + 3.0
                    self.text_x_slider.set(new_x)
                    self.text_x_label.configure(text=f"{new_x:.1f} mm")
                    self.center_var.set(False)
                except (ValueError, KeyError):
                    pass
        self._queue_live_preview()

    def _get_notebook_cfg_dict(self) -> dict:
        """Collect notebook entries into a cfg dict for the preview overlay."""
        e = self._notebook_entries
        def _v(key, default):
            try:
                return float(e[key].get())
            except (ValueError, KeyError):
                return default

        def _val_set(key, default):
            try:
                return float(self._settings_entries[key].get())
            except (ValueError, KeyError, TypeError):
                return float(self._config_data.get(key, default))

        align_mode = "left_margin_at_zero"
        if hasattr(self, "notebook_align_var"):
            val = self.notebook_align_var.get()
            if "Centered" in val:
                align_mode = "centered"
            else:
                align_mode = "left_margin_at_zero"

        return {
            "align_mode": align_mode,
            "margin_bed_x": _v("margin_bed_x", 0.0),
            "line_spacing": _v("line_spacing", 8.0),
            "left_margin": _v("left_margin", 30.0),
            "writable_w": _v("writable_w", 175.0),
            "writable_h": _v("writable_h", 250.0),
            "page_x": -1.0,
            "page_y": -1.0,
            "offset_y": _val_set("offset_y", 0.0),
        }

    def _sync_notebook_overlay(self):
        """Push current notebook state to the preview canvas."""
        enabled = self.notebook_enabled_var.get()
        cfg = self._get_notebook_cfg_dict() if enabled else None
        self.preview.set_notebook_overlay(enabled, cfg)

    # ============================
    # Callbacks
    # ============================
    def _on_tab_change(self):
        """Handle tab switching without losing active image/text content state."""
        tab = self.tabview.get()
        if tab in ("✏️  Text", "🖼️  Image"):
            self._last_active_tab = tab
        self._queue_live_preview(delay_ms=0)

    def _on_font_mode_change(self):
        if self._font_mode_var.get() == "system":
            self._font_controls_frame.grid()
            self._hershey_frame.grid_remove()
        else:
            self._font_controls_frame.grid_remove()
            self._hershey_frame.grid()
        self._queue_live_preview()

    def _on_font_size_change(self, value):
        self.font_size_label.configure(text=f"{int(value)} px")
        self._queue_live_preview()

    def _on_text_scale_change(self, value):
        self.text_scale_label.configure(text=f"{value:.1f} mm")
        self._queue_live_preview()

    def _on_text_x_change(self, value):
        self.text_x_label.configure(text=f"{value:.1f} mm")
        self.center_var.set(False)
        self._queue_live_preview()

    def _on_text_y_change(self, value):
        self.text_y_label.configure(text=f"{value:.1f} mm")
        self.center_var.set(False)
        self._queue_live_preview()

    def _on_center_toggle(self):
        if self.center_var.get() and self.notebook_enabled_var.get():
            geo = self.preview.get_notebook_geometry()
            if geo is not None:
                try:
                    line_num = max(1, int(float(self._notebook_entries["start_line"].get())))
                except (ValueError, KeyError):
                    line_num = 1
                init_x = geo["margin_x"] + 3.0
                init_y = (geo["wr_y_top"] - line_num * geo["line_spacing"]) + 1.0
                self.text_x_slider.set(init_x)
                self.text_y_slider.set(init_y)
                self.text_x_label.configure(text=f"{init_x:.1f} mm")
                self.text_y_label.configure(text=f"{init_y:.1f} mm")
        self._queue_live_preview()

    def _on_center_img_toggle(self):
        self._queue_live_preview()

    def _on_img_x_change(self, value):
        self.img_x_label.configure(text=f"{value:.1f} mm")
        self.center_img_var.set(False)
        self._queue_live_preview()

    def _on_img_y_change(self, value):
        self.img_y_label.configure(text=f"{value:.1f} mm")
        self.center_img_var.set(False)
        self._queue_live_preview()

    def _on_threshold_change(self, value):
        self.threshold_label.configure(text=f"{int(value)}")
        self._queue_live_preview()

    def _on_lock_aspect_toggle(self):
        """When aspect ratio lock is toggled, synchronize height if locked."""
        if self.lock_aspect_var.get() and hasattr(self, "_img_aspect_ratio") and self._img_aspect_ratio > 0:
            w = self.img_width_slider.get()
            new_h = max(5.0, min(float(self._config_data.get("bed_y", 220.0)), w * self._img_aspect_ratio))
            self.img_height_slider.set(new_h)
            self.img_height_label.configure(text=f"{new_h:.1f} mm")
        self._queue_live_preview()

    def _on_img_width_change(self, value):
        self.img_width_label.configure(text=f"{value:.1f} mm")
        if self.lock_aspect_var.get() and hasattr(self, "_img_aspect_ratio") and self._img_aspect_ratio > 0:
            new_h = max(5.0, min(float(self._config_data.get("bed_y", 220.0)), value * self._img_aspect_ratio))
            self.img_height_slider.set(new_h)
            self.img_height_label.configure(text=f"{new_h:.1f} mm")
        self._queue_live_preview()

    def _on_img_height_change(self, value):
        self.img_height_label.configure(text=f"{value:.1f} mm")
        if self.lock_aspect_var.get() and hasattr(self, "_img_aspect_ratio") and self._img_aspect_ratio > 0:
            new_w = max(5.0, min(float(self._config_data.get("bed_x", 220.0)), value / self._img_aspect_ratio))
            self.img_width_slider.set(new_w)
            self.img_width_label.configure(text=f"{new_w:.1f} mm")
        self._queue_live_preview()

    def _on_img_rotation_change(self, value):
        val_int = int(round(value))
        self.img_rot_label.configure(text=f"{val_int:+}°" if val_int != 0 else "0°")
        self._queue_live_preview()

    def _set_img_rotation(self, deg: float):
        deg = max(-180.0, min(180.0, deg))
        self.img_rot_slider.set(deg)
        self._on_img_rotation_change(deg)

    def _on_img_smooth_change(self, value):
        lvl = int(round(value))
        labels = {0: "0 (Raw / Sharp)", 1: "1 (Subtle)", 2: "2 (Flowing)", 3: "3 (High)", 4: "4 (Ultra-Smooth)"}
        self.img_smooth_label.configure(text=labels.get(lvl, f"{lvl}"))
        self._queue_live_preview()

    def _on_browse_image(self):
        path = filedialog.askopenfilename(
            title="Select Image",
            filetypes=[
                ("Images", "*.png *.jpg *.jpeg *.bmp *.tiff *.tif *.webp *.gif"),
                ("All files", "*.*"),
            ],
        )
        if path:
            self._load_image(path)
            self._queue_live_preview()

    def _on_browse_output(self):
        path = filedialog.asksaveasfilename(
            title="Save G-Code As",
            defaultextension=".gcode",
            filetypes=[("G-Code files", "*.gcode"), ("All files", "*.*")],
        )
        if path:
            self.output_entry.delete(0, "end")
            self.output_entry.insert(0, path)

    def _load_image(self, path: str):
        """Load and display an image."""
        self._current_image_path = path
        self._last_active_tab = "🖼️  Image"
        filename = os.path.basename(path)

        try:
            from PIL import Image as PILImage
            img = PILImage.open(path)
            w, h = img.size
            self._img_aspect_ratio = float(h) / float(w) if w > 0 else 1.0

            # Set initial proportional dimensions
            bed_x = float(self._config_data.get("bed_x", 220.0))
            bed_y = float(self._config_data.get("bed_y", 220.0))
            init_w = min(120.0, bed_x * 0.8)
            init_h = min(init_w * self._img_aspect_ratio, bed_y * 0.8)

            self.img_width_slider.set(init_w)
            self.img_height_slider.set(init_h)
            self.img_width_label.configure(text=f"{init_w:.1f} mm")
            self.img_height_label.configure(text=f"{init_h:.1f} mm")

            self.image_info_label.configure(
                text=f"📎 {filename}  ({w}×{h} px)",
                text_color=ACCENT,
            )
            self.drop_label.configure(text=f"✅  {filename}")
        except Exception as e:
            self.image_info_label.configure(
                text=f"❌ Error: {e}",
                text_color="#ff4757",
            )

    # ============================
    # Canvas Drag & Hover Interactions
    # ============================
    def _on_preview_drag_move(self, dx: float, dy: float, is_done: bool):
        """Move artwork when dragged on canvas with mouse."""
        tab = self.tabview.get()
        active_tab = tab if tab in ("✏️  Text", "🖼️  Image") else getattr(self, "_last_active_tab", "✏️  Text")
        cfg = self._get_config()
        rx_min = cfg.reachable_x_min
        rx_max = cfg.reachable_x_max
        ry_min = cfg.reachable_y_min
        ry_max = cfg.reachable_y_max

        if active_tab == "✏️  Text":
            if self.center_var.get():
                self.center_var.set(False)

            current_x = self.text_x_slider.get()
            current_y = self.text_y_slider.get()
            new_x = max(rx_min, min(rx_max, current_x + dx))
            new_y = max(ry_min, min(ry_max, current_y + dy))

            self.text_x_slider.set(new_x)
            self.text_y_slider.set(new_y)
            self.text_x_label.configure(text=f"{new_x:.1f} mm")
            self.text_y_label.configure(text=f"{new_y:.1f} mm")

            if self.notebook_enabled_var.get() and hasattr(self, "_notebook_entries"):
                geo = self.preview.get_notebook_geometry()
                if geo is not None and "start_line" in self._notebook_entries:
                    line_num = max(1, min(geo["num_lines"], int(round((geo["wr_y_top"] - new_y + 1.0) / geo["line_spacing"]))))
                    self._notebook_entries["start_line"].delete(0, "end")
                    self._notebook_entries["start_line"].insert(0, str(line_num))

        else:
            if self.center_img_var.get():
                self.center_img_var.set(False)

            current_x = self.img_x_slider.get()
            current_y = self.img_y_slider.get()
            new_x = max(rx_min, min(rx_max, current_x + dx))
            new_y = max(ry_min, min(ry_max, current_y + dy))

            self.img_x_slider.set(new_x)
            self.img_y_slider.set(new_y)
            self.img_x_label.configure(text=f"{new_x:.1f} mm")
            self.img_y_label.configure(text=f"{new_y:.1f} mm")

        self._queue_live_preview(delay_ms=0)

    def _on_preview_hover(self, wx: float, wy: float, bbox: Optional[Tuple[float, float, float, float]]):
        """Update top-right header with live mm stats and time on hover."""
        est_str = getattr(self.preview, "_est_time_str", "--")
        if bbox is not None:
            min_x, min_y, max_x, max_y = bbox
            w = max_x - min_x
            h = max_y - min_y
            self.stats_label.configure(
                text=f"⏱️ Est: ~{est_str}  |  📏 Size: {w:.1f} × {h:.1f} mm  |  Pos: ({min_x:.1f}, {min_y:.1f}) mm  |  Cursor: ({wx:.1f}, {wy:.1f}) mm"
            )
        else:
            self.stats_label.configure(
                text=f"⏱️ Est: ~{est_str}  |  Cursor: ({wx:.1f}, {wy:.1f}) mm"
            )

    # ============================
    # Drag & Drop
    # ============================
    def _setup_dnd(self):
        """Setup drag-and-drop support."""
        try:
            from tkinterdnd2 import DND_FILES
            self.drop_target_register(DND_FILES)
            self.dnd_bind("<<Drop>>", self._on_drop)
            self.drop_zone.configure(border_color=ACCENT)
        except Exception:
            pass

    def _on_drop(self, event):
        """Handle dropped files."""
        path = event.data.strip()
        if path.startswith("{") and path.endswith("}"):
            path = path[1:-1]

        ext = os.path.splitext(path)[1].lower()
        image_exts = {".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".tif", ".webp", ".gif"}

        if ext == ".svg":
            self._current_pcb_path = path
            fname = os.path.basename(path)
            if hasattr(self, "pcb_file_label"):
                self.pcb_file_label.configure(text=f"✅ {fname}", text_color="#2ed573")
            self.tabview.set("⚡ PCB")
            self._sync_pcb_overlay()
            self._queue_live_preview()
        elif ext in image_exts:
            self._load_image(path)
            self.tabview.set("🖼️  Image")
            self._queue_live_preview()
        else:
            messagebox.showwarning("Unsupported File", f"File type '{ext}' is not supported.")

    # ============================
    # Font Loading
    # ============================
    def _load_fonts_async(self):
        """Load system fonts in background thread."""
        def _load():
            fonts = font_manager.discover_fonts()
            self._fonts_dict = fonts
            names = list(fonts.keys()) if fonts else ["(no fonts found)"]
            try:
                self.after(0, lambda: self._update_font_list(names))
            except Exception:
                pass

        t = threading.Thread(target=_load, daemon=True)
        t.start()

    def _update_font_list(self, names):
        self.font_combo.configure(values=names)
        if names:
            self.font_combo.set(names[0])

    def _on_tab_change(self):
        """Called when user switches tabs."""
        tab = self.tabview.get()
        if tab in ("✏️  Text", "🖼️  Image", "⚡ PCB"):
            self._last_active_tab = tab

        if tab == "⚡ PCB":
            self._sync_pcb_overlay()
            self.preview.set_notebook_overlay(False)
        elif tab == "✏️  Text":
            self.preview.set_pcb_overlay(False)
            self._sync_notebook_overlay()
        else:
            self.preview.set_pcb_overlay(False)
            self.preview.set_notebook_overlay(False)

        self._queue_live_preview()

    # ============================
    # Live Preview & Generation
    # ============================
    def _get_config(self) -> PlotterConfig:
        """Build a PlotterConfig from current UI settings."""
        e = self._settings_entries

        # Get selected Hershey font key
        hershey_idx = 0
        hershey_display = [f"{v}  ({k})" for k, v in HERSHEY_FONTS.items()]
        selected = self.hershey_combo.get()
        if selected in hershey_display:
            hershey_idx = hershey_display.index(selected)
        hershey_key = self._hershey_keys[hershey_idx] if hershey_idx < len(self._hershey_keys) else "futural"

        tab = self.tabview.get()
        active_tab = tab if tab in ("✏️  Text", "🖼️  Image", "⚡ PCB") else getattr(self, "_last_active_tab", "✏️  Text")
        if active_tab == "✏️  Text":
            start_x = self.text_x_slider.get()
            start_y = self.text_y_slider.get()
            center = self.center_var.get()
        elif active_tab == "🖼️  Image":
            start_x = self.img_x_slider.get()
            start_y = self.img_y_slider.get()
            center = self.center_img_var.get()
        else:
            start_x = float(self.pcb_x_slider.get()) if hasattr(self, "pcb_x_slider") else 30.0
            start_y = float(self.pcb_y_slider.get()) if hasattr(self, "pcb_y_slider") else 40.0
            center = False

        def _val(key: str, default: float) -> float:
            """Read a float value from settings entries, falling back to saved JSON config."""
            if key in e:
                try:
                    return float(e[key].get() or default)
                except (ValueError, TypeError):
                    return float(default)
            # Fallback: read from saved JSON config data
            if key in self._config_data:
                try:
                    return float(self._config_data[key])
                except (ValueError, TypeError):
                    pass
            return float(default)

        def _int_val(key: str, default: int) -> int:
            """Read an int value from settings entries, falling back to saved JSON config."""
            if key in e:
                try:
                    return int(float(e[key].get() or default))
                except (ValueError, TypeError):
                    return int(default)
            if key in self._config_data:
                try:
                    return int(float(self._config_data[key]))
                except (ValueError, TypeError):
                    pass
            return int(default)

        return PlotterConfig(
            bed_x=_val("bed_x", 220.0),
            bed_y=_val("bed_y", 220.0),
            pen_touch_z=_val("pen_touch_z", 0.0),
            z_hop=_val("z_hop", 2.0),
            safe_lift_z=_val("safe_lift_z", 30.0),
            safe_wait_ms=_int_val("safe_wait_ms", 5000),
            travel_feed=_int_val("travel_feed", 2500),
            draw_feed=_int_val("draw_feed", 1200),
            offset_x=_val("offset_x", 0.0),
            offset_y=_val("offset_y", 0.0),
            offset_z=_val("offset_z", 0.0),
            output_file=self.output_entry.get() or "text_output.gcode",
            home_all=self.home_var.get(),
            text=self.text_input.get("1.0", "end-1c"),
            scale=self.text_scale_slider.get(),
            start_x=start_x,
            start_y=start_y,
            center_text=center,
            hershey_font=hershey_key,
            optimize_paths=self.optimize_paths_var.get(),
            auto_wrap=self.auto_wrap_var.get() if hasattr(self, "auto_wrap_var") else True,
        )

    def _queue_live_preview(self, delay_ms: int = 40):
        """Debounced live preview refresh."""
        if self._preview_job is not None:
            self.after_cancel(self._preview_job)
        self._preview_job = self.after(delay_ms, self._update_live_preview)

    def _update_live_preview(self):
        """Regenerate toolpaths and update preview canvas."""
        self._preview_job = None
        try:
            cfg = self._get_config()
            self._update_bed_sliders(cfg.bed_x, cfg.bed_y)
            self.preview.set_bed_size(cfg.bed_x, cfg.bed_y, cfg.offset_x, cfg.offset_y)

            tab = self.tabview.get()
            active_tab = tab if tab in ("✏️  Text", "🖼️  Image", "⚡ PCB") else getattr(self, "_last_active_tab", "✏️  Text")
            if active_tab == "⚡ PCB":
                self._sync_pcb_overlay()
                self.preview.set_notebook_overlay(False)
                writer = self._generate_pcb(cfg)
            elif active_tab == "🖼️  Image":
                self.preview.set_pcb_overlay(False)
                self.preview.set_notebook_overlay(False)
                writer = self._generate_image(cfg)
            else:
                self.preview.set_pcb_overlay(False)
                self._sync_notebook_overlay()
                writer = self._generate_text(cfg)

            if writer is not None:
                self._last_builder = writer
                self.preview.load_from_builder(writer)
                _, est_time_str, draw_d, travel_d = writer.estimate_time()
                bbox_dims = self.preview.get_bbox_dimensions()
                if bbox_dims:
                    min_x, min_y, max_x, max_y, w, h = bbox_dims
                    # If auto-centered, reflect the calculated position in labels
                    if (active_tab == "✏️  Text" and cfg.center_text):
                        self.text_x_label.configure(text=f"{min_x:.1f} mm (center)")
                        self.text_y_label.configure(text=f"{min_y:.1f} mm (center)")
                        self.text_x_slider.set(min_x)
                        self.text_y_slider.set(min_y)
                    elif (active_tab == "🖼️  Image" and self.center_img_var.get()):
                        self.img_x_label.configure(text=f"{min_x:.1f} mm (center)")
                        self.img_y_label.configure(text=f"{min_y:.1f} mm (center)")
                        self.img_x_slider.set(min_x)
                        self.img_y_slider.set(min_y)

                # Machine Bounds / Out-of-bounds safety check
                m_bounds = writer.get_machine_bounds()
                out_of_bounds = False
                bounds_msg = ""
                if m_bounds:
                    min_mx, min_my, max_mx, max_my = m_bounds
                    if min_mx < 0 or max_mx > cfg.bed_x or min_my < 0 or max_my > cfg.bed_y:
                        out_of_bounds = True
                        bounds_msg = (
                            f"⚠️ Offset Warning: Machine carriage moves (X: {min_mx:.1f}..{max_mx:.1f} mm, "
                            f"Y: {min_my:.1f}..{max_my:.1f} mm) exceed bed boundaries (0..{cfg.bed_x:.0f}, 0..{cfg.bed_y:.0f})!"
                        )

                if out_of_bounds:
                    self.bounds_warning_label.configure(text=bounds_msg)
                    self.bounds_warning_frame.grid()
                else:
                    self.bounds_warning_frame.grid_remove()

                offset_str = ""
                if abs(cfg.offset_x) > 0.001 or abs(cfg.offset_y) > 0.001 or abs(cfg.offset_z) > 0.001:
                    offset_str = f"  |  🎯 Offset: ({cfg.offset_x:+.1f}, {cfg.offset_y:+.1f}, {cfg.offset_z:+.1f}) mm"

                if bbox_dims:
                    min_x, min_y, max_x, max_y, w, h = bbox_dims
                    self.stats_label.configure(
                        text=f"⏱️ Est: ~{est_time_str}  |  📏 {w:.1f} × {h:.1f} mm  |  Pos: ({min_x:.1f}, {min_y:.1f}) mm{offset_str}  |  {len(writer.lines)} lines"
                    )
        except Exception:
            pass

    def _on_preview_erase(self, remaining_segments, history_len: int):
        """Called when user erases strokes or undos an erase on canvas."""
        if hasattr(self, "undo_erase_btn"):
            if history_len > 0:
                self.undo_erase_btn.configure(state="normal", text=f"↩️ Undo ({history_len})", fg_color=ACCENT, text_color="#0a0a1a")
                self.reset_erase_btn.configure(state="normal", text_color="#ff6b81")
            else:
                self.undo_erase_btn.configure(state="disabled", text="↩️ Undo Erase", fg_color=SURFACE, text_color="#ccccee")
                self.reset_erase_btn.configure(state="disabled", text_color=TEXT_DIM)

    def _on_undo_erase(self):
        """Undo the last right-click erase action."""
        remaining = self.preview.undo_erase()
        self._on_preview_erase(self.preview._draw_segments, remaining)

    def _on_reset_erase(self):
        """Reset all erased strokes back to original."""
        self.preview.reset_erased()
        self._on_preview_erase(self.preview._draw_segments, 0)

    def _on_generate(self):
        """Generate and save G-code to file (and auto-save settings to JSON)."""
        if self._generating:
            return
        self._generating = True
        self._save_current_settings_silently()
        self.generate_btn.configure(state="disabled", text="⏳  Writing G-Code...")
        self.status_label.configure(text="Generating G-Code...", text_color=ACCENT)

        current_tab = self.tabview.get()
        t = threading.Thread(target=self._do_generate, args=(current_tab,), daemon=True)
        t.start()

    def _do_generate(self, tab: str):
        """Background worker to save G-code file."""
        try:
            cfg = self._get_config()
            self.preview.set_bed_size(cfg.bed_x, cfg.bed_y)

            active_tab = tab if tab in ("✏️  Text", "🖼️  Image", "⚡ PCB") else getattr(self, "_last_active_tab", "✏️  Text")
            if self.preview.has_erased_segments():
                remaining_polys = self.preview.get_remaining_polylines()
                writer = generate_gcode_paths(cfg, remaining_polys)
            elif active_tab == "⚡ PCB":
                writer = self._generate_pcb(cfg)
            elif active_tab == "🖼️  Image":
                writer = self._generate_image(cfg)
            else:
                writer = self._generate_text(cfg)

            if writer is None:
                self.after(0, lambda: self._generation_error("No output generated."))
                return

            save_gcode(cfg, writer)
            line_count = len(writer.lines)
            _, est_time_str, draw_dist, travel_dist = writer.estimate_time()

            offset_info = ""
            if abs(cfg.offset_x) > 0.001 or abs(cfg.offset_y) > 0.001 or abs(cfg.offset_z) > 0.001:
                offset_info = f" • Offset: ({cfg.offset_x:+.1f}, {cfg.offset_y:+.1f}, {cfg.offset_z:+.1f}) mm"

            def _update():
                self.preview.load_from_builder(writer)
                self.status_label.configure(
                    text=f"✅ Saved to {cfg.output_file} ({line_count} lines • ⏱️ ~{est_time_str}{offset_info})",
                    text_color="#2ed573",
                )
                self.generate_btn.configure(state="normal", text="⚡  Generate File")
                self._generating = False

            self.after(0, _update)

        except Exception as e:
            self.after(0, lambda: self._generation_error(str(e)))

    # ============================
    # Removable Media (SD / USB) Handlers
    # ============================
    def _check_removable_drives(self):
        """Periodically scan for removable media (SD card / USB flash drive) in a background thread."""
        def _worker():
            try:
                drives = media_manager.get_removable_drives()
                def _update_ui():
                    self._detected_removable_drives = drives
                    if hasattr(self, "removable_btn"):
                        if drives:
                            drv = drives[0]
                            short_lbl = drv["short_display"]
                            self.removable_btn.configure(
                                state="normal",
                                text=f"💾 Save to {short_lbl}",
                                fg_color="#2ed573",
                                hover_color="#26af5f",
                                text_color="#0a0a1a",
                            )
                            self.eject_btn.grid(row=0, column=1, sticky="e", padx=(4, 0))
                        else:
                            self.removable_btn.configure(
                                state="disabled",
                                text="💾 No SD/USB Media",
                                fg_color=SURFACE_2,
                                text_color=TEXT_DIM,
                            )
                            self.eject_btn.grid_remove()
                self.after(0, _update_ui)
            except Exception:
                pass
            finally:
                try:
                    self._drive_scan_job = self.after(3500, self._check_removable_drives)
                except Exception:
                    pass

        threading.Thread(target=_worker, daemon=True).start()

    def _on_save_to_removable(self):
        """Save current G-code directly to the connected removable SD card / USB drive."""
        if not self._detected_removable_drives:
            self._detected_removable_drives = media_manager.get_removable_drives()

        if not self._detected_removable_drives:
            messagebox.showinfo(
                "No Removable Media",
                "No removable SD card or USB flash drive was detected.\n\nPlease insert your SD card or USB drive and try again."
            )
            return

        drv = self._detected_removable_drives[0]
        drive_path = drv["path"]

        cfg = self._get_config()
        self.preview.set_bed_size(cfg.bed_x, cfg.bed_y)

        tab = self.tabview.get()
        active_tab = tab if tab in ("✏️  Text", "🖼️  Image", "⚡ PCB") else getattr(self, "_last_active_tab", "✏️  Text")
        if self.preview.has_erased_segments():
            remaining_polys = self.preview.get_remaining_polylines()
            writer = generate_gcode_paths(cfg, remaining_polys)
        elif active_tab == "⚡ PCB":
            writer = self._generate_pcb(cfg)
        elif active_tab == "🖼️  Image":
            writer = self._generate_image(cfg)
        else:
            writer = self._generate_text(cfg)

        if writer is None:
            self._generation_error("No G-Code output could be generated.")
            return

        filename = os.path.basename(cfg.output_file or "text_output.gcode")
        ok, full_path, msg = media_manager.save_gcode_to_removable(writer.lines, drive_path, filename)

        if ok:
            self._save_current_settings_silently()
            self.preview.load_from_builder(writer)
            _, est_time_str, _, _ = writer.estimate_time()
            self.status_label.configure(
                text=f"✅ Saved to {full_path} ({len(writer.lines)} lines • 💾 {drv['short_display']} • ⏱️ ~{est_time_str})",
                text_color="#2ed573",
            )
        else:
            self._generation_error(msg)

    def _on_eject_removable(self):
        """Safely eject the connected removable drive."""
        if not self._detected_removable_drives:
            return

        drv = self._detected_removable_drives[0]
        drive_path = drv["path"]
        ok, msg = media_manager.eject_drive(drive_path)

        if ok:
            self.status_label.configure(
                text=f"⏏️ {msg}",
                text_color="#2ed573",
            )
            self._check_removable_drives()
        else:
            self.status_label.configure(
                text=f"⚠️ {msg}",
                text_color="#ffb86c",
            )

    def _generate_text(self, cfg: PlotterConfig) -> Optional[GCodeBuilder]:
        """Generate G-code for text. When notebook mode is on, position text on ruled lines with auto-wrap."""
        font_mode = self._font_mode_var.get()

        # Notebook mode: override cfg to align text with ruled lines and set wrap limit
        if self.notebook_enabled_var.get():
            geo = self.preview.get_notebook_geometry()
            if geo is not None:
                nb_line_spacing = geo["line_spacing"]
                nb_margin_x = geo["margin_x"]
                nb_wr_y_top = geo["wr_y_top"]
                nb_writable_w = geo["writable_w"]
                nb_wr_x = geo["wr_x"]
                nb_left_margin = geo["left_margin"]

                # Text height = ~75% of line spacing (comfortable fit)
                text_height = nb_line_spacing * 0.75
                cfg.scale = text_height

                # Maximum width before reaching right notebook margin
                cfg.max_width = max(30.0, (geo["wr_x"] + geo["writable_w"] - 4.0) - cfg.start_x)

                # If center_text is True (initial snap or center toggled), align to start_line & margin
                if cfg.center_text:
                    try:
                        start_line_num = max(1, int(float(self._notebook_entries["start_line"].get())))
                    except (ValueError, KeyError):
                        start_line_num = 1

                    # Baseline rests slightly above the lower ruled line of the band:
                    text_start_y = (nb_wr_y_top - start_line_num * nb_line_spacing) + 1.0
                    text_start_x = nb_margin_x + 3.0  # 3mm right of red margin
                    cfg.start_x = text_start_x
                    cfg.start_y = text_start_y
                    cfg.max_width = max(30.0, (geo["wr_x"] + geo["writable_w"] - 4.0) - text_start_x)
                    cfg.center_text = False

                # Set line spacing factor so multi-line text exactly matches ruled lines
                if text_height > 0:
                    cfg.line_spacing = nb_line_spacing / text_height

        if font_mode == "vector":
            # Hershey font vector mode
            return generate_gcode_text(cfg)
        else:
            # System TTF font
            font_name = self.font_combo.get()
            font_path = self._fonts_dict.get(font_name)
            font_size = int(self.font_size_slider.get())
            fill_mode = self.font_fill_var.get()

            text = cfg.text
            if cfg.auto_wrap and text:
                wrap_limit = cfg.max_width if cfg.max_width > 5.0 else (cfg.bed_x * 0.85 if cfg.center_text else max(30.0, cfg.bed_x - cfg.start_x - 10.0))
                text = wrap_text_to_width(text, "futural", cfg.scale, wrap_limit)

            if self.notebook_enabled_var.get():
                geo = self.preview.get_notebook_geometry()
                avail_w = (geo["writable_w"] - geo["left_margin"] - 6.0) if geo else (cfg.bed_x * 0.8)
                target_width = min(avail_w, cfg.scale * len(text) * 0.8)
                target_width = max(target_width, 10.0)
            else:
                target_width = cfg.scale * len(text) * 1.2
                target_width = max(target_width, 40.0)
                target_width = min(target_width, cfg.bed_x * 0.95)

            paths, _, _ = font_manager.text_to_paths(
                text=text,
                font_path=font_path,
                font_size=font_size,
                target_width_mm=target_width,
                fill_mode=fill_mode,
            )

            if not paths:
                return None

            offset_x, offset_y = cfg.start_x, cfg.start_y
            if cfg.center_text:
                all_x = [p[0] for poly in paths for p in poly]
                all_y = [p[1] for poly in paths for p in poly]
                if all_x and all_y:
                    path_w = max(all_x) - min(all_x)
                    path_h = max(all_y) - min(all_y)
                    avail_w = cfg.reachable_width if cfg.reachable_width > 5.0 else cfg.bed_x
                    avail_h = cfg.reachable_height if cfg.reachable_height > 5.0 else cfg.bed_y
                    offset_x = cfg.reachable_x_min + max(0.0, (avail_w - path_w) / 2.0) - min(all_x)
                    offset_y = cfg.reachable_y_min + max(0.0, (avail_h - path_h) / 2.0) - min(all_y)

            return generate_gcode_paths(cfg, paths, offset_x, offset_y)

    def _on_signature_mode_toggle(self):
        """Toggle signature single-stroke mode on/off."""
        if self.signature_mode_var.get():
            self.fill_mode_var.set("signature (single-stroke)")
            self.sig_desc_label.configure(
                text="✅ Active: Centerline skeletonization extracts 1 clean stroke without double borders.",
                text_color="#2ed573",
            )
        else:
            self.fill_mode_var.set("contour")
            self.sig_desc_label.configure(
                text="Extracts clean 1-line center strokes from ink/pen without double outlines.",
                text_color=TEXT_DIM,
            )
        self._queue_live_preview()

    def _on_fill_mode_change(self, val):
        """Called when fill mode combo box changes."""
        if "signature" in val:
            self.signature_mode_var.set(True)
            self.sig_desc_label.configure(
                text="✅ Active: Centerline skeletonization extracts 1 clean stroke without double borders.",
                text_color="#2ed573",
            )
        else:
            self.signature_mode_var.set(False)
            self.sig_desc_label.configure(
                text="Extracts clean 1-line center strokes from ink/pen without double outlines.",
                text_color=TEXT_DIM,
            )
        self._queue_live_preview()

    def _generate_image(self, cfg: PlotterConfig) -> Optional[GCodeBuilder]:
        """Generate G-code from an image with Signature Mode support."""
        if not self._current_image_path:
            return None

        target_width = float(self.img_width_slider.get())
        target_height = float(self.img_height_slider.get()) if hasattr(self, "img_height_slider") else None
        threshold = int(self.threshold_slider.get())
        invert = self.invert_var.get()
        adaptive = self.adaptive_var.get()

        fill_mode = self.fill_mode_var.get()
        if self.signature_mode_var.get() or "signature" in fill_mode:
            effective_fill = "signature"
        elif "centerline" in fill_mode:
            effective_fill = "centerline"
        elif "hatch" in fill_mode:
            effective_fill = "hatch"
        elif "both" in fill_mode:
            effective_fill = "both"
        else:
            effective_fill = "contour"

        rotation_deg = float(self.img_rot_slider.get()) if hasattr(self, "img_rot_slider") else 0.0
        smooth_iter = int(self.img_smooth_slider.get()) if hasattr(self, "img_smooth_slider") else 2

        paths, img_w, img_h = image_processor.image_to_paths(
            image_path=self._current_image_path,
            target_width_mm=target_width,
            target_height_mm=target_height,
            threshold=threshold,
            invert=invert,
            adaptive_threshold=adaptive,
            simplify=0.5,
            fill_mode=effective_fill,
            hatch_spacing=3.0,
            hatch_angle=45.0,
            rotation_deg=rotation_deg,
            smooth_iterations=smooth_iter,
        )

        if not paths:
            return None

        offset_x, offset_y = self.img_x_slider.get(), self.img_y_slider.get()
        if self.center_img_var.get():
            all_x = [p[0] for poly in paths for p in poly]
            all_y = [p[1] for poly in paths for p in poly]
            if all_x and all_y:
                path_w = max(all_x) - min(all_x)
                path_h = max(all_y) - min(all_y)
                avail_w = cfg.reachable_width if cfg.reachable_width > 5.0 else cfg.bed_x
                avail_h = cfg.reachable_height if cfg.reachable_height > 5.0 else cfg.bed_y
                offset_x = cfg.reachable_x_min + max(0.0, (avail_w - path_w) / 2.0) - min(all_x)
                offset_y = cfg.reachable_y_min + max(0.0, (avail_h - path_h) / 2.0) - min(all_y)

        return generate_gcode_paths(cfg, paths, offset_x, offset_y)

    def _generation_error(self, msg: str):
        """Handle generation errors."""
        self.status_label.configure(text=f"❌ Error: {msg}", text_color="#ff4757")
        self.generate_btn.configure(state="normal", text="⚡  Generate G-Code File")
        self._generating = False


def launch_gui():
    """Create and run the GUI application."""
    app = PlotterGUI()
    app.mainloop()
