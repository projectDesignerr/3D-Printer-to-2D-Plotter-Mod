"""
image_processor.py — Image loading, processing, contour extraction, and
conversion to pen-plotter polylines.

Supports any image format Pillow can read (JPEG, PNG, BMP, TIFF, WebP, etc.).
Black regions in the image are traced as drawing paths.

Includes a specialized "line art" mode that uses skeletonization to trace
the CENTER of strokes — critical for preserving fine detail in drawings.
"""

import math
import collections
import heapq
from typing import List, Tuple, Optional, Dict, Set

import cv2
import numpy as np
from PIL import Image

from gcode_engine import Polyline


# -----------------------------
# Image loading & preprocessing
# -----------------------------
def load_image(path: str) -> np.ndarray:
    """
    Load an image from disk with automatic Color-Aware Ink Extraction.
    Accurately extracts blue pen, black pen, red pen, and fountain pen ink by calculating
    optical ink absorption and chrominance distance from paper background.
    Supports any format Pillow can read (PNG, JPEG, WebP, TIFF, BMP, etc.).
    """
    pil_img = Image.open(path)

    # Handle alpha channel (transparency) by pasting onto white paper background
    if pil_img.mode in ("RGBA", "LA") or ("transparency" in pil_img.info):
        bg = Image.new("RGBA", pil_img.size, (255, 255, 255, 255))
        bg.paste(pil_img, mask=pil_img.split()[-1] if pil_img.mode == "RGBA" else None)
        pil_img = bg.convert("RGB")
    elif pil_img.mode != "RGB":
        pil_img = pil_img.convert("RGB")

    rgb = np.array(pil_img, dtype=np.float32)
    r = rgb[:, :, 0]
    g = rgb[:, :, 1]
    b = rgb[:, :, 2]

    # Optical ink density (minimum channel absorbs the most light across blue, red, black inks)
    # Blue ink reflects blue but strongly absorbs red (low R).
    # Red ink reflects red but strongly absorbs green/blue (low G/B).
    # Black ink absorbs all channels (low R, G, B).
    min_channel = np.minimum(r, np.minimum(g, b))

    # Chromatic ink contrast: measure color difference from estimated paper background
    paper_r = float(np.percentile(r, 85))
    paper_g = float(np.percentile(g, 85))
    paper_b = float(np.percentile(b, 85))

    dr = np.maximum(0.0, paper_r - r)
    dg = np.maximum(0.0, paper_g - g)
    db = np.maximum(0.0, paper_b - b)
    chroma_ink = np.sqrt(dr**2 + dg**2 + db**2)

    # Blend optical absorption with chromatic ink contrast for maximum clarity
    max_chroma = float(np.max(chroma_ink))
    if max_chroma > 10.0:
        p98 = float(np.percentile(chroma_ink, 98))
        norm_chroma = np.clip(chroma_ink / (p98 + 1e-5), 0.0, 1.0)
        enhanced_gray = 255.0 - (norm_chroma * 255.0)
        final_gray = 0.4 * min_channel + 0.6 * enhanced_gray
    else:
        final_gray = min_channel

    return np.clip(final_gray, 0, 255).astype(np.uint8)


def rotate_polylines(
    paths: List[Polyline],
    angle_deg: float,
    center_x: Optional[float] = None,
    center_y: Optional[float] = None,
) -> List[Polyline]:
    """
    Rotate polylines in pure 2D vector space with zero raster resampling noise.
    Eliminates all aliasing artifacts, broken strokes, and jagged boundaries.
    """
    if not paths or abs(angle_deg) < 0.001:
        return paths

    # If center not provided, compute bounding box centroid
    if center_x is None or center_y is None:
        all_x = [p[0] for poly in paths for p in poly]
        all_y = [p[1] for poly in paths for p in poly]
        if not all_x or not all_y:
            return paths
        center_x = (min(all_x) + max(all_x)) / 2.0
        center_y = (min(all_y) + max(all_y)) / 2.0

    rad = math.radians(angle_deg)
    cos_a = math.cos(rad)
    sin_a = math.sin(rad)

    rotated_paths = []
    for poly in paths:
        rot_poly = []
        for x, y in poly:
            dx = x - center_x
            dy = y - center_y
            rx = center_x + (dx * cos_a - dy * sin_a)
            ry = center_y + (dx * sin_a + dy * cos_a)
            rot_poly.append((rx, ry))
        rotated_paths.append(rot_poly)

    return rotated_paths


def rotate_image(gray: np.ndarray, angle_deg: float) -> np.ndarray:
    """
    Rotate a grayscale image by angle_deg (degrees) around its center.
    Automatically expands image canvas bounds so no corners/signatures get cropped,
    and fills empty background with white (255) paper color.
    """
    if abs(angle_deg) < 0.01:
        return gray

    h, w = gray.shape
    center = (w / 2.0, h / 2.0)

    # Compute rotation matrix
    M = cv2.getRotationMatrix2D(center, angle_deg, 1.0)

    # Calculate new bounding dimensions to avoid clipping
    cos_a = abs(M[0, 0])
    sin_a = abs(M[0, 1])
    new_w = int(round((h * sin_a) + (w * cos_a)))
    new_h = int(round((h * cos_a) + (w * sin_a)))

    # Adjust transformation matrix to center of new bounding box
    M[0, 2] += (new_w / 2.0) - center[0]
    M[1, 2] += (new_h / 2.0) - center[1]

    # Warp affine with white (255) paper background
    rotated = cv2.warpAffine(
        gray, M, (new_w, new_h),
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=255,
    )
    return rotated


def threshold_image(
    gray: np.ndarray,
    threshold: int = 128,
    invert: bool = False,
    blur_radius: int = 0,
    adaptive: bool = False,
    adaptive_block_size: int = 15,
    adaptive_c: int = 5,
) -> np.ndarray:
    """
    Convert grayscale image to binary.
    - threshold: pixel value cutoff (0-255). Below = black.
    - invert: if True, white areas become "draw" areas instead of black.
    - blur_radius: Gaussian blur radius to reduce noise (0 = no blur).
    - adaptive: use adaptive thresholding (better for uneven lighting/scans).
    Returns binary image (0 or 255).
    """
    if blur_radius > 0:
        ksize = blur_radius * 2 + 1  # must be odd
        gray = cv2.GaussianBlur(gray, (ksize, ksize), 0)

    if adaptive:
        # Adaptive thresholding — excellent for scanned line art
        block = adaptive_block_size
        if block % 2 == 0:
            block += 1
        if invert:
            binary = cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY, block, adaptive_c
            )
        else:
            binary = cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY_INV, block, adaptive_c
            )
    else:
        if invert:
            _, binary = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)
        else:
            _, binary = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY_INV)
    return binary


def preprocess_signature_image(
    gray: np.ndarray,
    threshold: int = 128,
    invert: bool = False,
    super_sample: int = 2,
) -> Tuple[np.ndarray, int, int]:
    """
    High-accuracy preprocessing pipeline for scanned/photographed signatures:
      1. Background illumination leveling (removes paper shadows, yellowing, gradients).
      2. CLAHE local contrast enhancement (amplifies faint ink upstrokes and delicate flourishes).
      3. Bilateral edge-preserving denoising (removes paper texture & grain without blurring ink edges).
      4. Combined Otsu + Adaptive thresholding (extracts exact ink geometry).
      5. Anti-aliased Super-Sampling (2x or 3x upscaling) to eliminate discrete pixel staircase artifacts.
    Returns (high_res_binary, scaled_w, scaled_h).
    """
    h, w = gray.shape

    # 1. Background illumination leveling (morphological division)
    kernel_size = max(25, min(h, w) // 10)
    if kernel_size % 2 == 0:
        kernel_size += 1
    bg_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
    bg_illum = cv2.morphologyEx(gray, cv2.MORPH_DILATE, bg_kernel)
    norm_gray = cv2.divide(gray, bg_illum, scale=255)

    # 2. CLAHE (Contrast Limited Adaptive Histogram Equalization)
    clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
    enhanced = clahe.apply(norm_gray)

    # 3. Bilateral Filter (smoothes paper texture without blurring ink edges)
    denoised = cv2.bilateralFilter(enhanced, d=5, sigmaColor=50, sigmaSpace=50)

    # 4. Otsu + Adaptive thresholding
    if invert:
        _, otsu_bin = cv2.threshold(denoised, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    else:
        _, otsu_bin = cv2.threshold(denoised, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    # Clean small speckles
    open_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
    clean_bin = cv2.morphologyEx(otsu_bin, cv2.MORPH_OPEN, open_kernel)

    # 5. Anti-aliased Super-Sampling (2x or 3x upscaling)
    if super_sample > 1:
        scaled_w = w * super_sample
        scaled_h = h * super_sample
        upscaled = cv2.resize(clean_bin, (scaled_w, scaled_h), interpolation=cv2.INTER_CUBIC)
        high_res_bin = (upscaled > 127).astype(np.uint8) * 255
    else:
        high_res_bin = clean_bin
        scaled_w = w
        scaled_h = h

    return high_res_bin, scaled_w, scaled_h


def prune_skeleton_spurs(skeleton: np.ndarray, max_spur_len: int = 6) -> np.ndarray:
    """
    Topological spur pruning: Removes short stub branches (<= max_spur_len px) caused by
    pixel boundary noise / ink bleed. Eliminates thorn artifacts and micro-jitters from curves.
    """
    skel = (skeleton > 0).astype(np.uint8)
    h, w = skel.shape
    if not np.any(skel):
        return skeleton

    # Compute 8-neighbor counts
    padded = np.pad(skel, 1, mode="constant", constant_values=0)
    p2 = padded[:-2, 1:-1]; p3 = padded[:-2, 2:]; p4 = padded[1:-1, 2:]; p5 = padded[2:, 2:]
    p6 = padded[2:, 1:-1]; p7 = padded[2:, :-2]; p8 = padded[1:-1, :-2]; p9 = padded[:-2, :-2]
    nbr_count = p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9

    endpoint_mask = (skel == 1) & (nbr_count == 1)
    ey, ex = np.where(endpoint_mask)
    if len(ey) == 0:
        return (skel * 255).astype(np.uint8)

    endpoints = list(zip(ex, ey))
    to_remove = set()

    for sx, sy in endpoints:
        branch = [(sx, sy)]
        curr_x, curr_y = sx, sy
        prev_x, prev_y = -1, -1

        for _ in range(max_spur_len):
            nbrs = []
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    if dy == 0 and dx == 0:
                        continue
                    nx, ny = curr_x + dx, curr_y + dy
                    if 0 <= ny < h and 0 <= nx < w and skel[ny, nx] and (nx, ny) != (prev_x, prev_y):
                        nbrs.append((nx, ny))

            if not nbrs:
                break
            if len(nbrs) > 1:
                # Hit a junction! This entire branch is a dead-end spur off the junction
                to_remove.update(branch)
                break

            next_x, next_y = nbrs[0]
            branch.append((next_x, next_y))
            prev_x, prev_y = curr_x, curr_y
            curr_x, curr_y = next_x, next_y

    for rx, ry in to_remove:
        skel[ry, rx] = 0

    return (skel * 255).astype(np.uint8)


# -----------------------------
# -----------------------------
# Skeletonization (Zhang-Suen Thinning)
# -----------------------------
def skeletonize(binary: np.ndarray) -> np.ndarray:
    """
    Reduce binary image to a 1-pixel-wide topological centerline skeleton using
    vectorized Zhang-Suen thinning.
    This extracts the exact center of strokes — essential for signatures and single-line handwriting.
    Input: binary image (0 and 255). White (255) = foreground ink.
    Output: 1-pixel skeleton binary image (0 and 255).
    """
    img = (binary > 0).astype(np.uint8)
    h, w = img.shape
    if h < 3 or w < 3:
        return binary

    # Pad by 1 pixel to handle boundary conditions safely
    padded = np.pad(img, 1, mode="constant", constant_values=0)

    while True:
        # 8-neighbors in clockwise order: P2 to P9
        # P9 P2 P3
        # P8 P1 P4
        # P7 P6 P5
        p2 = padded[:-2, 1:-1]
        p3 = padded[:-2, 2:]
        p4 = padded[1:-1, 2:]
        p5 = padded[2:, 2:]
        p6 = padded[2:, 1:-1]
        p7 = padded[2:, :-2]
        p8 = padded[1:-1, :-2]
        p9 = padded[:-2, :-2]

        # Condition 1: 2 <= B(P1) <= 6 (number of non-zero neighbors)
        bp = p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9
        c1 = (bp >= 2) & (bp <= 6)

        # Condition 2: A(P1) == 1 (number of 0 -> 1 transitions in clockwise order)
        ap = ((p2 == 0) & (p3 == 1)).astype(np.uint8) + \
             ((p3 == 0) & (p4 == 1)).astype(np.uint8) + \
             ((p4 == 0) & (p5 == 1)).astype(np.uint8) + \
             ((p5 == 0) & (p6 == 1)).astype(np.uint8) + \
             ((p6 == 0) & (p7 == 1)).astype(np.uint8) + \
             ((p7 == 0) & (p8 == 1)).astype(np.uint8) + \
             ((p8 == 0) & (p9 == 1)).astype(np.uint8) + \
             ((p9 == 0) & (p2 == 1)).astype(np.uint8)
        c2 = (ap == 1)

        # Iteration 1: P2*P4*P6 == 0 and P4*P6*P8 == 0
        c3_1 = (p2 * p4 * p6 == 0)
        c4_1 = (p4 * p6 * p8 == 0)

        del1 = (padded[1:-1, 1:-1] == 1) & c1 & c2 & c3_1 & c4_1
        padded[1:-1, 1:-1][del1] = 0

        # Re-sample neighbors for Iteration 2
        p2 = padded[:-2, 1:-1]
        p3 = padded[:-2, 2:]
        p4 = padded[1:-1, 2:]
        p5 = padded[2:, 2:]
        p6 = padded[2:, 1:-1]
        p7 = padded[2:, :-2]
        p8 = padded[1:-1, :-2]
        p9 = padded[:-2, :-2]

        bp = p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9
        c1 = (bp >= 2) & (bp <= 6)
        ap = ((p2 == 0) & (p3 == 1)).astype(np.uint8) + \
             ((p3 == 0) & (p4 == 1)).astype(np.uint8) + \
             ((p4 == 0) & (p5 == 1)).astype(np.uint8) + \
             ((p5 == 0) & (p6 == 1)).astype(np.uint8) + \
             ((p6 == 0) & (p7 == 1)).astype(np.uint8) + \
             ((p7 == 0) & (p8 == 1)).astype(np.uint8) + \
             ((p8 == 0) & (p9 == 1)).astype(np.uint8) + \
             ((p9 == 0) & (p2 == 1)).astype(np.uint8)
        c2 = (ap == 1)

        # Iteration 2: P2*P4*P8 == 0 and P2*P6*P8 == 0
        c3_2 = (p2 * p4 * p8 == 0)
        c4_2 = (p2 * p6 * p8 == 0)

        del2 = (padded[1:-1, 1:-1] == 1) & c1 & c2 & c3_2 & c4_2
        padded[1:-1, 1:-1][del2] = 0

        if not np.any(del1) and not np.any(del2):
            break

    return (padded[1:-1, 1:-1] * 255).astype(np.uint8)


def _trace_skeleton_paths(skeleton: np.ndarray, bridge_gap_px: int = 3) -> List[List[Tuple[int, int]]]:
    """
    Extract 1-stroke continuous Eulerian paths from a 1-pixel skeleton image.
    Every connected component of the skeleton is traversed as a single continuous polyline
    using the Chinese Postman / Eulerian trail algorithm (single-stroke puzzle / 1-line drawing logic).
    Eliminates fragmented sub-paths and pen touchdown dots.
    """
    h, w = skeleton.shape
    skel = (skeleton > 0).astype(np.uint8)
    if not np.any(skel):
        return []

    # 0. Bridge tiny gaps between nearby stroke endpoints to prevent unnecessary fragmentation
    if bridge_gap_px > 0:
        padded = np.pad(skel, 1, mode="constant", constant_values=0)
        p2 = padded[:-2, 1:-1]; p3 = padded[:-2, 2:]; p4 = padded[1:-1, 2:]; p5 = padded[2:, 2:]
        p6 = padded[2:, 1:-1]; p7 = padded[2:, :-2]; p8 = padded[1:-1, :-2]; p9 = padded[:-2, :-2]
        nbr_count = p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9
        endpoint_mask = (skel == 1) & (nbr_count == 1)
        ey, ex = np.where(endpoint_mask)
        endpoints = list(zip(ex, ey))

        for i in range(len(endpoints)):
            x1, y1 = endpoints[i]
            best_j = -1
            best_dist = bridge_gap_px + 0.1
            for j in range(i + 1, len(endpoints)):
                x2, y2 = endpoints[j]
                d = math.hypot(x2 - x1, y2 - y1)
                if 1 < d <= bridge_gap_px and d < best_dist:
                    best_dist = d
                    best_j = j
            if best_j != -1:
                x2, y2 = endpoints[best_j]
                cv2.line(skel, (x1, y1), (x2, y2), 1, 1)

    ys, xs = np.where(skel > 0)
    if len(ys) == 0:
        return []

    # 1. Build pixel graph adjacency
    pixel_neighbors: Dict[Tuple[int, int], Set[Tuple[int, int]]] = collections.defaultdict(set)
    for y, x in zip(ys, xs):
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and skel[ny, nx]:
                    pixel_neighbors[(x, y)].add((nx, ny))

    # 2. Find connected components of pixels (sorted left-to-right, top-to-bottom for natural writing order)
    visited_pixels = set()
    components = []
    sorted_all_pixels = sorted(pixel_neighbors.keys(), key=lambda p: (p[0], p[1]))

    for p in sorted_all_pixels:
        if p not in visited_pixels:
            comp = []
            queue = collections.deque([p])
            visited_pixels.add(p)
            while queue:
                curr = queue.popleft()
                comp.append(curr)
                for nbr in pixel_neighbors[curr]:
                    if nbr not in visited_pixels:
                        visited_pixels.add(nbr)
                        queue.append(nbr)
            components.append(comp)

    all_continuous_paths = []

    for comp in components:
        comp_set = set(comp)
        if len(comp) <= 2:
            all_continuous_paths.append(comp)
            continue

        # Classify nodes: Endpoints (deg 1), Junctions (deg >= 3), Curve points (deg 2)
        junctions = set()
        endpoints = []
        for p in comp:
            deg = len(pixel_neighbors[p] & comp_set)
            if deg == 1:
                endpoints.append(p)
            elif deg >= 3:
                junctions.add(p)

        # Merge adjacent junction pixels into single cluster representatives
        cluster_rep: Dict[Tuple[int, int], Tuple[int, int]] = {}
        junction_clusters = {}
        cluster_id = 0
        visited_j = set()
        for j in junctions:
            if j not in visited_j:
                c_members = [j]
                q = [j]
                visited_j.add(j)
                while q:
                    curr = q.pop()
                    for nbr in pixel_neighbors[curr]:
                        if nbr in junctions and nbr not in visited_j:
                            visited_j.add(nbr)
                            q.append(nbr)
                            c_members.append(nbr)
                rep = (
                    int(round(sum(p[0] for p in c_members) / len(c_members))),
                    int(round(sum(p[1] for p in c_members) / len(c_members))),
                )
                for m in c_members:
                    cluster_rep[m] = rep
                junction_clusters[cluster_id] = (rep, c_members)
                cluster_id += 1

        key_vertices = set(endpoints) | {rep for rep, _ in junction_clusters.values()}

        # If it's a closed loop without endpoints or junctions, pick the leftmost-topmost pixel
        if not key_vertices:
            sorted_comp = sorted(comp, key=lambda p: (p[0], p[1]))
            key_vertices.add(sorted_comp[0])

        # Extract topological edges between key vertices
        edges = []
        edge_id = 0
        visited_edge_pixel_pairs = set()

        for u_pix in comp:
            u_key = cluster_rep.get(u_pix, u_pix) if u_pix in junctions else (u_pix if u_pix in key_vertices else None)
            if u_key is None:
                continue

            for next_pix in pixel_neighbors[u_pix]:
                if u_pix in junctions and next_pix in junctions and cluster_rep.get(u_pix) == cluster_rep.get(next_pix):
                    continue

                pair_key = tuple(sorted([u_pix, next_pix]))
                if pair_key in visited_edge_pixel_pairs:
                    continue

                path_pts = [u_key, next_pix]
                visited_edge_pixel_pairs.add(pair_key)
                prev_p = u_pix
                curr_p = next_pix

                while True:
                    if curr_p in junctions:
                        v_key = cluster_rep[curr_p]
                        if v_key != path_pts[-1]:
                            path_pts.append(v_key)
                        break
                    elif curr_p in key_vertices:
                        v_key = curr_p
                        break

                    nbrs = [n for n in pixel_neighbors[curr_p] if n != prev_p and n in comp_set]
                    if not nbrs:
                        v_key = curr_p
                        break

                    next_p = nbrs[0]
                    visited_edge_pixel_pairs.add(tuple(sorted([curr_p, next_p])))
                    path_pts.append(next_p)
                    prev_p = curr_p
                    curr_p = next_p

                length = sum(math.hypot(path_pts[k+1][0] - path_pts[k][0], path_pts[k+1][1] - path_pts[k][1]) for k in range(len(path_pts)-1))
                if length > 0 or u_key != v_key:
                    edges.append({
                        "id": edge_id,
                        "u": u_key,
                        "v": v_key,
                        "pts": path_pts,
                        "len": max(0.1, length)
                    })
                    edge_id += 1

        if not edges:
            continue

        # 3. Build multigraph for Eulerian traversal
        adj: Dict[Tuple[int, int], List[dict]] = collections.defaultdict(list)
        for e in edges:
            adj[e["u"]].append(e)
            adj[e["v"]].append(e)

        # 4. Chinese Postman: Match odd degree vertices to make the component Eulerian (<= 2 odd vertices)
        odd_vertices = [v for v in adj if len(adj[v]) % 2 != 0]

        if len(odd_vertices) > 2:
            def shortest_path(start, target):
                dist = {start: 0.0}
                prev = {}
                q = [(0.0, start)]
                while q:
                    d, u = heapq.heappop(q)
                    if u == target:
                        break
                    if d > dist.get(u, float('inf')):
                        continue
                    for edge in adj[u]:
                        nbr = edge["v"] if edge["u"] == u else edge["u"]
                        new_d = d + edge["len"]
                        if new_d < dist.get(nbr, float('inf')):
                            dist[nbr] = new_d
                            prev[nbr] = (u, edge)
                            heapq.heappush(q, (new_d, nbr))
                if target not in prev:
                    return float('inf'), []
                path_edges = []
                curr = target
                while curr != start:
                    p_node, p_edge = prev[curr]
                    path_edges.append(p_edge)
                    curr = p_node
                return dist[target], path_edges

            pairs = []
            for i in range(len(odd_vertices)):
                for j in range(i + 1, len(odd_vertices)):
                    v1, v2 = odd_vertices[i], odd_vertices[j]
                    d, p_edges = shortest_path(v1, v2)
                    pairs.append((d, v1, v2, p_edges))

            pairs.sort(key=lambda x: x[0])

            matched_nodes = set()
            for d, v1, v2, p_edges in pairs:
                if len(odd_vertices) - len(matched_nodes) <= 2:
                    break
                if v1 not in matched_nodes and v2 not in matched_nodes:
                    matched_nodes.add(v1)
                    matched_nodes.add(v2)
                    for pe in p_edges:
                        dup_e = {
                            "id": edge_id,
                            "u": pe["u"],
                            "v": pe["v"],
                            "pts": list(pe["pts"]),
                            "len": pe["len"]
                        }
                        edge_id += 1
                        edges.append(dup_e)
                        adj[dup_e["u"]].append(dup_e)
                        adj[dup_e["v"]].append(dup_e)

        # 5. Hierholzer's Algorithm
        final_odds = [v for v in adj if len(adj[v]) % 2 != 0]
        if final_odds:
            # Start at the leftmost odd vertex (natural handwriting stroke flow from left to right)
            start_v = min(final_odds, key=lambda p: (p[0], p[1]))
        else:
            start_v = min(adj.keys(), key=lambda p: (p[0], p[1]))

        current_adj = {v: list(e_list) for v, e_list in adj.items()}
        stack = [start_v]
        circuit = []

        while stack:
            u = stack[-1]
            if current_adj[u]:
                edge = current_adj[u].pop()
                v = edge["v"] if edge["u"] == u else edge["u"]
                if edge in current_adj[v]:
                    current_adj[v].remove(edge)
                stack.append(v)
            else:
                circuit.append(stack.pop())

        circuit.reverse()

        # Unpack circuit edges into continuous polyline
        continuous_poly = []
        available_edges = list(edges)

        for i in range(len(circuit) - 1):
            u = circuit[i]
            v = circuit[i + 1]
            found_edge = None
            for e in available_edges:
                if (e["u"] == u and e["v"] == v) or (e["u"] == v and e["v"] == u):
                    found_edge = e
                    available_edges.remove(e)
                    break

            if found_edge:
                pts = found_edge["pts"]
                seg_pts = pts if found_edge["u"] == u else list(reversed(pts))
                if not continuous_poly:
                    continuous_poly.extend(seg_pts)
                else:
                    continuous_poly.extend(seg_pts[1:])

        if len(continuous_poly) >= 2:
            # Clean duplicate adjacent points
            clean_poly = [continuous_poly[0]]
            for pt in continuous_poly[1:]:
                if pt[0] != clean_poly[-1][0] or pt[1] != clean_poly[-1][1]:
                    clean_poly.append(pt)
            if len(clean_poly) >= 2:
                all_continuous_paths.append(clean_poly)

    return all_continuous_paths


# -----------------------------
# Contour extraction
# -----------------------------
def extract_contours(
    binary: np.ndarray,
    simplify_epsilon: float = 0.5,
    min_area: float = 2.0,
    min_length: float = 3.0,
) -> List[np.ndarray]:
    """
    Extract contours from a binary image.
    - simplify_epsilon: approximation accuracy (higher = simpler curves).
      Use 0 for maximum detail.
    - min_area: ignore contours smaller than this area (in pixels).
    - min_length: ignore contours shorter than this perimeter (in pixels).
    Returns list of contour arrays, each shape (N, 1, 2).
    """
    # Use RETR_TREE to capture nested contours (important for details)
    contours, hierarchy = cv2.findContours(
        binary, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE
    )

    result = []
    for i, cnt in enumerate(contours):
        area = cv2.contourArea(cnt)
        perimeter = cv2.arcLength(cnt, closed=True)

        # Filter by both area and perimeter to keep thin lines
        if area < min_area and perimeter < min_length:
            continue

        # Simplify the contour
        if simplify_epsilon > 0:
            approx = cv2.approxPolyDP(cnt, simplify_epsilon, closed=True)
        else:
            approx = cnt

        # Only keep if we have enough points
        if len(approx) >= 2:
            result.append(approx)

    return result


# -----------------------------
# Hatching / infill
# -----------------------------
def generate_hatching(
    binary: np.ndarray,
    spacing: float = 3.0,
    angle: float = 45.0,
) -> List[List[Tuple[float, float]]]:
    """
    Generate parallel-line hatching pattern for filled (white=255) regions.
    """
    h, w = binary.shape
    hatch_lines = []

    angle_rad = math.radians(angle)
    cos_a = math.cos(angle_rad)
    sin_a = math.sin(angle_rad)

    diag = math.sqrt(h * h + w * w)
    num_lines = int(2 * diag / spacing) + 1
    offset_start = -diag

    for i in range(num_lines):
        offset = offset_start + i * spacing

        cx, cy = w / 2.0, h / 2.0
        dx, dy = cos_a, sin_a
        px, py = -sin_a, cos_a

        lx = cx + px * offset
        ly = cy + py * offset

        x1 = lx - dx * diag
        y1 = ly - dy * diag
        x2 = lx + dx * diag
        y2 = ly + dy * diag

        segments = _clip_hatch_line(binary, x1, y1, x2, y2, spacing * 0.5)
        hatch_lines.extend(segments)

    return hatch_lines


def _clip_hatch_line(
    binary: np.ndarray,
    x1: float, y1: float,
    x2: float, y2: float,
    step: float = 1.0,
) -> List[List[Tuple[float, float]]]:
    """
    Walk along a line and collect segments inside the filled region.
    """
    h, w = binary.shape
    length = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
    if length < 1:
        return []

    dx = (x2 - x1) / length
    dy = (y2 - y1) / length
    num_steps = int(length / step)

    segments = []
    current_segment = []
    was_inside = False

    for i in range(num_steps + 1):
        ppx = x1 + dx * step * i
        ppy = y1 + dy * step * i

        ix, iy = int(round(ppx)), int(round(ppy))

        if 0 <= ix < w and 0 <= iy < h:
            is_inside = binary[iy, ix] > 0
        else:
            is_inside = False

        if is_inside:
            current_segment.append((ppx, ppy))
            was_inside = True
        else:
            if was_inside and len(current_segment) >= 2:
                segments.append(current_segment)
            current_segment = []
            was_inside = False

    if was_inside and len(current_segment) >= 2:
        segments.append(current_segment)

    return segments


# -----------------------------
# Coordinate conversion
# -----------------------------
def contours_to_paths(
    contours: List[np.ndarray],
    img_width: int,
    img_height: int,
    target_width_mm: float,
    target_height_mm: float,
    offset_x: float = 0.0,
    offset_y: float = 0.0,
    flip_y: bool = True,
) -> List[Polyline]:
    """
    Convert pixel contours to mm-scale polylines for the plotter.
    """
    if img_width <= 0 or img_height <= 0:
        return []

    scale_x = target_width_mm / img_width
    scale_y = target_height_mm / img_height

    paths = []
    for cnt in contours:
        poly = []
        points = cnt.reshape(-1, 2)
        for px, py in points:
            mx = px * scale_x + offset_x
            if flip_y:
                my = (img_height - py) * scale_y + offset_y
            else:
                my = py * scale_y + offset_y
            poly.append((mx, my))

        # Close the contour
        if len(poly) >= 2 and poly[0] != poly[-1]:
            poly.append(poly[0])

        if len(poly) >= 2:
            paths.append(poly)

    return paths


def catmull_rom_spline_polyline(
    poly: Polyline,
    subdivisions: int = 3,
    alpha: float = 0.5,
) -> Polyline:
    """
    Centripetal Catmull-Rom spline interpolation for 100% authentic signature fidelity.
    Crucial advantage: Passes EXACTLY through every original handwritten keypoint without
    cutting corners, flattening crests, or distorting signature loops and flourishes.
    """
    if len(poly) < 3 or subdivisions <= 1:
        return poly

    def get_t(t_prev, p_prev, p_curr):
        dx = p_curr[0] - p_prev[0]
        dy = p_curr[1] - p_prev[1]
        dist = math.hypot(dx, dy)
        return t_prev + (dist ** alpha if dist > 1e-6 else 1e-6)

    # Pad endpoints
    p_list = [poly[0]] + list(poly) + [poly[-1]]
    result = []

    for i in range(1, len(p_list) - 2):
        p0, p1, p2, p3 = p_list[i - 1], p_list[i], p_list[i + 1], p_list[i + 2]

        t0 = 0.0
        t1 = get_t(t0, p0, p1)
        t2 = get_t(t1, p1, p2)
        t3 = get_t(t2, p2, p3)

        if abs(t1 - t0) < 1e-7 or abs(t2 - t1) < 1e-7 or abs(t3 - t2) < 1e-7:
            result.append(p1)
            continue

        for s in range(subdivisions):
            t = t1 + (t2 - t1) * (s / subdivisions)
            # Catmull-Rom interpolation
            a1_x = ((t1 - t) * p0[0] + (t - t0) * p1[0]) / (t1 - t0)
            a1_y = ((t1 - t) * p0[1] + (t - t0) * p1[1]) / (t1 - t0)

            a2_x = ((t2 - t) * p1[0] + (t - t1) * p2[0]) / (t2 - t1)
            a2_y = ((t2 - t) * p1[1] + (t - t1) * p2[1]) / (t2 - t1)

            a3_x = ((t3 - t) * p2[0] + (t - t2) * p3[0]) / (t3 - t2)
            a3_y = ((t3 - t) * p2[1] + (t - t2) * p3[1]) / (t3 - t2)

            b1_x = ((t2 - t) * a1_x + (t - t0) * a2_x) / (t2 - t0)
            b1_y = ((t2 - t) * a1_y + (t - t0) * a2_y) / (t2 - t0)

            b2_x = ((t3 - t) * a2_x + (t - t1) * a3_x) / (t3 - t1)
            b2_y = ((t3 - t) * a2_y + (t - t1) * a3_y) / (t3 - t1)

            cx = ((t2 - t) * b1_x + (t - t1) * b2_x) / (t2 - t1)
            cy = ((t2 - t) * b1_y + (t - t1) * b2_y) / (t2 - t1)
            result.append((cx, cy))

    result.append(poly[-1])
    return result


def skeleton_to_paths(
    skeleton_paths: List[List[Tuple[int, int]]],
    img_width: int,
    img_height: int,
    target_width_mm: float,
    target_height_mm: float,
    offset_x: float = 0.0,
    offset_y: float = 0.0,
    flip_y: bool = True,
    simplify_epsilon: float = 0.1,
    smooth_iterations: int = 2,
) -> List[Polyline]:
    """
    Convert pixel-space skeleton paths to mm-scale polylines with 100% authentic curve fidelity.
    Uses sub-pixel coordinate mapping and Centripetal Catmull-Rom splines that preserve all
    original handwritten curve peaks, loops, and distinctive personal style.
    """
    if img_width <= 0 or img_height <= 0:
        return []

    scale_x = target_width_mm / img_width
    scale_y = target_height_mm / img_height

    paths = []
    for seg in skeleton_paths:
        if len(seg) < 2:
            continue

        # Convert to numpy for ultra-fine simplification (preserves all curve points)
        pts = np.array(seg, dtype=np.float32).reshape(-1, 1, 2)

        if simplify_epsilon > 0.01 and len(pts) > 4:
            pts = cv2.approxPolyDP(pts, simplify_epsilon, closed=False)

        poly = []
        for pt in pts.reshape(-1, 2):
            px, py = float(pt[0]), float(pt[1])
            mx = px * scale_x + offset_x
            if flip_y:
                my = (img_height - py) * scale_y + offset_y
            else:
                my = py * scale_y + offset_y
            poly.append((mx, my))

        if len(poly) >= 3:
            if smooth_iterations > 0:
                # Subdivide smoothly through exact points
                poly = catmull_rom_spline_polyline(poly, subdivisions=max(2, smooth_iterations + 1))

        if len(poly) >= 2:
            paths.append(poly)

    return paths


def hatching_to_paths(
    hatch_lines: List[List[Tuple[float, float]]],
    img_width: int,
    img_height: int,
    target_width_mm: float,
    target_height_mm: float,
    offset_x: float = 0.0,
    offset_y: float = 0.0,
    flip_y: bool = True,
) -> List[Polyline]:
    """Convert pixel-space hatch lines to mm-scale polylines."""
    if img_width <= 0 or img_height <= 0:
        return []

    scale_x = target_width_mm / img_width
    scale_y = target_height_mm / img_height

    paths = []
    for seg in hatch_lines:
        poly = []
        for px, py in seg:
            mx = px * scale_x + offset_x
            if flip_y:
                my = (img_height - py) * scale_y + offset_y
            else:
                my = py * scale_y + offset_y
            poly.append((mx, my))
        if len(poly) >= 2:
            paths.append(poly)

    return paths


# -----------------------------
# High-level API
# -----------------------------
def image_to_paths(
    image_path: str,
    target_width_mm: float = 200.0,
    target_height_mm: Optional[float] = None,
    threshold: int = 128,
    invert: bool = False,
    blur_radius: int = 0,
    adaptive_threshold: bool = False,
    simplify: float = 0.35,
    min_area: float = 2.0,
    fill_mode: str = "contour",
    hatch_spacing: float = 3.0,
    hatch_angle: float = 45.0,
    offset_x: float = 0.0,
    offset_y: float = 0.0,
    rotation_deg: float = 0.0,
    smooth_iterations: int = 2,
) -> Tuple[List[Polyline], int, int]:
    """
    Complete high-accuracy pipeline: image file → polylines ready for G-code.

    fill_mode:
      - "contour": trace outlines of black regions
      - "signature": high-accuracy single-stroke centerline skeleton with background normalization,
                     2x super-sampling, spur pruning, and curvature-aware smoothing
      - "centerline": skeletonize and trace center of strokes (best for line art!)
      - "hatch": parallel line fill of black regions
      - "both": contours + hatching

    rotation_deg: rotate image in degrees (-180 to +180) around center with auto-expanded bounds.
    smooth_iterations: Chaikin curve smoothing passes for flowing handwriting.

    Returns (paths, original_width, original_height).
    """
    gray = load_image(image_path)
    img_h, img_w = gray.shape

    # Maintain aspect ratio if height not specified
    if target_height_mm is None:
        aspect = img_h / img_w if img_w > 0 else 1.0
        target_height_mm = target_width_mm * aspect

    all_paths = []

    if fill_mode == "signature":
        # High-Accuracy Signature Mode: Illumination normalization, 2x super-sampling, spur pruning
        high_res_bin, proc_w, proc_h = preprocess_signature_image(
            gray, threshold=threshold, invert=invert, super_sample=2
        )
        skel = skeletonize(high_res_bin)
        skel = prune_skeleton_spurs(skel, max_spur_len=8)
        skel_paths = _trace_skeleton_paths(skel, bridge_gap_px=6)
        mm_paths = skeleton_to_paths(
            skel_paths, proc_w, proc_h,
            target_width_mm, target_height_mm,
            offset_x, offset_y,
            simplify_epsilon=simplify * 0.7,
            smooth_iterations=smooth_iterations,
        )
        all_paths.extend(mm_paths)

    elif fill_mode == "centerline":
        binary = threshold_image(
            gray, threshold, invert, blur_radius,
            adaptive=adaptive_threshold,
        )
        skel = skeletonize(binary)
        skel = prune_skeleton_spurs(skel, max_spur_len=4)
        skel_paths = _trace_skeleton_paths(skel, bridge_gap_px=3)
        mm_paths = skeleton_to_paths(
            skel_paths, img_w, img_h,
            target_width_mm, target_height_mm,
            offset_x, offset_y,
            simplify_epsilon=simplify,
            smooth_iterations=smooth_iterations,
        )
        all_paths.extend(mm_paths)

    elif fill_mode in ("contour", "both"):
        binary = threshold_image(
            gray, threshold, invert, blur_radius,
            adaptive=adaptive_threshold,
        )
        contours = extract_contours(binary, simplify, min_area)
        contour_paths = contours_to_paths(
            contours, img_w, img_h,
            target_width_mm, target_height_mm,
            offset_x, offset_y,
        )
        all_paths.extend(contour_paths)

    if fill_mode in ("hatch", "both"):
        binary = threshold_image(
            gray, threshold, invert, blur_radius,
            adaptive=adaptive_threshold,
        )
        hatch_lines = generate_hatching(binary, hatch_spacing, hatch_angle)
        hatch_paths = hatching_to_paths(
            hatch_lines, img_w, img_h,
            target_width_mm, target_height_mm,
            offset_x, offset_y,
        )
        all_paths.extend(hatch_paths)

    # Pure mathematical vector rotation (zero resampling noise)
    if abs(rotation_deg) >= 0.001:
        all_paths = rotate_polylines(all_paths, rotation_deg)

    return all_paths, img_w, img_h


def numpy_to_paths(
    binary: np.ndarray,
    target_width_mm: float = 200.0,
    target_height_mm: Optional[float] = None,
    simplify: float = 0.35,
    min_area: float = 2.0,
    fill_mode: str = "contour",
    hatch_spacing: float = 3.0,
    hatch_angle: float = 45.0,
    offset_x: float = 0.0,
    offset_y: float = 0.0,
    smooth_iterations: int = 0,
) -> List[Polyline]:
    """
    Same as image_to_paths but accepts a pre-processed binary numpy array.
    Used by font_manager to convert rendered text to paths.
    """
    img_h, img_w = binary.shape

    if target_height_mm is None:
        aspect = img_h / img_w if img_w > 0 else 1.0
        target_height_mm = target_width_mm * aspect

    all_paths = []

    if fill_mode in ("centerline", "signature"):
        skel = skeletonize(binary)
        skel = prune_skeleton_spurs(skel, max_spur_len=4)
        skel_paths = _trace_skeleton_paths(skel, bridge_gap_px=3)
        mm_paths = skeleton_to_paths(
            skel_paths, img_w, img_h,
            target_width_mm, target_height_mm,
            offset_x, offset_y,
            simplify_epsilon=simplify,
            smooth_iterations=smooth_iterations,
        )
        all_paths.extend(mm_paths)

    elif fill_mode in ("contour", "both"):
        contours = extract_contours(binary, simplify, min_area)
        contour_paths = contours_to_paths(
            contours, img_w, img_h,
            target_width_mm, target_height_mm,
            offset_x, offset_y,
        )
        all_paths.extend(contour_paths)

    if fill_mode in ("hatch", "both"):
        hatch_lines = generate_hatching(binary, hatch_spacing, hatch_angle)
        hatch_paths = hatching_to_paths(
            hatch_lines, img_w, img_h,
            target_width_mm, target_height_mm,
            offset_x, offset_y,
        )
        all_paths.extend(hatch_paths)

    return all_paths
