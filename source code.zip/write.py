"""
write.py — Backward-compatible wrapper.

This file preserves the original CLI behavior. For the full application,
use main.py which launches the interactive GUI.
"""

from gcode_engine import (
    PlotterConfig,
    GCodeBuilder,
    VECTOR_FONT as FONT,
    clamp,
    safe_z_value,
    estimate_text_size,
    anchor_center,
    generate_gcode,
    generate_gcode_text,
    save_gcode,
)

if __name__ == "__main__":
    import sys

    # If no arguments, launch GUI; otherwise use classic CLI mode
    if len(sys.argv) > 1 and sys.argv[1] == "--gui":
        from gui import launch_gui
        launch_gui()
    else:
        cfg = PlotterConfig(
            text="hello world",
            output_file="text_output.gcode",
            start_x=20.0,
            start_y=20.0,
            scale=4.0,
            char_gap=1.2,
            word_gap=2.4,
            pen_touch_z=16.3,
            z_hop=2.0,
            center_text=True,
            home_all=True,
            safe_lift_z=30.0,
            safe_wait_ms=5000,
        )

        writer = generate_gcode_text(cfg)
        count = save_gcode(cfg, writer)
        _, est_time, draw_dist, travel_dist = writer.estimate_time()
        print(f"Generated {cfg.output_file} with {count} G-code lines.")
        print(f"Estimated Plot Time: ~{est_time} (Draw: {draw_dist:.1f}mm, Travel: {travel_dist:.1f}mm)")
        print(f"Safety: no Z command will go below {cfg.pen_touch_z:.2f} mm.")
        print(f"\nTip: Run 'python main.py' for the interactive GUI.")
