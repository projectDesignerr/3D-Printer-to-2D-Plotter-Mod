"""
config_manager.py — Configuration management and persistence for G-Code Pen Plotter.

Handles loading, saving, and defaults for all machine, toolhead offset,
feedrate, and Z-axis configurations via JSON.
"""

import json
import os
from pathlib import Path
from typing import Any, Dict

CONFIG_FILE = "plotter_config.json"

DEFAULT_CONFIG: Dict[str, Any] = {
    # Pen Toolhead Offsets (Anycubic Kobra 2 Neo front-mount pen mod)
    "offset_x": 0.0,
    "offset_y": 49.5,
    "offset_z": 0.0,
    
    # Bed & Machine Dimensions (mm)
    "bed_x": 220.0,
    "bed_y": 220.0,
    
    # Pen Heights & Clearance (mm)
    "pen_touch_z": 9.4,
    "z_hop": 3.0,
    "safe_lift_z": 30.0,
    "safe_wait_ms": 5000,
    
    # Speeds & Feedrates (mm/min)
    "travel_feed": 2500,
    "draw_feed": 1200,
    
    # Options & Behaviors
    "home_all": True,
    "optimize_paths": True,
    "output_file": "text_output.gcode",
    
    # Text Defaults
    "default_text": "Hello World",
    "default_scale": 10.0,
    "hershey_font": "futural",
    "font_mode": "vector",
    "center_on_bed": False,
    "text_start_x": 30.0,
    "text_start_y": 70.0,
    "auto_wrap": True,

    # 📄 Notebook Page Mode (Indian A4 Ruled Register)
    "notebook_enabled": False,
    "notebook_align_mode": "left_margin_at_zero",  # "left_margin_at_zero", "centered", "custom"
    "notebook_margin_bed_x": 0.0,      # mm X position of red margin on bed (0.0 = touching left plate border)
    "notebook_line_spacing": 8.0,      # mm between horizontal ruled lines
    "notebook_left_margin": 30.0,      # mm red margin from left edge of writable area
    "notebook_writable_w": 175.0,      # mm writable area width
    "notebook_writable_h": 250.0,      # mm writable area height
    "notebook_page_x": -1.0,           # -1 = auto
    "notebook_page_y": -1.0,           # -1 = auto (top of bed)
    "notebook_start_line": 1,          # which ruled line to start writing on
}


def get_default_config() -> Dict[str, Any]:
    """Return a fresh copy of the default configuration dictionary."""
    return dict(DEFAULT_CONFIG)


def load_config(config_path: str = CONFIG_FILE) -> Dict[str, Any]:
    """
    Load configuration from JSON file. If file does not exist or is invalid,
    returns default configuration merged with any valid keys.
    """
    cfg = get_default_config()
    p = Path(config_path)
    if p.is_file():
        try:
            with open(p, "r", encoding="utf-8") as f:
                saved = json.load(f)
                if isinstance(saved, dict):
                    for k, v in saved.items():
                        if k in cfg:
                            # Cast types appropriately
                            expected_type = type(cfg[k])
                            try:
                                cfg[k] = expected_type(v)
                            except (ValueError, TypeError):
                                cfg[k] = v

                    # Backward-compatible key migration
                    if "pen_z" in saved and "pen_touch_z" not in saved:
                        try:
                            cfg["pen_touch_z"] = float(saved["pen_z"])
                        except (ValueError, TypeError):
                            pass
        except Exception as e:
            print(f"[config_manager] Warning: Could not read {config_path}: {e}")
    return cfg


def save_config(config_data: Dict[str, Any], config_path: str = CONFIG_FILE) -> bool:
    """
    Save configuration dictionary to JSON file.
    Returns True on success, False on error.
    """
    try:
        p = Path(config_path)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(config_data, f, indent=4)
        return True
    except Exception as e:
        print(f"[config_manager] Error: Could not save to {config_path}: {e}")
        return False
