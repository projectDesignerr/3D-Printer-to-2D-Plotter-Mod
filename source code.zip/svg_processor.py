"""
svg_processor.py — High-precision SVG parser & PCB etch-resist toolpath generator.

Specially built for EasyEDA, KiCad, and standard PCB CAD vector SVG exports.
Extracts copper traces, SMD/DIP pads, ground planes, and silkscreen geometry
with sub-micron physical millimeter accuracy and generates solid etch-resist
infill for Ferric Chloride (FeCl3) chemical etching.
"""

import re
import math
import xml.etree.ElementTree as ET
from typing import List, Tuple, Optional, Dict, Any, Union

import numpy as np
from gcode_engine import Polyline


# -----------------------------
# Unit conversion helpers
# -----------------------------
def parse_length(val_str: Optional[str], default_dpi: float = 96.0) -> Optional[float]:
    """
    Parse an SVG length string (e.g. '100mm', '2.54in', '50pt', '120px', '200')
    and convert to millimeters (mm).
    """
    if not val_str:
        return None
    val_str = val_str.strip().lower()
    
    # Strip any extra trailing quotes or garbage
    val_str = val_str.strip('"\'')

    if val_str.endswith("mm"):
        return float(val_str[:-2])
    elif val_str.endswith("cm"):
        return float(val_str[:-2]) * 10.0
    elif val_str.endswith("in"):
        return float(val_str[:-2]) * 25.4
    elif val_str.endswith("mil"):
        return float(val_str[:-3]) * 0.0254
    elif val_str.endswith("pt"):
        return float(val_str[:-2]) * (25.4 / 72.0)
    elif val_str.endswith("pc"):
        return float(val_str[:-2]) * (25.4 / 6.0)
    elif val_str.endswith("px"):
        return float(val_str[:-2]) * (25.4 / default_dpi)
    else:
        try:
            return float(val_str) * (25.4 / default_dpi)
        except ValueError:
            return None


def parse_style(style_str: str) -> Dict[str, str]:
    """Parse CSS style string into a dictionary."""
    props = {}
    if not style_str:
        return props
    for item in style_str.split(';'):
        if ':' in item:
            k, v = item.split(':', 1)
            props[k.strip().lower()] = v.strip().lower()
    return props


# -----------------------------
# 2D Transform Helpers
# -----------------------------
def parse_transform(transform_str: str) -> np.ndarray:
    """
    Parse SVG transform attribute into a 3x3 affine matrix.
    Supports matrix, translate, scale, rotate.
    """
    mat = np.eye(3, dtype=np.float64)
    if not transform_str:
        return mat

    commands = re.findall(r'([a-zA-Z]+)\s*\(([^)]+)\)', transform_str)
    for cmd, args_str in commands:
        args = [float(x) for x in re.split(r'[\s,]+', args_str.strip()) if x]
        t = np.eye(3, dtype=np.float64)

        if cmd == "matrix" and len(args) >= 6:
            a, b, c, d, e, f = args[:6]
            t = np.array([
                [a, c, e],
                [b, d, f],
                [0, 0, 1]
            ], dtype=np.float64)

        elif cmd == "translate":
            tx = args[0]
            ty = args[1] if len(args) > 1 else 0.0
            t[0, 2] = tx
            t[1, 2] = ty

        elif cmd == "scale":
            sx = args[0]
            sy = args[1] if len(args) > 1 else sx
            t[0, 0] = sx
            t[1, 1] = sy

        elif cmd == "rotate":
            angle_deg = args[0]
            rad = math.radians(angle_deg)
            cos_a = math.cos(rad)
            sin_a = math.sin(rad)
            if len(args) >= 3:
                cx, cy = args[1], args[2]
                t1 = np.array([[1, 0, cx], [0, 1, cy], [0, 0, 1]], dtype=np.float64)
                tr = np.array([[cos_a, -sin_a, 0], [sin_a, cos_a, 0], [0, 0, 1]], dtype=np.float64)
                t2 = np.array([[1, 0, -cx], [0, 1, -cy], [0, 0, 1]], dtype=np.float64)
                t = t1 @ tr @ t2
            else:
                t = np.array([
                    [cos_a, -sin_a, 0],
                    [sin_a, cos_a, 0],
                    [0, 0, 1]
                ], dtype=np.float64)

        mat = mat @ t

    return mat


def apply_transform(pts: List[Tuple[float, float]], mat: np.ndarray) -> List[Tuple[float, float]]:
    """Apply 3x3 affine transform matrix to a list of (x, y) points."""
    if np.allclose(mat, np.eye(3)):
        return pts
    out = []
    for x, y in pts:
        v = np.array([x, y, 1.0], dtype=np.float64)
        v_prime = mat @ v
        out.append((float(v_prime[0]), float(v_prime[1])))
    return out


# -----------------------------
# SVG Path Tokenizer & Evaluator
# -----------------------------
def tokenize_path_d(d_str: str) -> List[Any]:
    """Tokenize SVG path 'd' string into commands and numeric arguments."""
    pattern = re.compile(r'([a-df-zA-DF-Z])|([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)')
    tokens = []
    for match in pattern.finditer(d_str):
        cmd, num = match.groups()
        if cmd:
            tokens.append(cmd)
        elif num:
            tokens.append(float(num))
    return tokens


def evaluate_cubic_bezier(p0, p1, p2, p3, subdivisions=12) -> List[Tuple[float, float]]:
    pts = []
    for i in range(1, subdivisions + 1):
        t = i / subdivisions
        mt = 1.0 - t
        x = (mt**3)*p0[0] + 3*(mt**2)*t*p1[0] + 3*mt*(t**2)*p2[0] + (t**3)*p3[0]
        y = (mt**3)*p0[1] + 3*(mt**2)*t*p1[1] + 3*mt*(t**2)*p2[1] + (t**3)*p3[1]
        pts.append((x, y))
    return pts


def evaluate_quadratic_bezier(p0, p1, p2, subdivisions=10) -> List[Tuple[float, float]]:
    pts = []
    for i in range(1, subdivisions + 1):
        t = i / subdivisions
        mt = 1.0 - t
        x = (mt**2)*p0[0] + 2*mt*t*p1[0] + (t**2)*p2[0]
        y = (mt**2)*p0[1] + 2*mt*t*p1[1] + (t**2)*p2[1]
        pts.append((x, y))
    return pts


def evaluate_arc(p0, rx, ry, phi_deg, large_arc, sweep, p1, subdivisions=16) -> List[Tuple[float, float]]:
    x1, y1 = p0
    x2, y2 = p1
    if math.isclose(x1, x2, abs_tol=1e-6) and math.isclose(y1, y2, abs_tol=1e-6):
        return []
    if rx <= 0 or ry <= 0:
        return [p1]

    phi = math.radians(phi_deg % 360.0)
    cos_phi = math.cos(phi)
    sin_phi = math.sin(phi)

    dx = (x1 - x2) / 2.0
    dy = (y1 - y2) / 2.0
    x1_prime = cos_phi * dx + sin_phi * dy
    y1_prime = -sin_phi * dx + cos_phi * dy

    lam = (x1_prime ** 2) / (rx ** 2) + (y1_prime ** 2) / (ry ** 2)
    if lam > 1.0:
        s = math.sqrt(lam)
        rx *= s
        ry *= s

    num = (rx ** 2) * (ry ** 2) - (rx ** 2) * (y1_prime ** 2) - (ry ** 2) * (x1_prime ** 2)
    den = (rx ** 2) * (y1_prime ** 2) + (ry ** 2) * (x1_prime ** 2)
    radicand = max(0.0, num / den if den > 0 else 0.0)
    factor = math.sqrt(radicand)
    if large_arc == sweep:
        factor = -factor

    cx_prime = factor * (rx * y1_prime / ry)
    cy_prime = factor * (-ry * x1_prime / rx)

    cx = cos_phi * cx_prime - sin_phi * cy_prime + (x1 + x2) / 2.0
    cy = sin_phi * cx_prime + cos_phi * cy_prime + (y1 + y2) / 2.0

    def vector_angle(u, v):
        dot = u[0] * v[0] + u[1] * v[1]
        len_prod = math.hypot(u[0], u[1]) * math.hypot(v[0], v[1])
        cos_ang = max(-1.0, min(1.0, dot / len_prod if len_prod > 0 else 1.0))
        ang = math.acos(cos_ang)
        if u[0] * v[1] - u[1] * v[0] < 0:
            ang = -ang
        return ang

    v1 = ((x1_prime - cx_prime) / rx, (y1_prime - cy_prime) / ry)
    v2 = ((-x1_prime - cx_prime) / rx, (-y1_prime - cy_prime) / ry)
    theta1 = vector_angle((1.0, 0.0), v1)
    d_theta = vector_angle(v1, v2) % (2 * math.pi)

    if not sweep and d_theta > 0:
        d_theta -= 2 * math.pi
    elif sweep and d_theta < 0:
        d_theta += 2 * math.pi

    pts = []
    num_pts = max(4, int(subdivisions * abs(d_theta) / (math.pi / 2)))
    for i in range(1, num_pts + 1):
        theta = theta1 + d_theta * (i / num_pts)
        ex = rx * math.cos(theta)
        ey = ry * math.sin(theta)
        px = cos_phi * ex - sin_phi * ey + cx
        py = sin_phi * ex + cos_phi * ey + cy
        pts.append((px, py))

    return pts


def parse_path_d(d_str: str) -> List[Tuple[Polyline, bool]]:
    """
    Parse an SVG path 'd' string.
    
    Returns:
        List of (polyline, is_closed) tuples.
    """
    tokens = tokenize_path_d(d_str)
    if not tokens:
        return []

    results = []
    current_poly = []
    is_closed = False
    curr_x, curr_y = 0.0, 0.0
    start_x, start_y = 0.0, 0.0
    last_cubic_ctrl = None
    last_quad_ctrl = None

    idx = 0
    cmd = 'M'

    while idx < len(tokens):
        if isinstance(tokens[idx], str):
            cmd = tokens[idx]
            idx += 1

        is_rel = cmd.islower()
        cmd_u = cmd.upper()

        if cmd_u == 'M':
            if idx + 1 >= len(tokens):
                break
            nx = tokens[idx] + (curr_x if is_rel else 0.0)
            ny = tokens[idx + 1] + (curr_y if is_rel else 0.0)
            idx += 2
            if current_poly and len(current_poly) >= 2:
                results.append((current_poly, is_closed))
            curr_x, curr_y = nx, ny
            start_x, start_y = nx, ny
            current_poly = [(curr_x, curr_y)]
            is_closed = False
            cmd = 'l' if is_rel else 'L'

        elif cmd_u == 'L':
            if idx + 1 >= len(tokens):
                break
            nx = tokens[idx] + (curr_x if is_rel else 0.0)
            ny = tokens[idx + 1] + (curr_y if is_rel else 0.0)
            idx += 2
            curr_x, curr_y = nx, ny
            current_poly.append((curr_x, curr_y))

        elif cmd_u == 'H':
            if idx >= len(tokens):
                break
            nx = tokens[idx] + (curr_x if is_rel else 0.0)
            idx += 1
            curr_x = nx
            current_poly.append((curr_x, curr_y))

        elif cmd_u == 'V':
            if idx >= len(tokens):
                break
            ny = tokens[idx] + (curr_y if is_rel else 0.0)
            idx += 1
            curr_y = ny
            current_poly.append((curr_x, curr_y))

        elif cmd_u == 'C':
            if idx + 5 >= len(tokens):
                break
            ox = curr_x if is_rel else 0.0
            oy = curr_y if is_rel else 0.0
            x1, y1 = tokens[idx] + ox, tokens[idx + 1] + oy
            x2, y2 = tokens[idx + 2] + ox, tokens[idx + 3] + oy
            x, y = tokens[idx + 4] + ox, tokens[idx + 5] + oy
            idx += 6
            curve_pts = evaluate_cubic_bezier((curr_x, curr_y), (x1, y1), (x2, y2), (x, y))
            current_poly.extend(curve_pts)
            curr_x, curr_y = x, y
            last_cubic_ctrl = (x2, y2)

        elif cmd_u == 'S':
            if idx + 3 >= len(tokens):
                break
            ox = curr_x if is_rel else 0.0
            oy = curr_y if is_rel else 0.0
            if last_cubic_ctrl:
                x1 = 2 * curr_x - last_cubic_ctrl[0]
                y1 = 2 * curr_y - last_cubic_ctrl[1]
            else:
                x1, y1 = curr_x, curr_y
            x2, y2 = tokens[idx] + ox, tokens[idx + 1] + oy
            x, y = tokens[idx + 2] + ox, tokens[idx + 3] + oy
            idx += 4
            curve_pts = evaluate_cubic_bezier((curr_x, curr_y), (x1, y1), (x2, y2), (x, y))
            current_poly.extend(curve_pts)
            curr_x, curr_y = x, y
            last_cubic_ctrl = (x2, y2)

        elif cmd_u == 'Q':
            if idx + 3 >= len(tokens):
                break
            ox = curr_x if is_rel else 0.0
            oy = curr_y if is_rel else 0.0
            x1, y1 = tokens[idx] + ox, tokens[idx + 1] + oy
            x, y = tokens[idx + 2] + ox, tokens[idx + 3] + oy
            idx += 4
            curve_pts = evaluate_quadratic_bezier((curr_x, curr_y), (x1, y1), (x, y))
            current_poly.extend(curve_pts)
            curr_x, curr_y = x, y
            last_quad_ctrl = (x1, y1)

        elif cmd_u == 'T':
            if idx + 1 >= len(tokens):
                break
            ox = curr_x if is_rel else 0.0
            oy = curr_y if is_rel else 0.0
            if last_quad_ctrl:
                x1 = 2 * curr_x - last_quad_ctrl[0]
                y1 = 2 * curr_y - last_quad_ctrl[1]
            else:
                x1, y1 = curr_x, curr_y
            x, y = tokens[idx] + ox, tokens[idx + 1] + oy
            idx += 2
            curve_pts = evaluate_quadratic_bezier((curr_x, curr_y), (x1, y1), (x, y))
            current_poly.extend(curve_pts)
            curr_x, curr_y = x, y
            last_quad_ctrl = (x1, y1)

        elif cmd_u == 'A':
            if idx + 6 >= len(tokens):
                break
            rx = abs(tokens[idx])
            ry = abs(tokens[idx + 1])
            phi = tokens[idx + 2]
            large_arc = bool(tokens[idx + 3])
            sweep = bool(tokens[idx + 4])
            ox = curr_x if is_rel else 0.0
            oy = curr_y if is_rel else 0.0
            x = tokens[idx + 5] + ox
            y = tokens[idx + 6] + oy
            idx += 7
            arc_pts = evaluate_arc((curr_x, curr_y), rx, ry, phi, large_arc, sweep, (x, y))
            current_poly.extend(arc_pts)
            curr_x, curr_y = x, y

        elif cmd_u == 'Z':
            if current_poly:
                current_poly.append((start_x, start_y))
                results.append((current_poly, True))
                current_poly = []
                is_closed = True
                curr_x, curr_y = start_x, start_y

        else:
            idx += 1

        if cmd_u not in ('C', 'S'):
            last_cubic_ctrl = None
        if cmd_u not in ('Q', 'T'):
            last_quad_ctrl = None

    if current_poly and len(current_poly) >= 2:
        results.append((current_poly, is_closed))

    return results


# -----------------------------
# PCB Shape Element Classes
# -----------------------------
class PCBShape:
    def __init__(self, kind: str, points: Polyline, is_closed: bool = False, stroke_w: float = 0.6, is_fill: bool = True):
        self.kind = kind  # 'trace', 'pad_circle', 'pad_rect', 'polygon'
        self.points = points
        self.is_closed = is_closed
        self.stroke_w = stroke_w
        self.is_fill = is_fill
        # Extra circle info if applicable
        self.center = (0.0, 0.0)
        self.radius = 0.0


# -----------------------------
# Element Parsers
# -----------------------------
def parse_circle_shape(elem: ET.Element) -> Optional[PCBShape]:
    cx = float(elem.attrib.get('cx', '0'))
    cy = float(elem.attrib.get('cy', '0'))
    r = float(elem.attrib.get('r', '0'))
    if r <= 0:
        return None
    pts = []
    num_pts = max(16, int(r * 6))
    for i in range(num_pts + 1):
        ang = 2 * math.pi * (i / num_pts)
        pts.append((cx + r * math.cos(ang), cy + r * math.sin(ang)))
    shape = PCBShape('pad_circle', pts, is_closed=True, is_fill=True)
    shape.center = (cx, cy)
    shape.radius = r
    return shape


def parse_ellipse_shape(elem: ET.Element) -> Optional[PCBShape]:
    cx = float(elem.attrib.get('cx', '0'))
    cy = float(elem.attrib.get('cy', '0'))
    rx = float(elem.attrib.get('rx', '0'))
    ry = float(elem.attrib.get('ry', '0'))
    if rx <= 0 or ry <= 0:
        return None
    pts = []
    num_pts = max(16, int(max(rx, ry) * 6))
    for i in range(num_pts + 1):
        ang = 2 * math.pi * (i / num_pts)
        pts.append((cx + rx * math.cos(ang), cy + ry * math.sin(ang)))
    shape = PCBShape('pad_circle', pts, is_closed=True, is_fill=True)
    shape.center = (cx, cy)
    shape.radius = (rx + ry) / 2.0
    return shape


def parse_rect_shape(elem: ET.Element) -> Optional[PCBShape]:
    x = float(elem.attrib.get('x', '0'))
    y = float(elem.attrib.get('y', '0'))
    w = float(elem.attrib.get('width', '0'))
    h = float(elem.attrib.get('height', '0'))
    if w <= 0 or h <= 0:
        return None
    pts = [(x, y), (x + w, y), (x + w, y + h), (x, y + h), (x, y)]
    return PCBShape('pad_rect', pts, is_closed=True, is_fill=True)


def parse_line_shape(elem: ET.Element) -> Optional[PCBShape]:
    x1 = float(elem.attrib.get('x1', '0'))
    y1 = float(elem.attrib.get('y1', '0'))
    x2 = float(elem.attrib.get('x2', '0'))
    y2 = float(elem.attrib.get('y2', '0'))
    return PCBShape('trace', [(x1, y1), (x2, y2)], is_closed=False, is_fill=False)


def parse_polygon_shape(elem: ET.Element) -> Optional[PCBShape]:
    pts_str = elem.attrib.get('points', '')
    coords = [float(x) for x in re.split(r'[\s,]+', pts_str.strip()) if x]
    if len(coords) < 4:
        return None
    pts = [(coords[i], coords[i + 1]) for i in range(0, len(coords) - 1, 2)]
    is_poly = elem.tag.endswith('polygon')
    if is_poly and pts and pts[0] != pts[-1]:
        pts.append(pts[0])
    return PCBShape('polygon' if is_poly else 'trace', pts, is_closed=is_poly, is_fill=is_poly)


# -----------------------------
# Main SVG Vector Parser
# -----------------------------
def parse_svg_pcb_elements(svg_path: str) -> Tuple[List[PCBShape], float, float]:
    """
    Extract all vector shapes from an EasyEDA / KiCad SVG file in physical millimeters.
    """
    tree = ET.parse(svg_path)
    root = tree.getroot()

    viewbox_str = root.attrib.get('viewBox') or root.attrib.get('viewbox')
    vb_x, vb_y, vb_w, vb_h = 0.0, 0.0, 100.0, 100.0
    has_viewbox = False

    if viewbox_str:
        parts = [float(x) for x in re.split(r'[\s,]+', viewbox_str.strip()) if x]
        if len(parts) >= 4:
            vb_x, vb_y, vb_w, vb_h = parts[:4]
            has_viewbox = True

    phys_w = parse_length(root.attrib.get('width'))
    phys_h = parse_length(root.attrib.get('height'))

    if phys_w is None and has_viewbox:
        phys_w = vb_w * (25.4 / 96.0)
    if phys_h is None and has_viewbox:
        phys_h = vb_h * (25.4 / 96.0)

    phys_w = phys_w or 100.0
    phys_h = phys_h or 100.0

    if has_viewbox and vb_w > 0 and vb_h > 0:
        scale_x = phys_w / vb_w
        scale_y = phys_h / vb_h
    else:
        scale_x = 25.4 / 96.0
        scale_y = 25.4 / 96.0

    shapes: List[PCBShape] = []

    def traverse(node, current_mat):
        node_transform = node.attrib.get('transform', '')
        mat = current_mat @ parse_transform(node_transform)

        tag = node.tag.split('}')[-1] if '}' in node.tag else node.tag

        # Style attributes
        style = parse_style(node.attrib.get('style', ''))
        fill_val = style.get('fill', node.attrib.get('fill', '')).lower()
        stroke_val = style.get('stroke', node.attrib.get('stroke', '')).lower()

        # Skip white cutouts/holes if desired
        if fill_val in ('#ffffff', '#fff', 'white') and stroke_val in ('#ffffff', '#fff', 'white', 'none', ''):
            for child in node:
                traverse(child, mat)
            return

        has_fill = (fill_val not in ('none', 'transparent', ''))
        has_stroke = (stroke_val not in ('none', 'transparent', ''))

        if tag == 'path':
            d = node.attrib.get('d', '')
            if d:
                for poly, is_closed in parse_path_d(d):
                    if len(poly) >= 2:
                        tf_poly = apply_transform(poly, mat)
                        kind = 'polygon' if (is_closed and has_fill) else 'trace'
                        s = PCBShape(kind, tf_poly, is_closed=is_closed, is_fill=(is_closed and has_fill))
                        shapes.append(s)

        elif tag == 'circle':
            s = parse_circle_shape(node)
            if s and len(s.points) >= 2:
                s.points = apply_transform(s.points, mat)
                cx, cy = s.center
                v = mat @ np.array([cx, cy, 1.0])
                s.center = (v[0], v[1])
                s.radius = s.radius * ((mat[0,0]**2 + mat[0,1]**2)**0.5)
                shapes.append(s)

        elif tag == 'ellipse':
            s = parse_ellipse_shape(node)
            if s and len(s.points) >= 2:
                s.points = apply_transform(s.points, mat)
                cx, cy = s.center
                v = mat @ np.array([cx, cy, 1.0])
                s.center = (v[0], v[1])
                s.radius = s.radius * ((mat[0,0]**2 + mat[0,1]**2)**0.5)
                shapes.append(s)

        elif tag == 'rect':
            s = parse_rect_shape(node)
            if s and len(s.points) >= 2:
                s.points = apply_transform(s.points, mat)
                shapes.append(s)

        elif tag == 'line':
            s = parse_line_shape(node)
            if s and len(s.points) >= 2:
                s.points = apply_transform(s.points, mat)
                shapes.append(s)

        elif tag in ('polygon', 'polyline'):
            s = parse_polygon_shape(node)
            if s and len(s.points) >= 2:
                s.points = apply_transform(s.points, mat)
                shapes.append(s)

        for child in node:
            traverse(child, mat)

    traverse(root, np.eye(3, dtype=np.float64))

    # Scale shapes to millimeter units
    mm_shapes: List[PCBShape] = []
    for s in shapes:
        mm_pts = [((x - vb_x) * scale_x, (y - vb_y) * scale_y) for x, y in s.points]
        s.points = mm_pts
        if s.kind == 'pad_circle':
            cx, cy = s.center
            s.center = ((cx - vb_x) * scale_x, (cy - vb_y) * scale_y)
            s.radius = s.radius * scale_x
        mm_shapes.append(s)

    return mm_shapes, phys_w, phys_h


# -----------------------------
# Solid Etch-Resist Vector Infill Generator
# -----------------------------
def generate_solid_pad_toolpaths(shape: PCBShape, marker_tip_mm: float, overlap_pct: float) -> List[Polyline]:
    """
    Generate solid concentric etch-resist fill for pads and closed polygons without raster artifacts.
    """
    paths = []
    step_mm = max(0.15, marker_tip_mm * (1.0 - (overlap_pct / 100.0)))

    if shape.kind == 'pad_circle':
        # Outer ring perimeter
        paths.append(shape.points)
        cx, cy = shape.center
        r = shape.radius
        curr_r = r - step_mm
        # Concentric inner rings down to center/drill hole (leave ~0.4mm center dot for drilling)
        while curr_r >= 0.4:
            pts = []
            num_pts = max(12, int(curr_r * 6))
            for i in range(num_pts + 1):
                ang = 2 * math.pi * (i / num_pts)
                pts.append((cx + curr_r * math.cos(ang), cy + curr_r * math.sin(ang)))
            paths.append(pts)
            curr_r -= step_mm

    elif shape.kind == 'pad_rect' or shape.kind == 'polygon':
        # Outer perimeter
        paths.append(shape.points)
        poly = shape.points
        # Concentric shrink offsets
        shrink = step_mm
        for _ in range(10):
            # Compute centroid
            xs = [p[0] for p in poly]
            ys = [p[1] for p in poly]
            w = max(xs) - min(xs)
            h = max(ys) - min(ys)
            if w <= shrink * 2 or h <= shrink * 2:
                break
            cx = sum(xs) / len(xs)
            cy = sum(ys) / len(ys)
            scale_x = max(0.05, (w - shrink * 2) / max(0.01, w))
            scale_y = max(0.05, (h - shrink * 2) / max(0.01, h))
            inner_poly = [(cx + (x - cx) * scale_x, cy + (y - cy) * scale_y) for x, y in poly]
            paths.append(inner_poly)
            poly = inner_poly

    else:
        paths.append(shape.points)

    return paths


# -----------------------------
# End-to-End PCB Processor
# -----------------------------
def process_pcb_svg(
    svg_path: str,
    pcb_board_w_mm: float,
    pcb_board_h_mm: float,
    pcb_board_bed_x: float,
    pcb_board_bed_y: float,
    mirror_x: bool = True,
    rotation_deg: float = 0.0,
    trace_shift_x: float = 0.0,
    trace_shift_y: float = 0.0,
    auto_center: bool = True,
    marker_tip_mm: float = 0.6,
    overlap_pct: float = 40.0,
    infill_mode: str = "solid",
) -> Tuple[List[Polyline], Dict[str, Any]]:
    """
    Process EasyEDA PCB SVG into true vector toolpaths with solid etch-resist infill,
    custom trace X/Y offset positioning on the board, and 2D board rotation.
    """
    shapes, nat_w, nat_h = parse_svg_pcb_elements(svg_path)
    if not shapes:
        return [], {"error": "No vector elements found in SVG."}

    # Extract all points across all shapes to compute bounding box
    all_pts = [p for s in shapes for p in s.points]
    if not all_pts:
        return [], {"error": "Empty shape points."}

    all_x = [p[0] for p in all_pts]
    all_y = [p[1] for p in all_pts]
    min_x, max_x = min(all_x), max(all_x)
    min_y, max_y = min(all_y), max(all_y)
    trace_w = max(0.1, max_x - min_x)
    trace_h = max(0.1, max_y - min_y)

    # Shift all shapes so top-left aligns with origin (0, 0)
    for s in shapes:
        s.points = [(x - min_x, y - min_y) for x, y in s.points]
        if s.kind == 'pad_circle':
            cx, cy = s.center
            s.center = (cx - min_x, cy - min_y)

    # Position shapes inside the physical blank copper clad board dimensions
    base_margin_x = max(0.0, (pcb_board_w_mm - trace_w) / 2.0) if auto_center else 0.0
    base_margin_y = max(0.0, (pcb_board_h_mm - trace_h) / 2.0) if auto_center else 0.0

    pos_x = base_margin_x + trace_shift_x
    pos_y = base_margin_y + trace_shift_y

    for s in shapes:
        s.points = [(x + pos_x, y + pos_y) for x, y in s.points]
        if s.kind == 'pad_circle':
            cx, cy = s.center
            s.center = (cx + pos_x, cy + pos_y)

    # Apply Horizontal Mirroring for Bottom Layer (solder/copper side)
    if mirror_x:
        for s in shapes:
            s.points = [(pcb_board_w_mm - x, y) for x, y in s.points]
            if s.kind == 'pad_circle':
                cx, cy = s.center
                s.center = (pcb_board_w_mm - cx, cy)

    # Generate toolpaths
    raw_toolpaths: List[Polyline] = []
    for s in shapes:
        if s.kind == 'trace':
            # Traces are direct vector paths!
            raw_toolpaths.append(s.points)
        elif s.is_fill and infill_mode in ('solid', 'outline_and_hatch'):
            # Pads / zones get solid concentric vector infill
            pad_paths = generate_solid_pad_toolpaths(s, marker_tip_mm, overlap_pct)
            raw_toolpaths.extend(pad_paths)
        else:
            raw_toolpaths.append(s.points)

    # Apply 2D Board Rotation around board center
    if abs(rotation_deg) > 0.001:
        rad = math.radians(rotation_deg)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)
        cx = pcb_board_w_mm / 2.0
        cy = pcb_board_h_mm / 2.0
        rotated_toolpaths = []
        for poly in raw_toolpaths:
            rot_poly = []
            for x, y in poly:
                rx = cx + (x - cx) * cos_a - (y - cy) * sin_a
                ry = cy + (x - cx) * sin_a + (y - cy) * cos_a
                rot_poly.append((rx, ry))
            rotated_toolpaths.append(rot_poly)
        raw_toolpaths = rotated_toolpaths

    # Map to print bed coordinates: PCB placed at (pcb_board_bed_x, pcb_board_bed_y)
    bed_paths: List[Polyline] = []
    for poly in raw_toolpaths:
        bed_poly = []
        for x, y in poly:
            bx = pcb_board_bed_x + x
            # Invert Y so top of SVG board corresponds to upper bed Y
            by = pcb_board_bed_y + (pcb_board_h_mm - y)
            bed_poly.append((bx, by))
        if len(bed_poly) >= 2:
            bed_paths.append(bed_poly)

    metadata = {
        "trace_w_mm": trace_w,
        "trace_h_mm": trace_h,
        "pcb_board_w_mm": pcb_board_w_mm,
        "pcb_board_h_mm": pcb_board_h_mm,
        "bed_origin": (pcb_board_bed_x, pcb_board_bed_y),
        "mirrored": mirror_x,
        "rotation_deg": rotation_deg,
        "total_paths": len(bed_paths),
    }

    return bed_paths, metadata
