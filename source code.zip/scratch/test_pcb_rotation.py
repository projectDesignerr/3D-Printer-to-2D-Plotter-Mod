"""
Test script for verifying PCB Board Rotation in svg_processor, preview, and GUI.
"""

import sys
import os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import svg_processor
from gcode_engine import PlotterConfig, generate_gcode_paths, save_gcode


def test_pcb_rotation():
    print("=== Testing PCB Board Rotation ===")
    svg_file = "scratch/test_pcb_board.svg"

    # Test 0 deg
    paths_0, meta_0 = svg_processor.process_pcb_svg(
        svg_path=svg_file,
        pcb_board_w_mm=70.0,
        pcb_board_h_mm=50.0,
        pcb_board_bed_x=30.0,
        pcb_board_bed_y=40.0,
        rotation_deg=0.0,
    )

    # Test 90 deg rotation
    paths_90, meta_90 = svg_processor.process_pcb_svg(
        svg_path=svg_file,
        pcb_board_w_mm=70.0,
        pcb_board_h_mm=50.0,
        pcb_board_bed_x=30.0,
        pcb_board_bed_y=40.0,
        rotation_deg=90.0,
    )

    # Test 180 deg rotation
    paths_180, meta_180 = svg_processor.process_pcb_svg(
        svg_path=svg_file,
        pcb_board_w_mm=70.0,
        pcb_board_h_mm=50.0,
        pcb_board_bed_x=30.0,
        pcb_board_bed_y=40.0,
        rotation_deg=180.0,
    )

    assert len(paths_0) == len(paths_90) == len(paths_180), "Path counts must match across rotations"
    print(f"Path count: {len(paths_0)} across all rotation angles")

    # Verify GUI controls
    from gui import PlotterGUI
    app = PlotterGUI()
    app.update()

    app.tabview.set("⚡ PCB")
    app._on_tab_change()
    app._current_pcb_path = svg_file

    # Set 90 deg rotation in GUI
    app._set_pcb_rotation(90.0)
    app.update()

    assert app.preview._pcb_cfg.get("rotation_deg") == 90.0, "Preview PCB cfg rotation must be 90"

    # Test Swap W/H button
    orig_w = float(app.pcb_w_entry.get())
    orig_h = float(app.pcb_h_entry.get())
    app._swap_pcb_dimensions()
    app.update()

    new_w = float(app.pcb_w_entry.get())
    new_h = float(app.pcb_h_entry.get())
    assert new_w == orig_h and new_h == orig_w, "Swap W/H should invert dimensions"
    print(f"Swap W/H verified: {orig_w}x{orig_h} -> {new_w}x{new_h}")

    app.destroy()
    print("✓ PCB Board Rotation test PASSED successfully!")


if __name__ == "__main__":
    test_pcb_rotation()
