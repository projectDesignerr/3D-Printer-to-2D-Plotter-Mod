"""
test_removable.py — Automated verification for removable media (SD Card / USB) features.
"""

import os
import sys
import tempfile
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import media_manager
from gcode_engine import PlotterConfig, generate_gcode_text


def test_media_manager():
    print("=== Testing media_manager ===")
    drives = media_manager.get_removable_drives()
    print(f"Detected removable drives: {len(drives)}")
    for d in drives:
        print(f"  • {d['short_display']} -> {d['path']} ({d['free_gb']:.1f} GB)")

    # Test saving G-Code to a temporary directory acting as drive root
    with tempfile.TemporaryDirectory() as tmp_drive:
        cfg = PlotterConfig(text="Removable Test")
        builder = generate_gcode_text(cfg)
        ok, full_path, msg = media_manager.save_gcode_to_removable(
            builder.lines, tmp_drive, "test_print.gcode"
        )
        assert ok, f"save_gcode_to_removable failed: {msg}"
        assert os.path.isfile(full_path)
        content = Path(full_path).read_text(encoding="ascii")
        assert len(content.splitlines()) == len(builder.lines)
        print(f"✓ G-code successfully saved to mock drive: {full_path}")

    print("✓ media_manager tests passed!")


def test_gui_removable_integration():
    print("\n=== Testing GUI Removable Drive Integration ===")
    from gui import PlotterGUI
    app = PlotterGUI()
    app.update()

    assert hasattr(app, "removable_btn"), "GUI missing removable_btn"
    assert hasattr(app, "eject_btn"), "GUI missing eject_btn"

    # Trigger scan
    app._check_removable_drives()
    app.update()

    btn_text = app.removable_btn.cget("text")
    print(f"Removable button text: '{btn_text}'")

    if app._detected_removable_drives:
        print(f"✓ Detected drive active in GUI: {app._detected_removable_drives[0]['short_display']}")
        assert "Save to" in btn_text
    else:
        print("✓ No removable drive detected (button cleanly in disabled state)")

    app.destroy()
    print("✓ GUI removable media integration passed!")


if __name__ == "__main__":
    test_media_manager()
    test_gui_removable_integration()
    print("\n🎉 ALL REMOVABLE MEDIA TESTS PASSED!")
