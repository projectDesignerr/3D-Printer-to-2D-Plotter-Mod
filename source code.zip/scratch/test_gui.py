"""
Test script for verifying PlotterGUI instantiation, tab switching, and config retrieval.
"""

import os
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import gui
from gui import PlotterGUI


def test_gui_init_and_config():
    print("=== Testing PlotterGUI initialization & Settings ===")
    app = PlotterGUI()
    app.update()

    # Verify tabs exist
    assert "✏️  Text" in app.tabview._tab_dict
    assert "🖼️  Image" in app.tabview._tab_dict
    assert "⚙️  Settings" in app.tabview._tab_dict
    print("✓ All 3 tabs created successfully!")

    # Verify settings entries
    assert "offset_x" in app._settings_entries
    assert "offset_y" in app._settings_entries
    assert "offset_z" in app._settings_entries
    assert "bed_x" in app._settings_entries
    assert "bed_y" in app._settings_entries
    assert "pen_touch_z" in app._settings_entries
    print("✓ All settings fields registered!")

    # Test setting offset values and getting config
    app._apply_offset_preset(5.0, -35.0, 1.0)
    cfg = app._get_config()
    assert cfg.offset_x == 5.0
    assert cfg.offset_y == -35.0
    assert cfg.offset_z == 1.0
    print(f"✓ Retrieved config with offsets: X={cfg.offset_x}, Y={cfg.offset_y}, Z={cfg.offset_z}")

    # Test live preview generation with text
    app.tabview.set("✏️  Text")
    app._update_live_preview()
    assert app._last_builder is not None
    print("✓ Live preview generated with builder successfully!")

    # Test saving settings
    app._on_save_settings()
    assert "saved" in app.settings_status_label.cget("text").lower()
    print("✓ Settings saved callback works!")

    # Backup original config before test
    orig_cfg = config_manager.load_config()
    try:
        app._on_reset_settings()
        cfg_reset = app._get_config()
        assert cfg_reset.offset_x == 0.0
        assert cfg_reset.offset_y == 49.5
        print("✓ Settings reset callback works!")
    finally:
        config_manager.save_config(orig_cfg)

    app.destroy()
    print("\n🎉 GUI INTEGRATION TESTS PASSED!")


if __name__ == "__main__":
    test_gui_init_and_config()
