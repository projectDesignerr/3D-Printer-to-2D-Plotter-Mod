"""
Test script for EasyEDA SVG parsing, true mm accuracy, board mapping, and etch-resist infill.
"""

import sys
import os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import svg_processor


def test_svg_pcb_processing():
    print("=== Testing EasyEDA SVG PCB Processing ===")

    # 1. Create a realistic EasyEDA PCB SVG snippet
    # Contains:
    # - 2.54mm pitch DIP pads (circles with drill holes)
    # - 45-degree angled 0.8mm traces (paths)
    # - SMD 0805 rectangular pads
    # - Copper ground plane polygon
    svg_content = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="60mm" height="40mm" viewBox="0 0 60 40">
    <g id="BottomLayer" fill="#000000" stroke="none">
        <!-- DIP Pin 1 & 2 at 2.54mm pitch -->
        <circle cx="10" cy="20" r="1.5" />
        <circle cx="12.54" cy="20" r="1.5" />
        <circle cx="15.08" cy="20" r="1.5" />
        
        <!-- SMD Pads -->
        <rect x="25" y="15" width="1.6" height="2.0" />
        <rect x="28" y="15" width="1.6" height="2.0" />
        
        <!-- 45-degree Trace -->
        <path d="M 10 20 L 10 28 L 18 36 L 35 36" stroke="#000000" stroke-width="0.8" fill="none" />
        
        <!-- IC Package Outline -->
        <polygon points="40,10 55,10 55,25 40,25" />
    </g>
</svg>"""

    os.makedirs("scratch", exist_ok=True)
    svg_file = "scratch/test_pcb_board.svg"
    with open(svg_file, "w", encoding="utf-8") as f:
        f.write(svg_content)

    print(f"Created synthetic PCB SVG: {svg_file}")

    # 2. Process PCB with 70mm x 50mm blank copper clad placed at (30, 40) on bed
    pcb_w = 70.0
    pcb_h = 50.0
    bed_x = 30.0
    bed_y = 40.0

    paths, meta = svg_processor.process_pcb_svg(
        svg_path=svg_file,
        pcb_board_w_mm=pcb_w,
        pcb_board_h_mm=pcb_h,
        pcb_board_bed_x=bed_x,
        pcb_board_bed_y=bed_y,
        mirror_x=True,  # Bottom copper layer
        marker_tip_mm=0.6,
        overlap_pct=40.0,
        infill_mode="solid",
    )

    print(f"Total extracted PCB toolpaths (outlines + infill): {len(paths)}")
    assert len(paths) > 10, "Should generate outlines and etch-resist infill paths"

    # Check bounds on bed
    all_x = [p[0] for poly in paths for p in poly]
    all_y = [p[1] for poly in paths for p in poly]
    min_x, max_x = min(all_x), max(all_x)
    min_y, max_y = min(all_y), max(all_y)

    print(f"Bed X range: {min_x:.2f} to {max_x:.2f} mm (Board: {bed_x} to {bed_x + pcb_w})")
    print(f"Bed Y range: {min_y:.2f} to {max_y:.2f} mm (Board: {bed_y} to {bed_y + pcb_h})")

    assert min_x >= bed_x - 0.1 and max_x <= bed_x + pcb_w + 0.1, "Traces must be contained inside PCB board X bounds"
    assert min_y >= bed_y - 0.1 and max_y <= bed_y + pcb_h + 0.1, "Traces must be contained inside PCB board Y bounds"

    print("✓ EasyEDA SVG PCB trace extraction and board mapping PASSED!")


if __name__ == "__main__":
    test_svg_pcb_processing()
