"""
Test script for 100% Authentic Signature Curve Fidelity (Catmull-Rom Spline).
"""

import sys
import math
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import numpy as np
import cv2
from PIL import Image

import image_processor


def test_curve_fidelity():
    print("=== Testing Signature Curve Fidelity ===")

    # 1. Create a signature with sharp crests, loops, and distinctive handwritten flourishes
    h, w = 400, 800
    img = np.full((h, w), 255, dtype=np.uint8)
    
    # Intricate signature curve points
    original_control_points = [
        (80, 200), (120, 80), (140, 250), (180, 120), (220, 260),
        (260, 90), (320, 220), (380, 140), (450, 240), (550, 100), (700, 200)
    ]
    pts = np.array(original_control_points, np.int32)
    cv2.polylines(img, [pts], False, 0, 4, cv2.LINE_AA)
    # Loop flourish
    cv2.ellipse(img, (260, 140), (35, 60), 30, 0, 360, 0, 4, cv2.LINE_AA)

    test_path = "scratch/test_curve_fidelity.png"
    Image.fromarray(img).save(test_path)

    # 2. Extract paths with authentic curve fidelity
    paths, _, _ = image_processor.image_to_paths(
        image_path=test_path,
        target_width_mm=120.0,
        fill_mode="signature",
        simplify=0.1,  # Ultra-fine fidelity
        smooth_iterations=0,  # Exact original curves
    )

    print(f"Extracted {len(paths)} stroke(s).")
    assert len(paths) >= 1

    # Verify that the extracted path captures all the peaks without cutting corners
    poly = paths[0]
    y_coords = [p[1] for p in poly]
    min_y = min(y_coords)
    max_y = max(y_coords)
    height_mm = max_y - min_y
    print(f"Stroke height: {height_mm:.2f} mm")
    assert height_mm > 20.0, "Extracted signature must preserve full vertical stroke range!"

    print("✓ 100% Authentic signature curve fidelity verified!")


if __name__ == "__main__":
    test_curve_fidelity()
