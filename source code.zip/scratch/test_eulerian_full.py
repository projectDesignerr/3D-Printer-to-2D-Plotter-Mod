"""
Comprehensive test for Eulerian Single-Stroke Graph Traversal on Skeletons.
"""

import sys
import math
import collections
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import cv2
from PIL import Image

import image_processor
from gcode_engine import PlotterConfig, generate_gcode_paths


def trace_skeleton_eulerian(skeleton: np.ndarray, bridge_gap_px: int = 3) -> list:
    """
    Extract 1-stroke continuous Eulerian paths from a 1-pixel skeleton image.
    Every connected component of the skeleton is traversed as a single continuous polyline
    using Chinese Postman / Eulerian trail single-stroke puzzle logic.
    """
    h, w = skeleton.shape
    skel = (skeleton > 0).astype(np.uint8)
    
    # 0. Bridge tiny gaps between nearby endpoints to merge fragmented strokes into 1 continuous component
    if bridge_gap_px > 0:
        # Find endpoints (pixels with exactly 1 neighbor in 8-connectivity)
        padded = np.pad(skel, 1, mode="constant", constant_values=0)
        p2 = padded[:-2, 1:-1]; p3 = padded[:-2, 2:]; p4 = padded[1:-1, 2:]; p5 = padded[2:, 2:]
        p6 = padded[2:, 1:-1]; p7 = padded[2:, :-2]; p8 = padded[1:-1, :-2]; p9 = padded[:-2, :-2]
        nbr_count = p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9
        endpoint_mask = (skel == 1) & (nbr_count == 1)
        ey, ex = np.where(endpoint_mask)
        endpoints = list(zip(ex, ey))
        
        # Connect endpoints within bridge_gap_px distance
        for i in range(len(endpoints)):
            x1, y1 = endpoints[i]
            best_j = -1
            best_dist = bridge_gap_px + 0.1
            for j in range(i + 1, len(endpoints)):
                x2, y2 = endpoints[j]
                d = math.hypot(x2 - x1, y2 - y1)
                if 1 < d <= bridge_gap_px and d < best_dist:
                    best_dist = d
                    best_j = j
            if best_j != -1:
                x2, y2 = endpoints[best_j]
                cv2.line(skel, (x1, y1), (x2, y2), 1, 1)

    ys, xs = np.where(skel > 0)
    if len(ys) == 0:
        return []

    # 1. Build pixel graph adjacency
    pixel_neighbors = collections.defaultdict(set)
    for y, x in zip(ys, xs):
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and skel[ny, nx]:
                    pixel_neighbors[(x, y)].add((nx, ny))

    # 2. Find connected components of pixels
    visited_pixels = set()
    components = []
    # Sort pixels left-to-right, top-to-bottom for natural writing order
    sorted_all_pixels = sorted(pixel_neighbors.keys(), key=lambda p: (p[0], p[1]))
    
    for p in sorted_all_pixels:
        if p not in visited_pixels:
            comp = []
            queue = collections.deque([p])
            visited_pixels.add(p)
            while queue:
                curr = queue.popleft()
                comp.append(curr)
                for nbr in pixel_neighbors[curr]:
                    if nbr not in visited_pixels:
                        visited_pixels.add(nbr)
                        queue.append(nbr)
            components.append(comp)

    all_continuous_paths = []

    for comp in components:
        comp_set = set(comp)
        if len(comp) <= 2:
            all_continuous_paths.append(comp)
            continue

        # Classify nodes: Endpoints (deg 1), Junctions (deg >= 3), Curve points (deg 2)
        junctions = set()
        endpoints = []
        for p in comp:
            deg = len(pixel_neighbors[p] & comp_set)
            if deg == 1:
                endpoints.append(p)
            elif deg >= 3:
                junctions.add(p)

        # Merge adjacent junction pixels into single cluster representatives
        cluster_rep = {}
        junction_clusters = {}
        cluster_id = 0
        visited_j = set()
        for j in junctions:
            if j not in visited_j:
                c_members = [j]
                q = [j]
                visited_j.add(j)
                while q:
                    curr = q.pop()
                    for nbr in pixel_neighbors[curr]:
                        if nbr in junctions and nbr not in visited_j:
                            visited_j.add(nbr)
                            q.append(nbr)
                            c_members.append(nbr)
                rep = (
                    int(round(sum(p[0] for p in c_members) / len(c_members))),
                    int(round(sum(p[1] for p in c_members) / len(c_members))),
                )
                for m in c_members:
                    cluster_rep[m] = rep
                junction_clusters[cluster_id] = (rep, c_members)
                cluster_id += 1

        key_vertices = set(endpoints) | {rep for rep, _ in junction_clusters.values()}

        # If it's a closed loop without endpoints or junctions, pick the leftmost-topmost pixel
        if not key_vertices:
            sorted_comp = sorted(comp, key=lambda p: (p[0], p[1]))
            key_vertices.add(sorted_comp[0])

        # Extract topological edges between key vertices
        edges = []
        edge_id = 0
        visited_edge_pixel_pairs = set()

        for u_pix in comp:
            u_key = cluster_rep.get(u_pix, u_pix) if u_pix in junctions else (u_pix if u_pix in key_vertices else None)
            if u_key is None:
                continue

            for next_pix in pixel_neighbors[u_pix]:
                if u_pix in junctions and next_pix in junctions and cluster_rep.get(u_pix) == cluster_rep.get(next_pix):
                    continue

                pair_key = tuple(sorted([u_pix, next_pix]))
                if pair_key in visited_edge_pixel_pairs:
                    continue

                path_pts = [u_key, next_pix]
                visited_edge_pixel_pairs.add(pair_key)
                prev_p = u_pix
                curr_p = next_pix

                while True:
                    if curr_p in junctions:
                        v_key = cluster_rep[curr_p]
                        if v_key != path_pts[-1]:
                            path_pts.append(v_key)
                        break
                    elif curr_p in key_vertices:
                        v_key = curr_p
                        break

                    nbrs = [n for n in pixel_neighbors[curr_p] if n != prev_p and n in comp_set]
                    if not nbrs:
                        v_key = curr_p
                        break

                    next_p = nbrs[0]
                    visited_edge_pixel_pairs.add(tuple(sorted([curr_p, next_p])))
                    path_pts.append(next_p)
                    prev_p = curr_p
                    curr_p = next_p

                length = sum(math.hypot(path_pts[k+1][0] - path_pts[k][0], path_pts[k+1][1] - path_pts[k][1]) for k in range(len(path_pts)-1))
                if length > 0 or u_key != v_key:
                    edges.append({
                        "id": edge_id,
                        "u": u_key,
                        "v": v_key,
                        "pts": path_pts,
                        "len": max(0.1, length)
                    })
                    edge_id += 1

        if not edges:
            continue

        # 3. Build multigraph for Eulerian traversal
        adj = collections.defaultdict(list)
        for e in edges:
            adj[e["u"]].append(e)
            adj[e["v"]].append(e)

        # 4. Chinese Postman: Match odd degree vertices to make the component Eulerian (<= 2 odd vertices)
        odd_vertices = [v for v in adj if len(adj[v]) % 2 != 0]

        if len(odd_vertices) > 2:
            def shortest_path(start, target):
                dist = {start: 0}
                prev = {}
                import heapq
                q = [(0, start)]
                while q:
                    d, u = heapq.heappop(q)
                    if u == target:
                        break
                    if d > dist.get(u, float('inf')):
                        continue
                    for edge in adj[u]:
                        nbr = edge["v"] if edge["u"] == u else edge["u"]
                        new_d = d + edge["len"]
                        if new_d < dist.get(nbr, float('inf')):
                            dist[nbr] = new_d
                            prev[nbr] = (u, edge)
                            heapq.heappush(q, (new_d, nbr))
                if target not in prev:
                    return float('inf'), []
                path_edges = []
                curr = target
                while curr != start:
                    p_node, p_edge = prev[curr]
                    path_edges.append(p_edge)
                    curr = p_node
                return dist[target], path_edges

            pairs = []
            for i in range(len(odd_vertices)):
                for j in range(i + 1, len(odd_vertices)):
                    v1, v2 = odd_vertices[i], odd_vertices[j]
                    d, p_edges = shortest_path(v1, v2)
                    pairs.append((d, v1, v2, p_edges))

            pairs.sort(key=lambda x: x[0])

            matched_nodes = set()
            for d, v1, v2, p_edges in pairs:
                if len(odd_vertices) - len(matched_nodes) <= 2:
                    break
                if v1 not in matched_nodes and v2 not in matched_nodes:
                    matched_nodes.add(v1)
                    matched_nodes.add(v2)
                    for pe in p_edges:
                        dup_e = {
                            "id": edge_id,
                            "u": pe["u"],
                            "v": pe["v"],
                            "pts": list(pe["pts"]),
                            "len": pe["len"]
                        }
                        edge_id += 1
                        edges.append(dup_e)
                        adj[dup_e["u"]].append(dup_e)
                        adj[dup_e["v"]].append(dup_e)

        # 5. Hierholzer's Algorithm
        final_odds = [v for v in adj if len(adj[v]) % 2 != 0]
        if final_odds:
            # Start at the leftmost odd vertex (natural handwriting stroke flow)
            start_v = min(final_odds, key=lambda p: (p[0], p[1]))
        else:
            start_v = min(adj.keys(), key=lambda p: (p[0], p[1]))

        current_adj = {v: list(e_list) for v, e_list in adj.items()}
        stack = [start_v]
        circuit = []

        while stack:
            u = stack[-1]
            if current_adj[u]:
                edge = current_adj[u].pop()
                v = edge["v"] if edge["u"] == u else edge["u"]
                if edge in current_adj[v]:
                    current_adj[v].remove(edge)
                stack.append(v)
            else:
                circuit.append(stack.pop())

        circuit.reverse()

        # Unpack circuit edges into continuous polyline
        continuous_poly = []
        available_edges = list(edges)

        for i in range(len(circuit) - 1):
            u = circuit[i]
            v = circuit[i + 1]
            found_edge = None
            for e in available_edges:
                if (e["u"] == u and e["v"] == v) or (e["u"] == v and e["v"] == u):
                    found_edge = e
                    available_edges.remove(e)
                    break

            if found_edge:
                pts = found_edge["pts"]
                seg_pts = pts if found_edge["u"] == u else list(reversed(pts))
                if not continuous_poly:
                    continuous_poly.extend(seg_pts)
                else:
                    continuous_poly.extend(seg_pts[1:])

        if len(continuous_poly) >= 2:
            # Clean duplicate adjacent points
            clean_poly = [continuous_poly[0]]
            for pt in continuous_poly[1:]:
                if pt[0] != clean_poly[-1][0] or pt[1] != clean_poly[-1][1]:
                    clean_poly.append(pt)
            if len(clean_poly) >= 2:
                all_continuous_paths.append(clean_poly)

    return all_continuous_paths


def test_eulerian():
    print("=== Testing Eulerian Single-Stroke Traversal ===")
    img = np.ones((300, 600), dtype=np.uint8) * 255
    # Cursive signature flourish with 3 loops and cross-strokes
    pts1 = np.array([[50, 200], [100, 80], [150, 70], [180, 180], [220, 90], [270, 80], [300, 220], [380, 140], [500, 220]], np.int32)
    pts2 = np.array([[80, 150], [350, 130]], np.int32)  # Cross stroke
    cv2.polylines(img, [pts1, pts2], False, 0, 5)

    binary = cv2.threshold(img, 128, 255, cv2.THRESH_BINARY_INV)[1]
    skel = image_processor.skeletonize(binary)

    old_paths = image_processor._trace_skeleton_paths(skel)
    new_paths = trace_skeleton_eulerian(skel, bridge_gap_px=4)

    print(f"Old fragmented path count: {len(old_paths)} (causes {len(old_paths)} pen lift/dots!)")
    print(f"Eulerian single-stroke path count: {len(new_paths)} continuous stroke(s)!")
    assert len(new_paths) == 1, f"Expected exactly 1 continuous stroke for connected signature, got {len(new_paths)}"
    print("✓ Complex signature with loops & crossing converted into EXACTLY 1 continuous stroke!")

if __name__ == "__main__":
    test_eulerian()
