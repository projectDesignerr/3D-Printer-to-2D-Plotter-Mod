"""
Test script for High-Accuracy Signature Extraction Pipeline.
"""

import sys
import math
import collections
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import numpy as np
import cv2
from PIL import Image

import image_processor


def test_high_accuracy_pipeline():
    print("=== Testing High-Accuracy Signature Pipeline ===")

    # 1. Create a realistic signature with subtle paper gradient, fine loops, sharp hairpins, and ink variation
    h, w = 300, 600
    paper = np.zeros((h, w), dtype=np.uint8)
    
    # Lighting gradient across paper (darker on left, lighter on right)
    for y in range(h):
        for x in range(w):
            paper[y, x] = int(210 + 35 * (x / w) - 20 * (y / h))

    # Ink layer (dark cursive strokes)
    ink = paper.copy()
    # Main cursive stroke
    pts = np.array([[60, 160], [100, 70], [140, 210], [190, 110], [250, 190], [310, 80], [390, 170], [530, 150]], np.int32)
    cv2.polylines(ink, [pts], False, 30, 5, cv2.LINE_AA)
    # Loop on letter
    cv2.ellipse(ink, (100, 110), (30, 50), 25, 0, 360, 30, 5, cv2.LINE_AA)
    # Sharp hairpin flourish
    pts_sharp = np.array([[190, 110], [200, 40], [215, 110]], np.int32)
    cv2.polylines(ink, [pts_sharp], False, 30, 4, cv2.LINE_AA)
    # Underline flourish
    pts_under = np.array([[40, 230], [270, 250], [560, 220]], np.int32)
    cv2.polylines(ink, [pts_under], False, 30, 4, cv2.LINE_AA)

    # Save realistic test image
    test_img_path = "scratch/test_realistic_signature.png"
    cv2.imwrite(test_img_path, ink)
    print(f"Created realistic signature test image: {test_img_path}")

    # Extract with signature mode
    paths, orig_w, orig_h = image_processor.image_to_paths(
        image_path=test_img_path,
        target_width_mm=100.0,
        fill_mode="signature",
        smooth_iterations=2,
    )

    print(f"Extracted {len(paths)} stroke polylines.")
    assert len(paths) in (1, 2), f"Expected 1 or 2 continuous strokes, got {len(paths)}"
    
    total_pts = sum(len(p) for p in paths)
    print(f"Total high-accuracy curve points: {total_pts}")
    assert total_pts > 50, "Extracted curve should have high detail resolution"

    print("✓ High-accuracy signature extraction test PASSED successfully!")


if __name__ == "__main__":
    test_high_accuracy_pipeline()
