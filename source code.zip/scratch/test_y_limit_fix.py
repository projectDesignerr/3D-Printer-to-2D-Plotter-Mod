"""
test_y_limit_fix.py — Verify that G-code generated for signatures and text
never exceeds the machine carriage limits (e.g. Y=220 mm), fixing the sleeping lines bug.
"""

import os
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import numpy as np
import cv2
from PIL import Image

from gcode_engine import PlotterConfig, GCodeBuilder, generate_gcode_text, generate_gcode_paths, anchor_center
import image_processor
import config_manager


def test_reachable_envelope():
    print("=== Testing Reachable Envelope Properties ===")
    cfg = PlotterConfig(
        bed_x=220.0,
        bed_y=220.0,
        offset_x=0.0,
        offset_y=49.5,
    )
    assert cfg.reachable_x_min == 0.0
    assert cfg.reachable_x_max == 220.0
    assert cfg.reachable_y_min == 0.0
    assert cfg.reachable_y_max == 170.5  # 220 - 49.5
    assert cfg.reachable_width == 220.0
    assert cfg.reachable_height == 170.5
    print(f"✓ Reachable area with offset_y=+49.5mm: {cfg.reachable_width} × {cfg.reachable_height} mm (Y max: {cfg.reachable_y_max} mm)")

    # Negative offset (rear mounted pen)
    cfg_rear = PlotterConfig(bed_x=220.0, bed_y=220.0, offset_x=-10.0, offset_y=-30.0)
    assert cfg_rear.reachable_x_min == 10.0
    assert cfg_rear.reachable_y_min == 30.0
    assert cfg_rear.reachable_x_max == 220.0
    assert cfg_rear.reachable_y_max == 220.0
    print("✓ Rear/left mounted pen reachable envelope verified!")


def test_centering_within_reachable_envelope():
    print("\n=== Testing Centering within Reachable Envelope ===")
    cfg = PlotterConfig(
        bed_x=220.0,
        bed_y=220.0,
        offset_x=0.0,
        offset_y=49.5,
        scale=10.0,
        text="Signature Test",
        center_text=True,
    )
    sx, sy = anchor_center(cfg)
    print(f"Centering placed start at: X={sx:.2f}, Y={sy:.2f}")
    assert sy < 100.0, f"Expected sy < 100 mm for reachable envelope, got {sy}"
    assert sy > 60.0, f"Expected sy > 60 mm, got {sy}"

    # Build G-code and verify max machine Y coordinate
    builder = generate_gcode_text(cfg)
    m_bounds = builder.get_machine_bounds()
    assert m_bounds is not None
    min_mx, min_my, max_mx, max_my = m_bounds
    print(f"Centered Text Machine Coordinates: X=[{min_mx:.2f}, {max_mx:.2f}], Y=[{min_my:.2f}, {max_my:.2f}]")
    assert max_my <= 220.0, f"Machine Y {max_my} exceeded bed_y 220.0!"
    print("✓ Centered text strictly stays inside machine limits (<= 220.0 mm)!")


def test_signature_at_various_y_levels():
    print("\n=== Testing Signature G-Code Machine Limits ===")
    # 1. Create a synthetic signature image
    img = np.ones((200, 400), dtype=np.uint8) * 255
    # Signature loop
    pts = np.array([[50, 150], [100, 50], [180, 40], [250, 120], [300, 60], [350, 160]], np.int32)
    cv2.polylines(img, [pts], False, 0, 4)
    cv2.putText(img, "John Doe", (60, 170), cv2.FONT_HERSHEY_SCRIPT_SIMPLEX, 1.2, 0, 2)

    os.makedirs("scratch", exist_ok=True)
    sig_img_path = "scratch/test_sig_y_check.png"
    Image.fromarray(img).save(sig_img_path)

    # 2. Extract signature paths
    paths, img_w, img_h = image_processor.image_to_paths(
        sig_img_path,
        target_width_mm=100.0,
        target_height_mm=50.0,
        fill_mode="signature",
    )

    cfg = PlotterConfig(
        bed_x=220.0,
        bed_y=220.0,
        offset_x=0.0,
        offset_y=49.5,
    )

    # Test at Y=70 (reachable)
    builder_low = generate_gcode_paths(cfg, paths, offset_x=30.0, offset_y=70.0)
    for line in builder_low.lines:
        if line.startswith("G0 ") or line.startswith("G1 "):
            parts = line.split()
            for part in parts:
                if part.startswith("Y"):
                    y_val = float(part[1:])
                    assert y_val <= 220.001, f"Y value {y_val} exceeded 220.0!"

    print("✓ Signature at Y=70 mm generates clean G-code within bed_y <= 220.0 mm")

    # Test at Y=180 (safety clamped so carriage never exceeds bed_y=220.0)
    builder_high = generate_gcode_paths(cfg, paths, offset_x=30.0, offset_y=180.0)
    for line in builder_high.lines:
        if line.startswith("G0 ") or line.startswith("G1 "):
            parts = line.split()
            for part in parts:
                if part.startswith("Y"):
                    y_val = float(part[1:])
                    assert y_val <= 220.001, f"Y value {y_val} exceeded 220.0!"

    print("✓ Signature at high Y level is safely clamped to bed_y <= 220.0 mm without hardware crash")


if __name__ == "__main__":
    test_reachable_envelope()
    test_centering_within_reachable_envelope()
    test_signature_at_various_y_levels()
    print("\n🎉 ALL Y-LIMIT & REACHABLE ENVELOPE TESTS PASSED SUCCESSFULLY!")
