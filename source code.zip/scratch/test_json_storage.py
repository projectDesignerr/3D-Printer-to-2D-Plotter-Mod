"""
Test script for JSON settings storage, import/export, and CLI config integration.
"""

import os
import sys
import json
import tempfile
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import config_manager
from gui import PlotterGUI


def test_json_storage():
    print("=== Testing JSON Storage Integration ===")

    # 1. Verify default JSON file exists and has valid JSON
    assert Path("plotter_config.json").exists()
    with open("plotter_config.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    assert "offset_x" in data
    assert "offset_y" in data
    assert "offset_z" in data
    print("✓ plotter_config.json is valid JSON!")

    # 2. Test GUI loading and saving to JSON
    app = PlotterGUI()
    app.update()

    # Modify settings in GUI
    app._apply_offset_preset(7.5, -38.0, 0.5)
    app._settings_entries["bed_x"].delete(0, "end")
    app._settings_entries["bed_x"].insert(0, "250.0")

    # Save to JSON
    app._on_save_settings()

    # Verify JSON was written
    with open("plotter_config.json", "r", encoding="utf-8") as f:
        saved_data = json.load(f)
    assert saved_data["offset_x"] == 7.5
    assert saved_data["offset_y"] == -38.0
    assert saved_data["offset_z"] == 0.5
    assert saved_data["bed_x"] == 250.0
    print("✓ GUI saved settings directly to plotter_config.json!")

    # 3. Test Export & Import
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tf:
        export_path = tf.name

    try:
        # Save custom export
        export_dict = app._get_current_settings_dict()
        export_dict["offset_x"] = 15.0
        export_dict["offset_y"] = -45.0
        config_manager.save_config(export_dict, export_path)

        # Re-import into GUI
        imported = config_manager.load_config(export_path)
        for k in ("offset_x", "offset_y"):
            app._settings_entries[k].delete(0, "end")
            app._settings_entries[k].insert(0, str(imported[k]))
        app._save_current_settings_silently()

        assert float(app._settings_entries["offset_x"].get()) == 15.0
        assert float(app._settings_entries["offset_y"].get()) == -45.0
        print("✓ Import & Export workflow passed!")
    finally:
        if os.path.exists(export_path):
            os.remove(export_path)

    # Reset back to default
    app._on_reset_settings()
    app.destroy()
    print("✓ Cleaned up and reset to default config!")


if __name__ == "__main__":
    test_json_storage()
    print("\n🎉 ALL JSON STORAGE TESTS PASSED!")
