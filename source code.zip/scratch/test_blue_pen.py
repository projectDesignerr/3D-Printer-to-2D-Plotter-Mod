"""
Test script for Blue Pen & Multi-Color Ink Extraction.
"""

import sys
import os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import numpy as np
import cv2
from PIL import Image

import image_processor


def test_blue_pen_extraction():
    print("=== Testing Blue Pen Ink Extraction ===")

    # 1. Create a synthetic blue pen signature photo with warm yellowish paper background
    h, w = 300, 600
    # Warm paper background (yellowish light tint: R=245, G=238, B=215)
    img_rgb = np.zeros((h, w, 3), dtype=np.uint8)
    img_rgb[:, :, 0] = 245  # R
    img_rgb[:, :, 1] = 238  # G
    img_rgb[:, :, 2] = 215  # B

    # Blue ballpoint ink (R=45, G=65, B=195)
    blue_ink = (45, 65, 195)
    pts = np.array([[60, 160], [100, 70], [140, 210], [190, 110], [250, 190], [310, 80], [390, 170], [530, 150]], np.int32)
    # OpenCV uses BGR order
    blue_bgr = (195, 65, 45)
    cv2.polylines(img_rgb, [pts], False, blue_ink, 4, cv2.LINE_AA)
    # Cursive loop
    cv2.ellipse(img_rgb, (100, 110), (30, 50), 25, 0, 360, blue_ink, 4, cv2.LINE_AA)
    # Underline
    pts_under = np.array([[40, 230], [270, 250], [560, 220]], np.int32)
    cv2.polylines(img_rgb, [pts_under], False, blue_ink, 4, cv2.LINE_AA)

    os.makedirs("scratch", exist_ok=True)
    blue_sig_path = "scratch/test_blue_pen_signature.png"
    Image.fromarray(img_rgb).save(blue_sig_path)
    print(f"Created blue pen signature photo: {blue_sig_path}")

    # 2. Extract paths with image_processor
    paths, orig_w, orig_h = image_processor.image_to_paths(
        image_path=blue_sig_path,
        target_width_mm=100.0,
        fill_mode="signature",
        smooth_iterations=2,
    )

    print(f"Extracted {len(paths)} stroke polylines from blue pen photo.")
    assert len(paths) in (1, 2), f"Expected 1 or 2 continuous strokes for blue pen, got {len(paths)}"

    total_pts = sum(len(p) for p in paths)
    print(f"Total curve points extracted from blue pen signature: {total_pts}")
    assert total_pts > 50, "Blue pen should extract high density curve coordinates"

    print("✓ Blue pen signature successfully extracted with maximum accuracy!")


if __name__ == "__main__":
    test_blue_pen_extraction()
