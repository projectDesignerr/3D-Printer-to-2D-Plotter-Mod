"""
test_tab_persistence.py — Verify that switching to the Settings tab does not clear
the loaded image/signature or reset the preview to default text.
"""

import os
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import numpy as np
from PIL import Image
import customtkinter as ctk

from gui import PlotterGUI


def test_settings_tab_preserves_image_preview():
    print("=== Testing Settings Tab Content Preservation ===")
    app = PlotterGUI()
    app.withdraw()  # Hide GUI window

    # 1. Create a dummy test image
    os.makedirs("scratch", exist_ok=True)
    test_img_path = os.path.abspath("scratch/test_tab_dummy.png")
    img = np.ones((100, 200), dtype=np.uint8) * 255
    img[40:60, 40:160] = 0  # black box
    Image.fromarray(img).save(test_img_path)

    # 2. Switch to Image tab and load image
    app.tabview.set("🖼️  Image")
    app._on_tab_change()
    assert app._last_active_tab == "🖼️  Image"
    app._load_image(test_img_path)

    # Generate live preview
    app._update_live_preview()
    assert app._last_builder is not None
    assert len(app.preview._draw_segments) > 0
    img_draw_count = len(app.preview._draw_segments)
    print(f"✓ Image loaded on Image Tab ({img_draw_count} draw segments)")

    # 3. Switch to Settings tab
    app.tabview.set("⚙️  Settings")
    app._on_tab_change()
    # Verify _last_active_tab remains "🖼️  Image"
    assert app._last_active_tab == "🖼️  Image", f"Expected '🖼️  Image', got {app._last_active_tab}"

    # Trigger live preview refresh while on Settings tab
    app._update_live_preview()
    assert app._last_builder is not None
    assert len(app.preview._draw_segments) == img_draw_count, (
        f"Expected {img_draw_count} draw segments from image, got {len(app.preview._draw_segments)}"
    )
    print("✓ Opening Settings Tab preserved the loaded image preview (did NOT reset to default text)!")

    # 4. Switch back to Image tab
    app.tabview.set("🖼️  Image")
    app._on_tab_change()
    assert app._last_active_tab == "🖼️  Image"
    app._update_live_preview()
    assert len(app.preview._draw_segments) == img_draw_count
    print("✓ Switching back to Image Tab shows the image seamlessly!")

    # 5. Switch to Text tab
    app.tabview.set("✏️  Text")
    app._on_tab_change()
    assert app._last_active_tab == "✏️  Text"
    app._update_live_preview()
    assert app._last_builder is not None
    print(f"✓ Text tab now generates text ({len(app.preview._draw_segments)} draw segments)")

    # 6. Switch to Settings tab from Text tab
    app.tabview.set("⚙️  Settings")
    app._on_tab_change()
    assert app._last_active_tab == "✏️  Text"
    app._update_live_preview()
    print("✓ Opening Settings Tab from Text tab preserves text preview!")

    app.destroy()
    print("\n🎉 ALL TAB PERSISTENCE TESTS PASSED!")


if __name__ == "__main__":
    test_settings_tab_preserves_image_preview()
