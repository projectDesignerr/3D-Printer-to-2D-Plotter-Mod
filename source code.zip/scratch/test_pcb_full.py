"""
Comprehensive test for EasyEDA PCB SVG, chemical etch-resist infill, board mapping, and GUI.
"""

import sys
import os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import svg_processor
from gcode_engine import PlotterConfig, generate_gcode_paths, save_gcode
import config_manager


def test_pcb_workflow():
    print("=== Testing PCB End-to-End Workflow ===")

    # 1. Verify config preservation
    cfg_data = config_manager.load_config()
    print(f"Loaded config: pen_touch_z={cfg_data.get('pen_touch_z')}, safe_lift_z={cfg_data.get('safe_lift_z')}, offset_y={cfg_data.get('offset_y')}")
    assert cfg_data.get("pen_touch_z") == 28.8, "pen_touch_z must be 28.8"
    assert cfg_data.get("safe_lift_z") == 40.0, "safe_lift_z must be 40.0"
    assert cfg_data.get("offset_y") == 49.5, "offset_y must be 49.5"

    # 2. Test SVG vector PCB processing
    svg_file = "scratch/test_pcb_board.svg"
    pcb_w = 70.0
    pcb_h = 50.0
    bed_x = 35.0
    bed_y = 45.0

    paths, meta = svg_processor.process_pcb_svg(
        svg_path=svg_file,
        pcb_board_w_mm=pcb_w,
        pcb_board_h_mm=pcb_h,
        pcb_board_bed_x=bed_x,
        pcb_board_bed_y=bed_y,
        mirror_x=True,
        marker_tip_mm=0.6,
        overlap_pct=40.0,
        infill_mode="solid",
    )

    print(f"Total PCB toolpaths extracted: {len(paths)}")
    assert len(paths) >= 20, "Must generate outline and infill toolpaths"

    # 3. Generate G-code with Kobra 2 Neo config
    config = PlotterConfig(
        bed_x=220.0,
        bed_y=220.0,
        offset_y=49.5,
        pen_touch_z=28.8,
        safe_lift_z=40.0,
        z_hop=3.0,
        output_file="scratch/test_pcb_output.gcode",
    )

    builder = generate_gcode_paths(config, paths)
    save_gcode(config, builder)
    print(f"Generated PCB G-code: {len(builder.lines)} lines")

    with open("scratch/test_pcb_output.gcode", "r", encoding="utf-8") as f:
        gcode_content = f.read()

    assert "Z28.8" in gcode_content, "G-code must use pen_touch_z=28.8"
    assert "Z40.0" in gcode_content, "G-code must use safe_lift_z=40.0"
    print("✓ G-code correctly uses configured Z heights!")

    # 4. Test GUI initialization in headless/offscreen
    from gui import PlotterGUI
    import tkinter as tk
    app = PlotterGUI()
    app.update()

    # Switch to PCB tab
    app.tabview.set("⚡ PCB")
    app._on_tab_change()
    app._current_pcb_path = svg_file
    app._update_live_preview()
    app.update()

    assert app.preview._pcb_enabled, "PCB overlay must be enabled when on PCB tab"
    print("✓ GUI PCB Tab, Copper Board Overlay, and Live Preview verified successfully!")

    app.destroy()
    print("=== All PCB Tests Passed Successfully! ===")


if __name__ == "__main__":
    test_pcb_workflow()
