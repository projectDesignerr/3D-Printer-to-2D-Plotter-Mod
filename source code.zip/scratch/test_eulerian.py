import sys
import math
import collections
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import cv2

def trace_skeleton_eulerian(skeleton: np.ndarray) -> list:
    """
    Extract 1-stroke continuous Eulerian paths from a 1-pixel skeleton image.
    Every connected component of the skeleton is traversed as a single continuous polyline
    using the Chinese Postman / Eulerian trail algorithm (single-stroke puzzle logic).
    """
    h, w = skeleton.shape
    skel = skeleton > 0
    ys, xs = np.where(skel)
    if len(ys) == 0:
        return []

    # 1. Build pixel graph adjacency
    pixel_neighbors = collections.defaultdict(set)
    for y, x in zip(ys, xs):
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and skel[ny, nx]:
                    pixel_neighbors[(x, y)].add((nx, ny))

    # 2. Find connected components of pixels
    visited_pixels = set()
    components = []
    for p in pixel_neighbors:
        if p not in visited_pixels:
            comp = []
            queue = collections.deque([p])
            visited_pixels.add(p)
            while queue:
                curr = queue.popleft()
                comp.append(curr)
                for nbr in pixel_neighbors[curr]:
                    if nbr not in visited_pixels:
                        visited_pixels.add(nbr)
                        queue.append(nbr)
            components.append(comp)

    all_continuous_paths = []

    for comp in components:
        comp_set = set(comp)
        if len(comp) == 1:
            pt = comp[0]
            all_continuous_paths.append([pt, (pt[0] + 0.1, pt[1] + 0.1)])
            continue

        # Classify nodes in this component
        # Endpoints: degree 1
        # Junctions: degree >= 3
        # Curve points: degree 2
        junctions = set()
        endpoints = set()
        for p in comp:
            deg = len(pixel_neighbors[p] & comp_set)
            if deg == 1:
                endpoints.append(p) if hasattr(endpoints, 'append') else endpoints.add(p)
            elif deg >= 3:
                junctions.add(p)

        # Merge adjacent junction pixels into single junction cluster representatives
        junction_clusters = {}
        cluster_rep = {}
        cluster_id = 0
        visited_j = set()
        for j in junctions:
            if j not in visited_j:
                c_members = [j]
                q = [j]
                visited_j.add(j)
                while q:
                    curr = q.pop()
                    for nbr in pixel_neighbors[curr]:
                        if nbr in junctions and nbr not in visited_j:
                            visited_j.add(nbr)
                            q.append(nbr)
                            c_members.append(nbr)
                rep = (
                    int(round(sum(p[0] for p in c_members) / len(c_members))),
                    int(round(sum(p[1] for p in c_members) / len(c_members))),
                )
                for m in c_members:
                    cluster_rep[m] = rep
                junction_clusters[cluster_id] = (rep, c_members)
                cluster_id += 1

        # Key vertices are endpoints and cluster representatives
        key_vertices = set(endpoints) | {rep for rep, _ in junction_clusters.values()}

        # If it's a pure loop without endpoints or junctions, pick the leftmost-topmost pixel as a key vertex
        if not key_vertices:
            sorted_comp = sorted(comp, key=lambda p: (p[0], p[1]))
            key_vertices.add(sorted_comp[0])

        # Extract topological edges between key vertices
        # Each edge is (u, v, path_pts, length)
        # We trace paths starting from each key vertex along each of its outgoing branches
        edges = []
        edge_id = 0
        visited_edge_pixel_pairs = set()

        for u_pix in comp:
            u_key = cluster_rep.get(u_pix, u_pix) if u_pix in junctions else (u_pix if u_pix in key_vertices else None)
            if u_key is None:
                continue

            for next_pix in pixel_neighbors[u_pix]:
                # If next_pix is in the same junction cluster as u_pix, skip internal cluster edge
                if u_pix in junctions and next_pix in junctions and cluster_rep.get(u_pix) == cluster_rep.get(next_pix):
                    continue

                pair_key = tuple(sorted([(u_pix), (next_pix)]))
                if pair_key in visited_edge_pixel_pairs:
                    continue

                # Trace stroke until we hit another key vertex or dead end
                path_pts = [u_key, next_pix]
                visited_edge_pixel_pairs.add(pair_key)
                prev_p = u_pix
                curr_p = next_pix

                while True:
                    # Check if curr_p is a key vertex or in a junction
                    if curr_p in junctions:
                        v_key = cluster_rep[curr_p]
                        if v_key != path_pts[-1]:
                            path_pts.append(v_key)
                        break
                    elif curr_p in endpoints or curr_p in key_vertices:
                        v_key = curr_p
                        break

                    # Move to next degree-2 neighbor
                    nbrs = [n for n in pixel_neighbors[curr_p] if n != prev_p and n in comp_set]
                    if not nbrs:
                        v_key = curr_p
                        break

                    next_p = nbrs[0]
                    visited_edge_pixel_pairs.add(tuple(sorted([curr_p, next_p])))
                    path_pts.append(next_p)
                    prev_p = curr_p
                    curr_p = next_p

                # Calculate length
                length = sum(math.hypot(path_pts[i+1][0] - path_pts[i][0], path_pts[i+1][1] - path_pts[i][1]) for i in range(len(path_pts)-1))
                if length > 0 or u_key != v_key:
                    edges.append({
                        "id": edge_id,
                        "u": u_key,
                        "v": v_key,
                        "pts": path_pts,
                        "len": max(0.1, length)
                    })
                    edge_id += 1

        if not edges:
            continue

        # 3. Build multigraph for Eulerian path
        adj = collections.defaultdict(list)
        for e in edges:
            adj[e["u"]].append(e)
            adj[e["v"]].append(e)

        # 4. Chinese Postman: Match odd degree vertices to make Eulerian
        odd_vertices = [v for v in adj if len(adj[v]) % 2 != 0]

        if len(odd_vertices) > 2:
            # Pair odd vertices using shortest path
            # Simple BFS/Dijkstra distance between all odd vertices
            def shortest_path(start, target):
                dist = {start: 0}
                prev = {}
                q = [(0, start)]
                import heapq
                while q:
                    d, u = heapq.heappop(q)
                    if u == target:
                        break
                    if d > dist.get(u, float('inf')):
                        continue
                    for edge in adj[u]:
                        nbr = edge["v"] if edge["u"] == u else edge["u"]
                        new_d = d + edge["len"]
                        if new_d < dist.get(nbr, float('inf')):
                            dist[nbr] = new_d
                            prev[nbr] = (u, edge)
                            heapq.heappush(q, (new_d, nbr))
                if target not in prev:
                    return float('inf'), []
                path_edges = []
                curr = target
                while curr != start:
                    p_node, p_edge = prev[curr]
                    path_edges.append(p_edge)
                    curr = p_node
                return dist[target], path_edges

            # Greedy or optimal pairing of odd vertices (leave 2 odd vertices unpaired for start/end)
            # Find pairwise distances
            pairs = []
            for i in range(len(odd_vertices)):
                for j in range(i + 1, len(odd_vertices)):
                    v1, v2 = odd_vertices[i], odd_vertices[j]
                    d, p_edges = shortest_path(v1, v2)
                    pairs.append((d, v1, v2, p_edges))

            pairs.sort(key=lambda x: x[0])

            # Greedily match pairs until at most 2 odd vertices remain
            matched_nodes = set()
            for d, v1, v2, p_edges in pairs:
                if len(odd_vertices) - len(matched_nodes) <= 2:
                    break
                if v1 not in matched_nodes and v2 not in matched_nodes:
                    matched_nodes.add(v1)
                    matched_nodes.add(v2)
                    # Duplicate path edges to turn both odd vertices into even
                    for pe in p_edges:
                        dup_e = {
                            "id": edge_id,
                            "u": pe["u"],
                            "v": pe["v"],
                            "pts": list(pe["pts"]),
                            "len": pe["len"]
                        }
                        edge_id += 1
                        edges.append(dup_e)
                        adj[dup_e["u"]].append(dup_e)
                        adj[dup_e["v"]].append(dup_e)

        # 5. Hierholzer's Algorithm on Eulerian Multigraph
        # Re-check odd vertices
        final_odds = [v for v in adj if len(adj[v]) % 2 != 0]
        # Choose start vertex: prefer odd vertex with smallest X (leftmost start like natural handwriting)
        if final_odds:
            start_v = min(final_odds, key=lambda p: (p[0], p[1]))
        else:
            start_v = min(adj.keys(), key=lambda p: (p[0], p[1]))

        # Hierholzer's algorithm with edge objects
        current_adj = {v: list(e_list) for v, e_list in adj.items()}
        stack = [start_v]
        circuit = []

        while stack:
            u = stack[-1]
            if current_adj[u]:
                edge = current_adj[u].pop()
                v = edge["v"] if edge["u"] == u else edge["u"]
                # Remove edge from v's adj list as well
                if edge in current_adj[v]:
                    current_adj[v].remove(edge)
                stack.append(v)
            else:
                circuit.append(stack.pop())

        circuit.reverse()

        # Unpack circuit into ordered coordinates
        continuous_poly = []
        for i in range(len(circuit) - 1):
            u = circuit[i]
            v = circuit[i + 1]
            # Find the edge matching (u, v)
            found_edge = None
            for e in edges:
                if (e["u"] == u and e["v"] == v) or (e["u"] == v and e["v"] == u):
                    found_edge = e
                    edges.remove(e)
                    break

            if found_edge:
                pts = found_edge["pts"]
                if found_edge["u"] == u:
                    seg_pts = pts
                else:
                    seg_pts = list(reversed(pts))

                if not continuous_poly:
                    continuous_poly.extend(seg_pts)
                else:
                    continuous_poly.extend(seg_pts[1:])

        if len(continuous_poly) >= 2:
            all_continuous_paths.append(continuous_poly)

    return all_continuous_paths

if __name__ == "__main__":
    # Test on synthetic signature with loop and crossing
    img = np.ones((200, 400), dtype=np.uint8) * 255
    pts = np.array([[50, 150], [100, 50], [180, 40], [250, 120], [300, 60], [350, 160]], np.int32)
    cv2.polylines(img, [pts], False, 0, 4)
    cv2.putText(img, "John", (60, 170), cv2.FONT_HERSHEY_SCRIPT_SIMPLEX, 1.2, 0, 2)

    import image_processor
    gray = img
    binary = cv2.threshold(gray, 128, 255, cv2.THRESH_BINARY_INV)[1]
    skel = image_processor.skeletonize(binary)

    old_paths = image_processor._trace_skeleton_paths(skel)
    new_paths = trace_skeleton_eulerian(skel)

    print(f"Old greedy tracer produced: {len(old_paths)} separate fragmented paths (causes {len(old_paths)} pen lift/touchdown dots).")
    print(f"Eulerian 1-stroke tracer produced: {len(new_paths)} continuous stroke(s)!")
