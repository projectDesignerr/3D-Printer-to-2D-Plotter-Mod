"""
Test script to verify Vector-Space Rotation with ZERO noise artifacts.
"""

import sys
import math
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import numpy as np
import cv2
from PIL import Image

import image_processor


def test_vector_rotation():
    print("=== Testing Vector-Space Rotation Accuracy ===")

    # 1. Create a clean signature image
    h, w = 300, 600
    img = np.full((h, w), 255, dtype=np.uint8)
    pts = np.array([[60, 160], [100, 70], [140, 210], [190, 110], [250, 190], [310, 80], [390, 170], [530, 150]], np.int32)
    cv2.polylines(img, [pts], False, 0, 5, cv2.LINE_AA)
    cv2.ellipse(img, (100, 110), (30, 50), 25, 0, 360, 0, 5, cv2.LINE_AA)

    test_img_path = "scratch/test_rot_accuracy.png"
    Image.fromarray(img).save(test_img_path)

    # 2. Extract at 0 degrees
    paths_0, _, _ = image_processor.image_to_paths(
        image_path=test_img_path,
        target_width_mm=100.0,
        fill_mode="signature",
        rotation_deg=0.0,
    )
    count_0 = len(paths_0)
    print(f"Paths at 0°: {count_0}")

    # 3. Extract at 35.5 degrees rotation
    paths_35, _, _ = image_processor.image_to_paths(
        image_path=test_img_path,
        target_width_mm=100.0,
        fill_mode="signature",
        rotation_deg=35.5,
    )
    count_35 = len(paths_35)
    print(f"Paths at 35.5°: {count_35}")

    # The stroke count must NOT explode when rotated!
    assert count_35 == count_0, f"Rotation should preserve exact stroke topology (expected {count_0} paths, got {count_35})"
    print("✓ Vector rotation perfectly preserves stroke topology with ZERO noise!")


if __name__ == "__main__":
    test_vector_rotation()
