"""
Test script for Notebook Page Mode — overlay geometry, text positioning on ruled lines.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import tkinter as tk
from preview import PreviewCanvas
from gui import PlotterGUI


def test_notebook_geometry():
    print("=== Testing Notebook Page Geometry ===")
    root = tk.Tk()
    canvas = PreviewCanvas(root)
    canvas.set_bed_size(220, 220)

    # Verify disabled state
    assert canvas.get_notebook_geometry() is None
    print("✓ Notebook overlay disabled by default")

    # Enable with centered mode
    canvas.set_notebook_overlay(True, {
        "align_mode": "centered",
        "line_spacing": 8.0,
        "left_margin": 30.0,
        "writable_w": 175.0,
        "writable_h": 250.0,
        "page_x": -1,
        "page_y": -1,
    })

    geo = canvas.get_notebook_geometry()
    assert geo is not None
    assert abs(geo["page_x"] - 5.0) < 0.01, f"page_x should be 5.0, got {geo['page_x']}"
    assert abs(geo["margin_x"] - 52.5) < 0.01

    # Enable with left_margin_at_zero mode (Red margin touching X=0 bed edge)
    canvas.set_notebook_overlay(True, {
        "align_mode": "left_margin_at_zero",
        "margin_bed_x": 0.0,
        "line_spacing": 8.0,
        "left_margin": 30.0,
        "writable_w": 175.0,
        "writable_h": 250.0,
    })

    geo_zero = canvas.get_notebook_geometry()
    assert geo_zero is not None
    assert abs(geo_zero["margin_x"] - 0.0) < 0.01, f"margin_x should be 0.0, got {geo_zero['margin_x']}"
    assert abs(geo_zero["wr_x"] - (-30.0)) < 0.01
    print("✓ Left margin touching X=0 geometry verified!")

    print(f"✓ Page geometry correct: {geo['num_lines']} lines, margin at {geo['margin_x']:.1f}mm")
    print(f"  Writable area: ({geo['wr_x']:.1f}, {geo['wr_y_bottom']:.1f}) → ({geo['wr_x'] + geo['writable_w']:.1f}, {geo['wr_y_top']:.1f}) mm")

    root.destroy()


def test_notebook_gui_integration():
    print("\n=== Testing Notebook GUI Integration ===")
    app = PlotterGUI()
    app.update()

    # Reset to defaults first to ensure clean state
    app._on_reset_settings()
    app.update()

    # Verify notebook is disabled by default after reset
    assert not app.notebook_enabled_var.get()
    print("✓ Notebook mode disabled by default")

    # Enable notebook mode
    app.notebook_enabled_var.set(True)
    app._on_notebook_toggle()
    app.update()

    # Verify overlay is synced to preview
    assert app.preview._notebook_enabled
    print("✓ Preview overlay synced when enabled")

    # Verify notebook entries exist and have correct defaults
    assert "line_spacing" in app._notebook_entries
    assert abs(float(app._notebook_entries["line_spacing"].get()) - 8.0) < 0.01
    assert abs(float(app._notebook_entries["left_margin"].get()) - 30.0) < 0.01
    assert abs(float(app._notebook_entries["writable_w"].get()) - 175.0) < 0.01
    assert abs(float(app._notebook_entries["writable_h"].get()) - 250.0) < 0.01
    print("✓ Notebook entries have correct defaults")

    # Set text and generate with notebook mode
    app.text_input.delete("1.0", "end")
    app.text_input.insert("1.0", "Hello World\nThis is a test")
    app.update()
    app._update_live_preview()
    app.update()

    # Verify text was generated (builder exists)
    assert app._last_builder is not None
    assert len(app._last_builder.draw_segments) > 0
    print("✓ Text generated on notebook ruled lines!")

    # Verify text starts near margin_x + 3mm
    geo = app.preview.get_notebook_geometry()
    min_draw_x = min(seg[0] for seg in app._last_builder.draw_segments)
    expected_start_x = geo["margin_x"] + 3.0
    assert abs(min_draw_x - expected_start_x) < 5.0, \
        f"Text should start near {expected_start_x:.1f}mm, got {min_draw_x:.1f}mm"
    print(f"✓ Text starts at X≈{min_draw_x:.1f}mm (margin at {geo['margin_x']:.1f}mm)")

    # Verify notebook settings are saved to JSON
    cfg_dict = app._get_current_settings_dict()
    assert cfg_dict["notebook_enabled"] == True
    assert abs(cfg_dict["notebook_line_spacing"] - 8.0) < 0.01
    assert abs(cfg_dict["notebook_left_margin"] - 30.0) < 0.01
    print("✓ Notebook settings included in JSON save dict")

    # Disable and reset to clean defaults
    app.notebook_enabled_var.set(False)
    app._on_notebook_toggle()
    app._on_reset_settings()
    app.update()
    assert not app.preview._notebook_enabled
    print("✓ Notebook overlay disabled and reset correctly")

    app.destroy()


if __name__ == "__main__":
    test_notebook_geometry()
    test_notebook_gui_integration()
    print("\n🎉 ALL NOTEBOOK PAGE MODE TESTS PASSED!")
