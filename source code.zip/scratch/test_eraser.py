"""
Test script for Manual Right-Click Eraser Tool on Canvas.
"""

import sys
import math
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import customtkinter as ctk
from preview import PreviewCanvas
from gcode_engine import PlotterConfig, generate_gcode_text, generate_gcode_paths


def test_eraser_functionality():
    print("=== Testing Manual Right-Click Eraser ===")
    app = ctk.CTk()
    app.withdraw()

    canvas = PreviewCanvas(app, width=600, height=600)
    canvas.set_bed_size(220.0, 220.0)

    # 1. Create a dummy drawing with 3 separate segments (e.g. 2 lines + 1 stray dot)
    paths = [
        [(20.0, 20.0), (80.0, 20.0)],          # Line 1
        [(50.0, 50.0), (50.0, 100.0)],         # Line 2
        [(150.0, 150.0), (150.5, 150.5)],      # Stray dot at (150, 150)
    ]
    cfg = PlotterConfig(bed_x=220.0, bed_y=220.0)
    builder = generate_gcode_paths(cfg, paths)
    canvas.load_from_builder(builder)

    initial_count = len(canvas._draw_segments)
    print(f"Initial draw segments count: {initial_count}")
    assert initial_count >= 3

    # 2. Erase the stray dot at (150, 150) by simulating right-click
    screen_x, screen_y = canvas._world_to_screen(150.0, 150.0)
    canvas._erase_at(screen_x, screen_y)
    canvas._on_right_release(None)

    after_erase_count = len(canvas._draw_segments)
    print(f"Segments after erasing stray dot: {after_erase_count}")
    assert after_erase_count < initial_count, "Stray dot should be erased!"
    assert canvas.has_erased_segments() is True

    # 3. Test Undo Erase
    canvas.undo_erase()
    restored_count = len(canvas._draw_segments)
    print(f"Segments after Undo: {restored_count}")
    assert restored_count == initial_count, "Undo should restore the erased segments!"

    # 4. Erase Line 1 by right-click dragging across (50, 20)
    canvas._is_erasing = True
    canvas._current_erase_batch = []
    sx1, sy1 = canvas._world_to_screen(50.0, 20.0)
    canvas._erase_at(sx1, sy1)
    canvas._on_right_release(None)
    
    assert len(canvas._draw_segments) < initial_count
    print("✓ Eraser accurately removed selected line segment!")

    app.destroy()
    print("✓ All Right-Click Eraser Tests PASSED!")


if __name__ == "__main__":
    test_eraser_functionality()
