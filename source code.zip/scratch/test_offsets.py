"""
Test script for verifying Settings Page, Config Manager, and Toolhead Offsets (X, Y, Z).
"""

import os
import sys
import tempfile
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import config_manager
from gcode_engine import PlotterConfig, GCodeBuilder, generate_gcode_text, save_gcode


def test_config_manager():
    print("=== Testing config_manager ===")
    defaults = config_manager.get_default_config()
    assert "offset_x" in defaults
    assert "offset_y" in defaults
    assert "offset_z" in defaults
    assert defaults["offset_x"] == 0.0
    assert defaults["offset_y"] == 49.5
    assert defaults["offset_z"] == 0.0
    assert defaults["pen_touch_z"] == 9.4

    # Test saving & loading with custom config file
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tf:
        temp_path = tf.name

    try:
        custom_cfg = dict(defaults)
        custom_cfg["offset_x"] = 5.0
        custom_cfg["offset_y"] = -35.0
        custom_cfg["offset_z"] = 1.2
        custom_cfg["bed_x"] = 235.0
        custom_cfg["bed_y"] = 235.0

        ok = config_manager.save_config(custom_cfg, temp_path)
        assert ok, "save_config returned False"

        loaded = config_manager.load_config(temp_path)
        assert loaded["offset_x"] == 5.0
        assert loaded["offset_y"] == -35.0
        assert loaded["offset_z"] == 1.2
        assert loaded["bed_x"] == 235.0
        assert loaded["bed_y"] == 235.0
        print("✓ config_manager save & load passed!")
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_gcode_engine_offsets():
    print("\n=== Testing gcode_engine with Toolhead Offsets ===")
    cfg = PlotterConfig(
        text="A",
        start_x=50.0,
        start_y=60.0,
        scale=10.0,
        pen_touch_z=15.0,
        z_hop=2.0,
        safe_lift_z=30.0,
        offset_x=10.0,
        offset_y=-35.0,
        offset_z=1.5,
        center_text=False,
        home_all=True,
    )

    # Test properties
    assert cfg.effective_touch_z == 15.0 + 1.5 == 16.5
    assert cfg.effective_pen_up_z == 15.0 + 1.5 + 2.0 == 18.5

    builder = generate_gcode_text(cfg)
    gcode_text = "\n".join(builder.lines)

    # Header checks
    assert "; Pen Toolhead Offset: X=+10.00 mm, Y=-35.00 mm, Z=+1.50 mm" in gcode_text
    assert "Z16.500" in gcode_text  # touch plane with offset

    # Move checks: Since start_x=50, offset_x=10 -> machine X should be 60.000
    # start_y=60, offset_y=-35 -> machine Y should be 25.000
    assert any("X60.000 Y25.000" in line for line in builder.lines), "Expected move with offset (60.000, 25.000)"

    # Machine bounds check
    m_bounds = builder.get_machine_bounds()
    assert m_bounds is not None
    min_mx, min_my, max_mx, max_my = m_bounds
    print(f"✓ Total Machine carriage travel bounds: X=[{min_mx:.2f}, {max_mx:.2f}], Y=[{min_my:.2f}, {max_my:.2f}]")
    assert min_mx == 10.0  # (0 + offset_x)
    assert min_my == -35.0 # (0 + offset_y)

    # Drawn segments bounds
    draw_x = [x + cfg.offset_x for seg in builder.draw_segments for x in (seg[0], seg[2])]
    draw_y = [y + cfg.offset_y for seg in builder.draw_segments for y in (seg[1], seg[3])]
    assert min(draw_x) >= 60.0 - 0.1
    assert min(draw_y) >= 25.0 - 0.1
    print(f"✓ Drawn artwork machine bounds: X=[{min(draw_x):.2f}, {max(draw_x):.2f}], Y=[{min(draw_y):.2f}, {max(draw_y):.2f}]")

    print("✓ gcode_engine offset transformations passed!")


def test_cli_execution():
    print("\n=== Testing main.py CLI with offsets ===")
    import subprocess
    cmd = [
        sys.executable,
        "main.py",
        "--cli",
        "--text", "Test",
        "-o", "scratch/test_cli_output.gcode",
        "--offset-x", "12.5",
        "--offset-y", "-30.0",
        "--offset-z", "0.5",
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    print("CLI Output:", res.stdout)
    assert res.returncode == 0, f"CLI returned error: {res.stderr}"
    assert "Toolhead Pen Offset: X=+12.50mm, Y=-30.00mm, Z=+0.50mm" in res.stdout

    output_file = Path("scratch/test_cli_output.gcode")
    assert output_file.exists()
    content = output_file.read_text()
    assert "; Pen Toolhead Offset: X=+12.50 mm, Y=-30.00 mm, Z=+0.50 mm" in content
    print("✓ CLI execution with offsets passed!")


if __name__ == "__main__":
    os.makedirs("scratch", exist_ok=True)
    test_config_manager()
    test_gcode_engine_offsets()
    test_cli_execution()
    print("\n🎉 ALL TESTS PASSED SUCCESSFULLY!")
