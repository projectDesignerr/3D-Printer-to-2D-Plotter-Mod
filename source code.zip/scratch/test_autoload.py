"""
test_autoload.py — Verify settings auto-save and auto-load round-trip.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import config_manager
from gui import PlotterGUI


def test_autoload():
    print("=== Testing Settings Auto-Load Round-Trip ===")

    # Launch GUI, change some settings, save, destroy
    app = PlotterGUI()
    app.update()

    app.text_x_slider.set(77.5)
    app.text_y_slider.set(155.3)
    app.center_var.set(False)
    app.text_scale_slider.set(12.0)

    app._save_current_settings_silently()
    app.destroy()

    # Verify values persisted to JSON
    cfg = config_manager.load_config()
    assert abs(cfg.get("text_start_x", 0) - 77.5) < 1.0
    assert abs(cfg.get("text_start_y", 0) - 155.3) < 1.0
    assert cfg.get("center_on_bed") == False
    assert abs(cfg.get("default_scale", 0) - 12.0) < 0.5
    assert cfg.get("font_mode") == "vector"
    assert cfg.get("hershey_font") == "futural"
    print("✓ Settings persisted to plotter_config.json")

    # Relaunch GUI and verify auto-restored
    app2 = PlotterGUI()
    app2.update()

    x = app2.text_x_slider.get()
    y = app2.text_y_slider.get()
    c = app2.center_var.get()
    s = app2.text_scale_slider.get()
    fm = app2._font_mode_var.get()

    assert abs(x - 77.5) < 1.0, f"text_x should be ~77.5, got {x}"
    assert abs(y - 155.3) < 1.0, f"text_y should be ~155.3, got {y}"
    assert c == False, f"center_on_bed should be False, got {c}"
    assert abs(s - 12.0) < 0.5, f"scale should be ~12.0, got {s}"
    assert fm == "vector", f"font_mode should be vector, got {fm}"
    print(f"✓ Auto-restored: X={x:.1f}, Y={y:.1f}, center={c}, scale={s:.1f}, font_mode={fm}")

    # Reset to defaults for cleanliness
    app2._on_reset_settings()
    app2._save_current_settings_silently()
    app2.destroy()

    print("✓ Reset to defaults after test")
    print("\n🎉 SETTINGS AUTO-LOAD ROUND-TRIP TEST PASSED!")


if __name__ == "__main__":
    test_autoload()
