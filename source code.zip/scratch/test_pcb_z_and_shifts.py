"""
Test script for verifying PCB Board Thickness (Z elevation) and Trace X/Y Shifting.
"""

import sys
import os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import svg_processor
import config_manager
from gui import PlotterGUI


def test_pcb_z_and_shifts():
    print("=== Testing PCB Board Z Elevation & Trace X/Y Shifting ===")
    svg_file = "scratch/test_pcb_board.svg"

    app = PlotterGUI()
    app.update()

    app.tabview.set("⚡ PCB")
    app._on_tab_change()
    app._current_pcb_path = svg_file

    # Set board thickness = 1.6 mm (standard FR4)
    app.pcb_thickness_entry.delete(0, "end")
    app.pcb_thickness_entry.insert(0, "1.6")
    app._on_pcb_param_change()
    app.update()

    base_cfg = app._get_config()
    assert base_cfg.pen_touch_z == 28.8, f"Base config must remain 28.8, got {base_cfg.pen_touch_z}"

    # Generate PCB G-code builder
    builder = app._generate_pcb(base_cfg)
    assert builder is not None, "G-code builder should be generated"

    lines = builder.lines

    # Verify that drawing moves use elevated Z (28.8 + 1.6 = 30.4 mm)
    z_moves = [line for line in lines if "Z30.4" in line or "Z30.400" in line]
    assert len(z_moves) > 0, "G-code must use elevated Z30.4 for drawing moves on top of copper board!"
    print(f"✓ Found {len(z_moves)} drawing moves using elevated Z30.4 mm on top of FR4 board")

    # Test shifting traces along X and Y inside the board
    app.pcb_trace_x_slider.set(10.0)
    app.pcb_trace_y_slider.set(-5.0)
    app._on_pcb_trace_x_change(10.0)
    app._on_pcb_trace_y_change(-5.0)
    app.update()

    builder_shifted = app._generate_pcb(base_cfg)
    assert builder_shifted is not None
    print("✓ Shifted G-code generated successfully with X=+10mm, Y=-5mm trace offset!")

    # Test Re-centering traces
    app._center_pcb_traces()
    app.update()
    assert app.pcb_trace_x_slider.get() == 0.0
    assert app.pcb_trace_y_slider.get() == 0.0
    print("✓ Re-centering traces reset sliders to 0.0 mm successfully!")

    app.destroy()
    print("🎉 PCB Z-Elevation & Trace Shifting Tests PASSED!")


if __name__ == "__main__":
    test_pcb_z_and_shifts()
