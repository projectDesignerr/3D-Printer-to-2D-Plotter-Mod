"""
test_signature.py — Verify Signature Single-Stroke Centerline Mode, Curve Flow Smoothing, and Rotation.
"""

import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import cv2
import numpy as np
import tempfile
import image_processor
from gui import PlotterGUI
from gcode_engine import PlotterConfig


def test_signature_processing():
    print("=== Testing Signature Single-Stroke Processing ===")

    # 1. Create a synthetic signature image with loops, thick strokes, and text
    img = np.full((300, 600), 255, dtype=np.uint8)  # white paper
    
    # Draw thick cursive ink strokes (width 8px)
    pts = np.array([[50, 150], [90, 50], [130, 200], [180, 120], [240, 180], [300, 60], [380, 160], [520, 140]], np.int32)
    cv2.polylines(img, [pts], False, 0, 8, cv2.LINE_AA)
    
    # Add a signature loop
    cv2.ellipse(img, (90, 100), (35, 60), 20, 0, 360, 0, 7, cv2.LINE_AA)
    
    # Add a flourish underline
    pts_under = np.array([[30, 220], [250, 240], [550, 210]], np.int32)
    cv2.polylines(img, [pts_under], False, 0, 6, cv2.LINE_AA)

    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
        tmp_path = tmp.name
        cv2.imwrite(tmp_path, img)

    # 2. Test standard contour mode (which creates double boundary outlines)
    contour_paths, _, _ = image_processor.image_to_paths(
        image_path=tmp_path,
        target_width_mm=100.0,
        fill_mode="contour",
    )
    print(f"Contour mode produced {len(contour_paths)} outline polylines (double boundaries).")

    # 3. Test Signature mode (single-stroke centerline skeletonization with Chaikin smoothing)
    sig_paths, _, _ = image_processor.image_to_paths(
        image_path=tmp_path,
        target_width_mm=100.0,
        fill_mode="signature",
        smooth_iterations=2,
    )
    print(f"Signature mode produced {len(sig_paths)} single-stroke centerline polylines.")

    assert len(sig_paths) > 0, "Signature mode should extract polylines"
    
    def total_length(paths):
        return sum(
            np.hypot(np.diff([p[0] for p in poly]), np.diff([p[1] for p in poly])).sum()
            for poly in paths if len(poly) >= 2
        )

    len_contour = total_length(contour_paths)
    len_sig = total_length(sig_paths)
    print(f"Contour total length: {len_contour:.1f} mm (double border)")
    print(f"Signature total length: {len_sig:.1f} mm (single centerline stroke)")

    assert len_sig < len_contour * 0.75, "Signature single stroke must be significantly shorter than double boundary"
    print("✓ Single-stroke centerline verified!")

    # 4. Test Rotation
    rot_paths, _, _ = image_processor.image_to_paths(
        image_path=tmp_path,
        target_width_mm=100.0,
        fill_mode="signature",
        rotation_deg=45.0,
    )
    assert len(rot_paths) > 0, "Rotated signature paths should be generated"
    print("✓ Signature rotation (45°) verified!")


def test_gui_signature_mode():
    print("\n=== Testing GUI Signature Mode & Rotation Controls ===")
    app = PlotterGUI()
    app.update()

    assert hasattr(app, "signature_mode_var"), "GUI missing signature_mode_var"
    assert hasattr(app, "signature_switch"), "GUI missing signature_switch"
    assert hasattr(app, "img_rot_slider"), "GUI missing img_rot_slider"
    assert hasattr(app, "img_smooth_slider"), "GUI missing img_smooth_slider"

    # Toggle signature mode
    app.signature_mode_var.set(True)
    app._on_signature_mode_toggle()
    app.update()
    assert "signature" in app.fill_mode_var.get()
    print("✓ Signature mode switch cleanly activates single-stroke fill mode")

    # Set rotation to 30 degrees
    app._set_img_rotation(30.0)
    app.update()
    assert abs(app.img_rot_slider.get() - 30.0) < 0.1
    print("✓ Rotation control works: set to +30.0°")

    # Set smoothness to 3
    app.img_smooth_slider.set(3)
    app._on_img_smooth_change(3)
    app.update()
    assert "High" in app.img_smooth_label.cget("text")
    print("✓ Stroke flow smoothness control works: set to 3 (High)")

    app.destroy()
    print("✓ GUI Signature integration passed!")


if __name__ == "__main__":
    test_signature_processing()
    test_gui_signature_mode()
    print("\n🎉 ALL SIGNATURE MODE & ROTATION TESTS PASSED!")
