"""
Test script to verify zoom persistence during mouse wheel zoom, pan, and timer events.
"""

import sys
import os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from gui import PlotterGUI
import tkinter as tk


def test_zoom_persistence():
    print("=== Testing Zoom Persistence ===")
    app = PlotterGUI()
    app.update()

    # Initial auto-fit zoom
    initial_zoom = app.preview._zoom
    print(f"Initial auto-fit zoom: {initial_zoom:.4f}")

    # Simulate mouse wheel zoom (zoom in 3x)
    class FakeEvent:
        def __init__(self, x, y, delta=120):
            self.x = x
            self.y = y
            self.delta = delta
            self.width = 800
            self.height = 600

    fake_scroll = FakeEvent(400, 300, 120)
    app.preview._on_scroll(fake_scroll)
    app.preview._on_scroll(fake_scroll)
    app.preview._on_scroll(fake_scroll)

    zoomed_in = app.preview._zoom
    print(f"Zoom after scrolling: {zoomed_in:.4f}")
    assert zoomed_in > initial_zoom * 1.3, "Zoom should have increased"
    assert app.preview._user_zoomed is True, "_user_zoomed flag should be True"

    # Simulate window configure / resize / timer layout event (which previously unzoomed)
    fake_resize = FakeEvent(800, 600)
    app.preview._on_resize(fake_resize)

    # Simulate live preview update / timer refresh
    app._update_live_preview()
    app.update()

    current_zoom = app.preview._zoom
    print(f"Zoom after layout/timer event: {current_zoom:.4f}")
    assert abs(current_zoom - zoomed_in) < 1e-4, "Zoom MUST remain preserved and not reset!"

    # Simulate double click to reset
    app.preview._on_double_click_reset(fake_scroll)
    reset_zoom = app.preview._zoom
    print(f"Zoom after double-click reset: {reset_zoom:.4f}")
    assert abs(reset_zoom - initial_zoom) < 1e-3, "Double click should reset to auto-fit"

    app.destroy()
    print("✓ Zoom persistence test PASSED successfully!")


if __name__ == "__main__":
    test_zoom_persistence()
