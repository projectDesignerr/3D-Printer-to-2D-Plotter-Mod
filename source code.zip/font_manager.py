"""
font_manager.py — System font discovery and text-to-polyline rendering.

Uses Pillow to render text with any installed TTF/OTF font, then converts
the rendered bitmap to vector paths via the image_processor contour pipeline.
"""

import os
import glob
from typing import List, Tuple, Optional, Dict
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from gcode_engine import Polyline
import image_processor


# -----------------------------
# Font discovery
# -----------------------------
# Common Windows font directories
_WINDOWS_FONT_DIRS = [
    os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),
    os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts"),
]

# Common font extensions
_FONT_EXTENSIONS = ("*.ttf", "*.otf", "*.ttc", "*.woff", "*.woff2")

# Cache for discovered fonts
_font_cache: Optional[Dict[str, str]] = None


def discover_fonts(extra_dirs: Optional[List[str]] = None) -> Dict[str, str]:
    """
    Scan system font directories and return a dict of {display_name: file_path}.
    Results are cached after first call.
    """
    global _font_cache
    if _font_cache is not None:
        return _font_cache

    fonts = {}
    search_dirs = list(_WINDOWS_FONT_DIRS)
    if extra_dirs:
        search_dirs.extend(extra_dirs)

    for font_dir in search_dirs:
        if not os.path.isdir(font_dir):
            continue
        for ext in _FONT_EXTENSIONS:
            for fp in glob.glob(os.path.join(font_dir, ext)):
                try:
                    # Get display name from font file
                    font = ImageFont.truetype(fp, size=20)
                    # Try to get font family name
                    name = _get_font_display_name(font, fp)
                    if name and name not in fonts:
                        fonts[name] = fp
                except Exception:
                    continue

    # Sort by name
    _font_cache = dict(sorted(fonts.items(), key=lambda x: x[0].lower()))
    return _font_cache


def _get_font_display_name(font: ImageFont.FreeTypeFont, filepath: str) -> str:
    """Extract a human-readable name from a font object."""
    try:
        # Pillow >= 10.1 has getname()
        family, style = font.getname()
        if style and style.lower() != "regular":
            return f"{family} {style}"
        return family
    except Exception:
        # Fallback to filename
        return Path(filepath).stem.replace("-", " ").replace("_", " ").title()


def get_default_font_path() -> Optional[str]:
    """Return the path to a good default font (Arial or first available)."""
    fonts = discover_fonts()

    # Prefer common clean fonts
    preferred = ["Arial", "Segoe UI", "Calibri", "Verdana", "Tahoma", "Roboto"]
    for name in preferred:
        if name in fonts:
            return fonts[name]

    # Fallback: first available
    if fonts:
        return next(iter(fonts.values()))

    return None


# -----------------------------
# Text rendering to image
# -----------------------------
def render_text_to_image(
    text: str,
    font_path: Optional[str] = None,
    font_size: int = 80,
    padding: int = 10,
) -> np.ndarray:
    """
    Render text using a TTF/OTF font into a high-resolution binary image.
    Returns a numpy array (0=background, 255=text) ready for contour extraction.
    """
    # Load font
    if font_path and os.path.isfile(font_path):
        font = ImageFont.truetype(font_path, size=font_size)
    else:
        # Fallback to default
        default_path = get_default_font_path()
        if default_path:
            font = ImageFont.truetype(default_path, size=font_size)
        else:
            font = ImageFont.load_default()

    # Calculate text bounding box
    # Use a temporary image to measure
    tmp_img = Image.new("L", (1, 1), color=255)
    draw = ImageDraw.Draw(tmp_img)
    bbox = draw.multiline_textbbox((0, 0), text, font=font)
    text_w = bbox[2] - bbox[0] + padding * 2
    text_h = bbox[3] - bbox[1] + padding * 2

    # Render text
    img = Image.new("L", (text_w, text_h), color=255)  # white background
    draw = ImageDraw.Draw(img)
    draw.multiline_text(
        (padding - bbox[0], padding - bbox[1]),
        text,
        font=font,
        fill=0,  # black text
    )

    return np.array(img, dtype=np.uint8)


# -----------------------------
# Text → polyline paths
# -----------------------------
def text_to_paths(
    text: str,
    font_path: Optional[str] = None,
    font_size: int = 80,
    target_width_mm: float = 200.0,
    target_height_mm: Optional[float] = None,
    fill_mode: str = "contour",
    simplify: float = 1.0,
    hatch_spacing: float = 3.0,
    hatch_angle: float = 45.0,
    offset_x: float = 0.0,
    offset_y: float = 0.0,
) -> Tuple[List[Polyline], int, int]:
    """
    Render text with a system font and convert to plotter polylines.

    Pipeline: text → bitmap → threshold → contours → mm-scale paths.

    Returns (paths, rendered_width_px, rendered_height_px).
    """
    # Render to grayscale bitmap
    gray = render_text_to_image(text, font_path, font_size)
    img_h, img_w = gray.shape

    # Threshold: text is black (0) on white (255), so we invert to get
    # white regions = text
    _, binary = __import__("cv2").threshold(gray, 128, 255, __import__("cv2").THRESH_BINARY_INV)

    # Maintain aspect ratio
    if target_height_mm is None:
        aspect = img_h / img_w if img_w > 0 else 1.0
        target_height_mm = target_width_mm * aspect

    # Convert to paths
    paths = image_processor.numpy_to_paths(
        binary,
        target_width_mm=target_width_mm,
        target_height_mm=target_height_mm,
        simplify=simplify,
        min_area=5.0,
        fill_mode=fill_mode,
        hatch_spacing=hatch_spacing,
        hatch_angle=hatch_angle,
        offset_x=offset_x,
        offset_y=offset_y,
    )

    return paths, img_w, img_h
